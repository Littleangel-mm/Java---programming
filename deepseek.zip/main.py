import requests

# API接口的URL
url = "https://api.siliconflow.cn/v1/chat/completions"

# 用户的对话历史
conversation_history = []

# 设置请求头
headers = {
    "Authorization": "Bearer sk-gckgbayekwaxrmyczrvfcoblnsptmcxszzmocwiuxgilifjc",  # 使用你的实际 API 密钥
    "Content-Type": "application/json"
}

while True:
    # 获取用户输入的问题
    user_question = input("You: ")

    # 如果用户输入 "exit" 则退出对话
    if user_question.lower() == "exit":
        print("Ending conversation.")
        break

    # 将用户问题加入对话历史
    conversation_history.append({"role": "user", "content": user_question})

    # 设置请求payload，包含对话历史
    payload = {
        "model": "Qwen/QwQ-32B",  # 使用的模型
        "messages": conversation_history,  # 传递整个对话历史
        "stream": False,  # 不使用流式传输
        "max_tokens": 512,  # 最大响应字符数
        "temperature": 0.7,  # 生成内容的多样性
        "top_p": 0.7,
        "top_k": 50,
        "frequency_penalty": 0.5,
        "n": 1,
        "response_format": {"type": "text"},  # 返回文本格式
        "tools": [
            {
                "type": "function",
                "function": {
                    "name": "predict_industry_trends",  # 工具函数名称
                    "arguments": "{\"country\": \"China\", \"industry\": \"large model\", \"year\": 2025}"  # 函数参数
                }
            }
        ]
    }

    # 发送请求并获取响应
    response = requests.post(url, json=payload, headers=headers)

    # 解析并打印响应内容
    response_data = response.json()

    if response_data.get("choices"):
        assistant_reply = response_data["choices"][0]["message"]["content"]
        print(f"Model: {assistant_reply}")
        # 将模型的回应加入对话历史
        conversation_history.append({"role": "assistant", "content": assistant_reply})
    else:
        print("No response from the model.")
