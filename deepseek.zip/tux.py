import requests
import json
from datetime import datetime
import os
from typing import Optional, Dict, Any

class KeywordImageGenerator:
    def __init__(self, api_key: str):
        """
        初始化API客户端
        
        :param api_key: SiliconFlow API密钥
        """
        self.api_url = "https://api.siliconflow.cn/v1/images/generations"
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
    
    def generate_from_keywords(
        self,
        keywords: str,
        model: str = "Kwai-Kolors/Kolors",
        negative_keywords: Optional[str] = None,
        image_size: str = "1024x1024",
        batch_size: int = 1,
        seed: Optional[int] = None,
        num_inference_steps: int = 20,
        guidance_scale: float = 7.5
    ) -> Dict[str, Any]:
        """
        根据关键词生成图像
        
        :param keywords: 描述图像的关键词，用逗号分隔
        :param negative_keywords: 不希望出现在图像中的关键词
        :param model: 使用的模型名称
        :param image_size: 图像尺寸，格式为"宽x高"
        :param batch_size: 生成图像的数量
        :param seed: 随机种子，用于可重复性
        :param num_inference_steps: 推理步骤数
        :param guidance_scale: 指导比例
        :return: API响应数据
        """
        # 将关键词转换为自然语言提示
        prompt = self._keywords_to_prompt(keywords)
        negative_prompt = self._keywords_to_prompt(negative_keywords) if negative_keywords else ""
        
        # 构建请求负载
        payload = {
            "model": model,
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "image_size": image_size,
            "batch_size": batch_size,
            "seed": seed,
            "num_inference_steps": num_inference_steps,
            "guidance_scale": guidance_scale,
        }
        
        try:
            # 发送API请求
            response = requests.post(
                self.api_url,
                json=payload,
                headers=self.headers,
                timeout=30  # 30秒超时
            )
            
            # 检查响应状态
            response.raise_for_status()
            
            # 返回JSON响应
            return response.json()
            
        except requests.exceptions.RequestException as e:
            # 处理请求错误
            error_msg = f"API请求失败: {str(e)}"
            if hasattr(e, 'response') and e.response is not None:
                error_msg += f", 状态码: {e.response.status_code}, 响应: {e.response.text}"
            raise RuntimeError(error_msg)
    
    def _keywords_to_prompt(self, keywords: str) -> str:
        """
        将关键词转换为自然语言提示
        
        :param keywords: 逗号分隔的关键词
        :return: 自然语言提示
        """
        keyword_list = [k.strip() for k in keywords.split(",")]
        return " ".join(keyword_list) + ", high quality, detailed, 4K"

def save_image_from_response(response_data: Dict[str, Any]):
    """
    根据API响应保存图像
    
    :param response_data: API返回的JSON数据
    :return: 保存的图像路径
    """
    # 创建输出目录
    if not os.path.exists("output"):
        os.makedirs("output")
    
    # 生成文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    try:
        # 检查API返回的图像URL格式
        if 'data' in response_data and isinstance(response_data['data'], list) and len(response_data['data']) > 0:
            image_url = response_data['data'][0].get('url')
            
            if image_url:
                # 下载图像
                image_response = requests.get(image_url, timeout=30)
                image_response.raise_for_status()
                
                # 保存图像
                filename = f"output/generated_image_{timestamp}.png"
                with open(filename, "wb") as f:
                    f.write(image_response.content)
                return filename
        
        # 检查base64编码图像
        elif 'images' in response_data and isinstance(response_data['images'], list) and len(response_data['images']) > 0:
            image_data = response_data['images'][0]
            
            if isinstance(image_data, str) and image_data.startswith("data:image"):
                import base64
                header, encoded = image_data.split(",", 1)
                image_bytes = base64.b64decode(encoded)
                filename = f"output/generated_image_{timestamp}.png"
                with open(filename, "wb") as f:
                    f.write(image_bytes)
                return filename
        
        # 如果以上格式都不匹配，保存原始JSON供调试
        filename = f"output/generated_image_{timestamp}.json"
        with open(filename, "w") as f:
            json.dump(response_data, f, indent=2)
        return None
    
    except Exception as e:
        print(f"保存图像时出错: {str(e)}")
        # 保存错误信息
        error_filename = f"output/error_{timestamp}.json"
        with open(error_filename, "w") as f:
            json.dump({
                "error": str(e),
                "response_data": response_data
            }, f, indent=2)
        return None

# 使用示例
if __name__ == "__main__":
    # 替换为你的实际API密钥
    API_KEY = "sk-gckgbayekwaxrmyczrvfcoblnsptmcxszzmocwiuxgilifjc"
    
    # 创建生成器实例
    generator = KeywordImageGenerator(API_KEY)
    
    print("SiliconFlow 关键词图像生成器")
    print("输入用逗号分隔的关键词来描述你想要生成的图像")
    print("例如: 少女, 樱花, 春天, 和服")
    
    # 获取用户输入
    keywords = input("\n请输入描述图像的关键词(用逗号分隔): ").strip()
    negative_keywords = input("请输入不希望出现在图像中的关键词(可选，用逗号分隔): ").strip()
    
    if not keywords:
        print("错误: 必须输入至少一个关键词")
        exit(1)
    
    try:
        # 调用API生成图像
        print("\n正在生成图像，请稍候...")
        result = generator.generate_from_keywords(
            keywords=keywords,
            negative_keywords=negative_keywords if negative_keywords else None,
            seed=4999999999
        )
        
        print("\n图像生成成功!")
        saved_file = save_image_from_response(result)
        
        if saved_file:
            print(f"图像已保存到: {saved_file}")
        else:
            print("API返回了无法识别的格式，已保存原始响应到output目录")
            print("请检查API文档确认返回格式，或联系API提供商")
            
    except Exception as e:
        print(f"\n图像生成失败: {str(e)}")