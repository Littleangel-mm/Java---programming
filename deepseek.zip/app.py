from flask import Flask, render_template, request, jsonify
import requests
import os
from dotenv import load_dotenv
from typing import Optional, Dict, Any

# 加载 .env 文件
load_dotenv()

# 获取 API 密钥
API_KEY = os.getenv("API_KEY")

# 确保 API_KEY 被加载
if not API_KEY:
    raise ValueError("API_KEY not found in .env file.")

# 关键词图像生成器类
class KeywordImageGenerator:
    def __init__(self, api_key: str):
        self.api_url = "https://api.siliconflow.cn/v1/images/generations"
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
    
    def generate_from_keywords(
        self,
        keywords: str,
        model: str = "Kwai-Kolors/Kolors",
        negative_keywords: Optional[str] = None,
        image_size: str = "1024x1024",
        batch_size: int = 1,
        seed: Optional[int] = None,
        num_inference_steps: int = 20,
        guidance_scale: float = 7.5
    ) -> Dict[str, Any]:
        prompt = self._keywords_to_prompt(keywords)
        negative_prompt = self._keywords_to_prompt(negative_keywords) if negative_keywords else ""
        
        payload = {
            "model": model,
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "image_size": image_size,
            "batch_size": batch_size,
            "seed": seed,
            "num_inference_steps": num_inference_steps,
            "guidance_scale": guidance_scale,
        }
        
        try:
            response = requests.post(self.api_url, json=payload, headers=self.headers, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            error_msg = f"API请求失败: {str(e)}"
            if hasattr(e, 'response') and e.response is not None:
                error_msg += f", 状态码: {e.response.status_code}, 响应: {e.response.text}"
            raise RuntimeError(error_msg)
    
    def _keywords_to_prompt(self, keywords: str) -> str:
        keyword_list = [k.strip() for k in keywords.split(",")]
        return " ".join(keyword_list) + ", high quality, detailed, 4K"


# Flask应用
app = Flask(__name__)

# 创建生成器实例
generator = KeywordImageGenerator(API_KEY)

# 请求头
headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

# 在全局范围内定义对话历史
conversation_history = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_question = request.form['user_question']

    if user_question.lower() == "exit":
        return jsonify({'message': 'Conversation ended'})

    # 将用户问题加入对话历史
    conversation_history.append({"role": "user", "content": user_question})

    payload = {
        "model": "Qwen/QwQ-32B",
        "messages": conversation_history,  # 传递整个对话历史
        "stream": False,
        "max_tokens": 512,
        "temperature": 0.7,
        "top_p": 0.7,
        "top_k": 50,
        "frequency_penalty": 0.5,
        "n": 1,
        "response_format": {"type": "text"},
    }

    # 发送请求并获取响应
    response = requests.post('https://api.siliconflow.cn/v1/chat/completions', json=payload, headers=headers)

    response_data = response.json()

    if response_data.get("choices"):
        assistant_reply = response_data["choices"][0]["message"]["content"]
        # 将模型的回应加入对话历史
        conversation_history.append({"role": "assistant", "content": assistant_reply})
        return jsonify({'message': assistant_reply})
    else:
        return jsonify({'message': 'No response from the model.'}) 
    
@app.route('/generate_image', methods=['POST'])
def generate_image():
    keywords = request.form['image_prompt']
    negative_keywords = request.form['negative_prompt']  # 可选的负面关键词

    if not keywords.strip():
        return jsonify({'message': 'Please provide a prompt for the image generation.'})

    try:
        # 调用关键词生成图像的API
        print("\n正在生成图像，请稍候...")
        result = generator.generate_from_keywords(
            keywords=keywords,
            negative_keywords=negative_keywords if negative_keywords else None,
            seed=4999999999
        )
        
        # 打印返回的结果，检查API的返回数据
        print(result)

        # 检查返回的结果是否包含图像的URL
        if "images" in result and len(result["images"]) > 0:
            image_url = result["images"][0]["url"]  # 获取第一个图像的URL
            return jsonify({'image_url': image_url})
        else:
            return jsonify({'message': 'No image generated.'})

    except Exception as e:
        return jsonify({'message': f"Error: {str(e)}"})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
