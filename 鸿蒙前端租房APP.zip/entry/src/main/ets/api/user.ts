import { http } from '../utils/http';

import { IUserInfo } from '../models/UserData';

// 发送验证码
export const sendSMSCodeApi = (phone: string): Promise<string> => {
  if (phone === '11') {
    return Promise.resolve('123456')
  }
  return http.post<string>('/sendSMSCode', { phone })
}

interface RresData {
  token: string
}

// 登录
export const loginApi = (phone: string, code: string): Promise<RresData> => {
  if (phone === '11') {
    return Promise.resolve({ token: 'mock-token' })
  }
  return http.post<RresData>('/login', { phone, code })
}

// 获取用户数据
export const getUserInfoApi = (): Promise<IUserInfo> => {
  const token = AppStorage.get('token') as string
  if (token === 'mock-token') {
    const user: IUserInfo = { id: 1, avatar: 'https://picsum.photos/seed/avatar/100/100', nickname: '模拟用户', points: 15 }
    return Promise.resolve(user)
  }
  return http.get<IUserInfo>('/auth/user/userInfo')
}
