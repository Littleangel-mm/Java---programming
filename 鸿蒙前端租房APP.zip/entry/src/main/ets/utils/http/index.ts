import Http from './http';

// 统一new,外部直接使用
export const http = new Http();