export type OrderStatus = '已预约' | '待支付' | '已支付' | '已取消'

export interface IOrderItem {
  id: string
  houseId: string
  title: string
  cover: string
  price: string
  unit: string
  status: OrderStatus
  createdAt: string
}

export type IOrderList = IOrderItem[]

export interface ICreateOrderInfo {
  houseId: string
  title: string
  cover: string
  price?: string
  unit?: string
}

export interface ICreateOrderResponse {
  success: boolean
  orderId: string
}

