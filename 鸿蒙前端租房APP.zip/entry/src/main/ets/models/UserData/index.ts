export interface IUserInfo {
  "id": number
  "nickname": string
  "avatar": string
  "points"?: number
}
