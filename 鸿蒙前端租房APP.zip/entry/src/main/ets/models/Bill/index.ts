export type BillStatus = '待支付' | '已支付'

export interface IBillItem {
  id: string
  orderId: string
  title: string
  amount: string
  createdAt: string
  status: BillStatus
}

export type IBillList = IBillItem[]

export interface ICreateBillInfo {
  orderId: string
  title: string
  amount: string
}

export interface ICreateBillResponse {
  success: boolean
  billId: string
}

