首页页面：![alt text](image.png)

想看页面：![alt text](image-1.png)

服务页面：![alt text](image-2.png)

发现页面：![alt text](image-3.png)

我的页面：![alt text](image-4.png)

房源推荐：![alt text](image-5.png)

房源筛选：![alt text](image-6.png)

预定房源：![alt text](image-7.png)

用户登陆：![alt text](image-8.png)

预约看房：![alt text](image-9.png)

## 项目概述

一个基于 HarmonyOS ArkTS/ArkUI 的租房类应用，覆盖首页推荐、房源搜索与详情、服务与发现、个人中心、登录、预约记录、订单与账单等流程。

## 技术栈与架构

- 框架：ArkUI（声明式 UI），语言：ArkTS
- 响应式：`@State`、`@Prop`、`@Link`、`@StorageLink`，全局持久化：`PersistentStorage`
- 组件封装：`ScrollContainer`（头部渐变与滚动处理）、`NavBar`、`Drawer`、`ConfirmDialog`
- 响应式工具：`rvp()` 等比例换算、`getWindowTopHeight()`状态栏高度适配
- 数据存储：`AppStorage` 持久化列表；其他模块由 `mock/index.ets` 控制 `USE_MOCK = true`

## 页面与功能

- 首页（`pages/Home.ets`）
  - Banner、功能导航、瓷片与计划位、轮播图、周边房源推荐
  - 点击“更多推荐”跳转房源列表
- 房源列表（`pages/RentRoom/RentRoomList.ets`）
  - 筛选：地区/租金/付款方式/排序（`views/RentRoomList/SearchFilter.ets`）
  - 瀑布流展示与触底加载（`views/RentRoomList/WaterfallFlow.ets`）
  - 支持“地图找房”“通勤找房”快捷入口（`views/See/FindRoom.ets`）
- 房源详情（`pages/RentRoom/RentRoomDetail.ets`）
  - 价格、优惠、配套信息、户型、标签、图集（多个 `views/RentRoomDetail/*` 组件）
  - 预约看房浮层：表单填写后生成一条订单与账单（本地模拟）
- 发现与服务（`pages/Discover.ets`、`pages/Service.ets`）
  - 列表均使用本地 `mock` 数据，便于讲解接口抽象与页面渲染
- 我的（`pages/My.ets`）
  - 显示用户信息，导航入口包含“约看/订单/账单”等模块（`views/My/Order.ets`）
- 登录（`pages/Login/LoginPhone.ets`、`pages/Login/LoginCode.ets`）
  - 手机号 + 验证码登录；本地模拟“验证码与 token 写入”
- 预约列表（`pages/BookRentRoomList.ets`）
  - 展示已预约记录（来源于本地），当前版本不提供删除入口
- 订单列表（`pages/OrderList.ets`）
  - 展示本地生成的订单记录，当前版本不提供删除入口
- 账单列表（`pages/BillList.ets`）
  - 展示本地生成的账单记录，当前版本不提供删除入口

## 数据说明

- 全局 Mock 开关：`entry/src/main/ets/mock/index.ets` 中 `USE_MOCK = true`
- 预约/订单/账单为本地模拟（不发起网络请求）：
  - 预约列表读取：`entry/src/main/ets/api/book.ets` 的 `getBookRentRoomListApi`
  - 订单列表读取/创建：`entry/src/main/ets/api/order.ets` 的 `getOrderListApi`、`createOrderApi`
  - 账单列表读取/创建：`entry/src/main/ets/api/bill.ets` 的 `getBillListApi`、`createBillApi`
- 存储容器：`AppStorage`，入口页 `pages/Index.ets` 中 `PersistentStorage.persistProp(...)` 持久化关键数据

## 交互要点（当前版本）

- 列表项展示为信息卡片，保留“去咨询”等文案，
- 预约看房表单提交后，会在本地生成对应的订单与账单记录，
- 页面切换与参数传递使用 `@ohos.router`（如“我的”页跳转预约与订单、账单等）

## 路由注册

- `entry/src/main/resources/base/profile/main_pages.json` 注册了主要页面：
  - `pages/Index`、`pages/RentRoom/RentRoomList`、`pages/RentRoom/RentRoomDetail`
  - `pages/Login/LoginPhone`、`pages/Login/LoginCode`
  - `pages/BookRentRoomList`、`pages/OrderList`、`pages/BillList`

## 代码结构速览

- `pages/*`：顶层页面（首页、列表、详情、发现、服务、我的、登录、预约、订单、账单）
- `views/*`：页面的子模块与复合组件（如详情页的各部分、筛选、Banner 等）
- `components/*`：通用组件（`ScrollContainer`、`NavBar`、`Drawer`、`ConfirmDialog` 等）
- `api/*`：接口层（当前预约/订单/账单为，其余由 `USE_MOCK` 控制）
- `mock/*`：模拟数据与生成逻辑（房源列表/详情、首页、服务、发现）
- `models/*`：数据类型声明
- `utils/*`：响应式尺寸换算、状态栏高度、提示等工具

## 说明

- 讲 ArkUI 声明式开发与响应式状态：`@State/@Prop/@Link/@StorageLink` 与组件数据流
- 演示路由跳转与参数传递：从“我的”页到预约/订单/账单，再到房源列表/详情
- 讲本地持久化与 Mock：`PersistentStorage`、`AppStorage`、`USE_MOCK` 与本地列表读写
- 讲 UI 适配：`rvp()` 等比例换算，`getWindowTopHeight()` 状态栏适配，`ScrollContainer` 的滚动与头部颜色变化
- 展示预约→产生订单与账单的流程

## 运行与预览

- 推荐使用 DevEco Studio



## 故障处理方式，没有Hyper-V
win 10家庭版 处理虚拟机的脚本已经放在文件夹了   Hyper-V.cmd，管理员身份运行，然后重启
  
