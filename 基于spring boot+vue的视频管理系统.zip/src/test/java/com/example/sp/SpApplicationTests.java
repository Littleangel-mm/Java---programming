package com.example.sp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpApplicationTests {

    @Test
    void contextLoads() {
    }

}
