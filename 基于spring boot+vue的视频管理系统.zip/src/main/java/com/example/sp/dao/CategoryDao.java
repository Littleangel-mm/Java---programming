package com.example.sp.dao;

import com.example.sp.Entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/**
 * 分类数据访问对象接口
 * 提供分类相关的高级数据访问操作
 */
public interface CategoryDao {
    
    /**
     * 根据名称查找分类
     */
    Optional<Category> findByName(String name);
    
    /**
     * 根据激活状态查找分类
     */
    List<Category> findByIsActive(Boolean isActive);
    
    /**
     * 根据父分类ID查找子分类
     */
    List<Category> findByParentId(Long parentId);
    
    /**
     * 查找顶级分类（无父分类）
     */
    List<Category> findTopLevelCategories();
    
    /**
     * 分页查询分类
     */
    Page<Category> findCategoriesWithPagination(Pageable pageable);
    
    /**
     * 搜索分类
     */
    Page<Category> searchCategories(String keyword, Boolean isActive, Pageable pageable);
    
    /**
     * 获取分类树结构
     */
    List<CategoryTree> getCategoryTree();
    
    /**
     * 获取分类统计信息
     */
    CategoryStatistics getCategoryStatistics();
    
    /**
     * 获取分类下的视频数量
     */
    long getVideoCountByCategory(Long categoryId);
    
    /**
     * 获取分类及其子分类的视频数量
     */
    long getTotalVideoCountByCategory(Long categoryId);
    
    /**
     * 获取热门分类
     */
    List<CategoryWithVideoCount> getPopularCategories(int limit);
    
    /**
     * 检查分类名称是否存在
     */
    boolean existsByName(String name);
    
    /**
     * 检查分类是否有子分类
     */
    boolean hasChildren(Long categoryId);
    
    /**
     * 检查分类下是否有视频
     */
    boolean hasVideos(Long categoryId);
    
    /**
     * 分类树结构内部类
     */
    class CategoryTree {
        private Category category;
        private List<CategoryTree> children;
        private long videoCount;
        
        public CategoryTree(Category category) {
            this.category = category;
            this.children = new java.util.ArrayList<>();
        }
        
        // Getters and Setters
        public Category getCategory() { return category; }
        public List<CategoryTree> getChildren() { return children; }
        public void setChildren(List<CategoryTree> children) { this.children = children; }
        public long getVideoCount() { return videoCount; }
        public void setVideoCount(long videoCount) { this.videoCount = videoCount; }
    }
    
    /**
     * 分类统计信息内部类
     */
    class CategoryStatistics {
        private long totalCategories;
        private long activeCategories;
        private long inactiveCategories;
        private long topLevelCategories;
        private long subCategories;
        
        public CategoryStatistics(long totalCategories, long activeCategories, long inactiveCategories, 
                                long topLevelCategories, long subCategories) {
            this.totalCategories = totalCategories;
            this.activeCategories = activeCategories;
            this.inactiveCategories = inactiveCategories;
            this.topLevelCategories = topLevelCategories;
            this.subCategories = subCategories;
        }
        
        // Getters
        public long getTotalCategories() { return totalCategories; }
        public long getActiveCategories() { return activeCategories; }
        public long getInactiveCategories() { return inactiveCategories; }
        public long getTopLevelCategories() { return topLevelCategories; }
        public long getSubCategories() { return subCategories; }
    }
    
    /**
     * 带视频数量的分类内部类
     */
    class CategoryWithVideoCount {
        private Long categoryId;
        private String categoryName;
        private long videoCount;
        
        public CategoryWithVideoCount(Long categoryId, String categoryName, long videoCount) {
            this.categoryId = categoryId;
            this.categoryName = categoryName;
            this.videoCount = videoCount;
        }
        
        // Getters
        public Long getCategoryId() { return categoryId; }
        public String getCategoryName() { return categoryName; }
        public long getVideoCount() { return videoCount; }
    }
} 