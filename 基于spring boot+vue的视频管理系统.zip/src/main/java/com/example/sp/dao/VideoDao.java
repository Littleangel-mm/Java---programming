package com.example.sp.dao;

import com.example.sp.Entity.Video;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/**
 * 视频数据访问对象接口
 * 提供视频相关的高级数据访问操作
 */
public interface VideoDao {
    
    /**
     * 根据标题查找视频
     */
    Optional<Video> findByTitle(String title);
    
    /**
     * 根据用户ID查找视频
     */
    List<Video> findByUserId(Long userId);
    
    /**
     * 根据分类ID查找视频
     */
    List<Video> findByCategoryId(Long categoryId);
    
    /**
     * 根据视频状态查找视频
     */
    List<Video> findByStatus(Video.VideoStatus status);
    
    /**
     * 根据视频可见性查找视频
     */
    List<Video> findByVisibility(Video.VideoVisibility visibility);
    
    /**
     * 分页查询视频
     */
    Page<Video> findVideosWithPagination(Pageable pageable);
    
    /**
     * 根据条件搜索视频
     */
    Page<Video> searchVideos(String keyword, Long categoryId, Video.VideoStatus status, 
                           Video.VideoVisibility visibility, Pageable pageable);
    
    /**
     * 获取热门视频
     */
    List<Video> getPopularVideos(int limit);
    
    /**
     * 获取最新视频
     */
    List<Video> getLatestVideos(int limit);
    
    /**
     * 获取推荐视频
     */
    List<Video> getRecommendedVideos(Long userId, int limit);
    
    /**
     * 获取用户喜欢的视频
     */
    List<Video> getUserLikedVideos(Long userId);
    
    /**
     * 获取用户收藏的视频
     */
    List<Video> getUserFavoriteVideos(Long userId);
    
    /**
     * 获取视频统计信息
     */
    VideoStatistics getVideoStatistics();
    
    /**
     * 获取分类视频统计
     */
    List<CategoryVideoCount> getCategoryVideoCounts();
    
    /**
     * 检查用户是否喜欢视频
     */
    boolean isLikedByUser(Long videoId, Long userId);
    
    /**
     * 检查用户是否收藏视频
     */
    boolean isFavoritedByUser(Long videoId, Long userId);
    
    /**
     * 获取视频点赞数
     */
    long getLikeCount(Long videoId);
    
    /**
     * 获取视频收藏数
     */
    long getFavoriteCount(Long videoId);
    
    /**
     * 获取视频评论数
     */
    long getCommentCount(Long videoId);
    
    /**
     * 获取视频播放数
     */
    long getViewCount(Long videoId);
    
    /**
     * 增加视频播放数
     */
    void incrementViewCount(Long videoId);
    
    /**
     * 视频统计信息内部类
     */
    class VideoStatistics {
        private long totalVideos;
        private long publishedVideos;
        private long draftVideos;
        private long pendingVideos;
        private long totalViews;
        private long totalLikes;
        private long totalComments;
        
        public VideoStatistics(long totalVideos, long publishedVideos, long draftVideos, 
                             long pendingVideos, long totalViews, long totalLikes, long totalComments) {
            this.totalVideos = totalVideos;
            this.publishedVideos = publishedVideos;
            this.draftVideos = draftVideos;
            this.pendingVideos = pendingVideos;
            this.totalViews = totalViews;
            this.totalLikes = totalLikes;
            this.totalComments = totalComments;
        }
        
        // Getters
        public long getTotalVideos() { return totalVideos; }
        public long getPublishedVideos() { return publishedVideos; }
        public long getDraftVideos() { return draftVideos; }
        public long getPendingVideos() { return pendingVideos; }
        public long getTotalViews() { return totalViews; }
        public long getTotalLikes() { return totalLikes; }
        public long getTotalComments() { return totalComments; }
    }
    
    /**
     * 分类视频数量内部类
     */
    class CategoryVideoCount {
        private Long categoryId;
        private String categoryName;
        private long videoCount;
        
        public CategoryVideoCount(Long categoryId, String categoryName, long videoCount) {
            this.categoryId = categoryId;
            this.categoryName = categoryName;
            this.videoCount = videoCount;
        }
        
        // Getters
        public Long getCategoryId() { return categoryId; }
        public String getCategoryName() { return categoryName; }
        public long getVideoCount() { return videoCount; }
    }
} 