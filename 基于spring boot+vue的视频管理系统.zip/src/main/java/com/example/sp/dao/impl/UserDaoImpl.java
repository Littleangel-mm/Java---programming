package com.example.sp.dao.impl;

import com.example.sp.Entity.User;
import com.example.sp.Repository.UserRepository;
import com.example.sp.dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;
import java.util.Optional;

/**
 * 用户数据访问对象实现类
 */
@Repository
public class UserDaoImpl implements UserDao {
    
    @Autowired
    private UserRepository userRepository;
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Override
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
    
    @Override
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    @Override
    public Optional<User> findByUsernameOrEmail(String username, String email) {
        Optional<User> userByUsername = userRepository.findByUsername(username);
        if (userByUsername.isPresent()) {
            return userByUsername;
        }
        return userRepository.findByEmail(email);
    }
    
    @Override
    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }
    
    @Override
    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }
    
    @Override
    public List<User> findByStatus(User.UserStatus status) {
        return userRepository.findByStatus(status);
    }
    
    @Override
    public List<User> findByRole(User.UserRole role) {
        return userRepository.findByRole(role);
    }
    
    @Override
    public Page<User> findUsersWithPagination(Pageable pageable) {
        return userRepository.findAll(pageable);
    }
    
    @Override
    public Page<User> searchUsers(String keyword, User.UserStatus status, User.UserRole role, Pageable pageable) {
        if (keyword != null && !keyword.trim().isEmpty()) {
            if (status != null && role != null) {
                return userRepository.findByRoleAndStatus(role, status, pageable);
            } else if (status != null) {
                return userRepository.findByStatus(status, pageable);
            } else if (role != null) {
                return userRepository.findByRole(role, pageable);
            } else {
                return userRepository.searchUsers(keyword, pageable);
            }
        } else {
            if (status != null && role != null) {
                return userRepository.findByRoleAndStatus(role, status, pageable);
            } else if (status != null) {
                return userRepository.findByStatus(status, pageable);
            } else if (role != null) {
                return userRepository.findByRole(role, pageable);
            } else {
                return userRepository.findAll(pageable);
            }
        }
    }
    
    @Override
    public UserStatistics getUserStatistics() {
        String sql = "SELECT " +
            "COUNT(*) as totalUsers, " +
            "SUM(CASE WHEN status = 'ACTIVE' THEN 1 ELSE 0 END) as activeUsers, " +
            "SUM(CASE WHEN status = 'INACTIVE' THEN 1 ELSE 0 END) as inactiveUsers, " +
            "SUM(CASE WHEN role = 'ADMIN' THEN 1 ELSE 0 END) as adminUsers, " +
            "SUM(CASE WHEN role = 'USER' THEN 1 ELSE 0 END) as regularUsers " +
            "FROM users";
        
        Query query = entityManager.createNativeQuery(sql);
        Object[] result = (Object[]) query.getSingleResult();
        
        return new UserStatistics(
            ((Number) result[0]).longValue(),
            ((Number) result[1]).longValue(),
            ((Number) result[2]).longValue(),
            ((Number) result[3]).longValue(),
            ((Number) result[4]).longValue()
        );
    }
    
    @Override
    public List<User> getActiveUsers(int limit) {
        return userRepository.findActiveUsers(5, org.springframework.data.domain.PageRequest.of(0, limit));
    }
    
    @Override
    public List<User> getUserFollowings(Long userId) {
        String sql = "SELECT u.* FROM users u " +
            "INNER JOIN user_follows uf ON u.id = uf.following_id " +
            "WHERE uf.follower_id = :userId " +
            "ORDER BY uf.created_time DESC";
        
        Query query = entityManager.createNativeQuery(sql, User.class);
        query.setParameter("userId", userId);
        return query.getResultList();
    }
    
    @Override
    public List<User> getUserFollowers(Long userId) {
        String sql = "SELECT u.* FROM users u " +
            "INNER JOIN user_follows uf ON u.id = uf.follower_id " +
            "WHERE uf.following_id = :userId " +
            "ORDER BY uf.created_time DESC";
        
        Query query = entityManager.createNativeQuery(sql, User.class);
        query.setParameter("userId", userId);
        return query.getResultList();
    }
    
    @Override
    public boolean isFollowing(Long followerId, Long followingId) {
        String sql = "SELECT COUNT(*) FROM user_follows WHERE follower_id = :followerId AND following_id = :followingId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("followerId", followerId);
        query.setParameter("followingId", followingId);
        return ((Number) query.getSingleResult()).longValue() > 0;
    }
    
    @Override
    public long getFollowingCount(Long userId) {
        String sql = "SELECT COUNT(*) FROM user_follows WHERE follower_id = :userId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("userId", userId);
        return ((Number) query.getSingleResult()).longValue();
    }
    
    @Override
    public long getFollowerCount(Long userId) {
        String sql = "SELECT COUNT(*) FROM user_follows WHERE following_id = :userId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("userId", userId);
        return ((Number) query.getSingleResult()).longValue();
    }
} 