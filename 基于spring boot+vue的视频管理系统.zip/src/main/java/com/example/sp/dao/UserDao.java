package com.example.sp.dao;

import com.example.sp.Entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/**
 * 用户数据访问对象接口
 * 提供用户相关的高级数据访问操作
 */
public interface UserDao {
    
    /**
     * 根据用户名查找用户
     */
    Optional<User> findByUsername(String username);
    
    /**
     * 根据邮箱查找用户
     */
    Optional<User> findByEmail(String email);
    
    /**
     * 根据用户名或邮箱查找用户
     */
    Optional<User> findByUsernameOrEmail(String username, String email);
    
    /**
     * 检查用户名是否存在
     */
    boolean existsByUsername(String username);
    
    /**
     * 检查邮箱是否存在
     */
    boolean existsByEmail(String email);
    
    /**
     * 根据用户状态查找用户
     */
    List<User> findByStatus(User.UserStatus status);
    
    /**
     * 根据用户角色查找用户
     */
    List<User> findByRole(User.UserRole role);
    
    /**
     * 分页查询用户
     */
    Page<User> findUsersWithPagination(Pageable pageable);
    
    /**
     * 根据条件搜索用户
     */
    Page<User> searchUsers(String keyword, User.UserStatus status, User.UserRole role, Pageable pageable);
    
    /**
     * 获取用户统计信息
     */
    UserStatistics getUserStatistics();
    
    /**
     * 获取活跃用户列表
     */
    List<User> getActiveUsers(int limit);
    
    /**
     * 获取用户关注列表
     */
    List<User> getUserFollowings(Long userId);
    
    /**
     * 获取用户粉丝列表
     */
    List<User> getUserFollowers(Long userId);
    
    /**
     * 检查用户是否关注另一个用户
     */
    boolean isFollowing(Long followerId, Long followingId);
    
    /**
     * 获取用户关注数量
     */
    long getFollowingCount(Long userId);
    
    /**
     * 获取用户粉丝数量
     */
    long getFollowerCount(Long userId);
    
    /**
     * 用户统计信息内部类
     */
    class UserStatistics {
        private long totalUsers;
        private long activeUsers;
        private long inactiveUsers;
        private long adminUsers;
        private long regularUsers;
        
        // 构造函数
        public UserStatistics(long totalUsers, long activeUsers, long inactiveUsers, 
                            long adminUsers, long regularUsers) {
            this.totalUsers = totalUsers;
            this.activeUsers = activeUsers;
            this.inactiveUsers = inactiveUsers;
            this.adminUsers = adminUsers;
            this.regularUsers = regularUsers;
        }
        
        // Getters
        public long getTotalUsers() { return totalUsers; }
        public long getActiveUsers() { return activeUsers; }
        public long getInactiveUsers() { return inactiveUsers; }
        public long getAdminUsers() { return adminUsers; }
        public long getRegularUsers() { return regularUsers; }
    }
} 