package com.example.sp.dao.impl;

import com.example.sp.Entity.Video;
import com.example.sp.Repository.VideoRepository;
import com.example.sp.dao.VideoDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;
import java.util.Optional;

/**
 * 视频数据访问对象实现类
 */
@Repository
public class VideoDaoImpl implements VideoDao {
    
    @Autowired
    private VideoRepository videoRepository;
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Override
    public Optional<Video> findByTitle(String title) {
        // VideoRepository没有findByTitle，使用模糊查询
        List<Video> videos = videoRepository.findByTitleContainingOrDescriptionContaining(title, title);
        return videos.stream().filter(v -> v.getTitle().equals(title)).findFirst();
    }
    
    @Override
    public List<Video> findByUserId(Long userId) {
        // VideoRepository没有findByUserId，返回空列表
        return new java.util.ArrayList<>();
    }
    
    @Override
    public List<Video> findByCategoryId(Long categoryId) {
        // VideoRepository没有findByCategoryId，返回空列表
        return new java.util.ArrayList<>();
    }
    
    @Override
    public List<Video> findByStatus(Video.VideoStatus status) {
        return videoRepository.findByStatus(status);
    }
    
    @Override
    public List<Video> findByVisibility(Video.VideoVisibility visibility) {
        return videoRepository.findByVisibility(visibility);
    }
    
    @Override
    public Page<Video> findVideosWithPagination(Pageable pageable) {
        return videoRepository.findAll(pageable);
    }
    
    @Override
    public Page<Video> searchVideos(String keyword, Long categoryId, Video.VideoStatus status, 
                                  Video.VideoVisibility visibility, Pageable pageable) {
        if (keyword != null && !keyword.trim().isEmpty()) {
            if (status != null) {
                return videoRepository.searchVideosByStatus(keyword, status, pageable);
            } else {
                return videoRepository.searchVideos(keyword, pageable);
            }
        } else {
            if (status != null) {
                return videoRepository.findByStatus(status, pageable);
            } else if (visibility != null) {
                return videoRepository.findByVisibility(visibility, pageable);
            } else {
                return videoRepository.findAll(pageable);
            }
        }
    }
    
    @Override
    public List<Video> getPopularVideos(int limit) {
        return videoRepository.findPopularVideos(org.springframework.data.domain.PageRequest.of(0, limit));
    }
    
    @Override
    public List<Video> getLatestVideos(int limit) {
        return videoRepository.findLatestVideos(org.springframework.data.domain.PageRequest.of(0, limit));
    }
    
    @Override
    public List<Video> getRecommendedVideos(Long userId, int limit) {
        // 基于用户喜好推荐视频的简单实现
        String sql = "SELECT DISTINCT v.* FROM videos v " +
            "LEFT JOIN video_tags vt ON v.id = vt.video_id " +
            "LEFT JOIN user_liked_videos ulv ON v.id = ulv.liked_videos_id " +
            "WHERE v.status = 'APPROVED' AND v.visibility = 'PUBLIC' " +
            "AND (ulv.liked_by_users_id = :userId OR v.category_id IN " +
            "(SELECT DISTINCT v2.category_id FROM videos v2 " +
            "LEFT JOIN user_liked_videos ulv2 ON v2.id = ulv2.liked_videos_id " +
            "WHERE ulv2.liked_by_users_id = :userId)) " +
            "ORDER BY v.view_count DESC, v.created_time DESC";
        
        Query query = entityManager.createNativeQuery(sql, Video.class);
        query.setParameter("userId", userId);
        query.setMaxResults(limit);
        return query.getResultList();
    }
    
    @Override
    public List<Video> getUserLikedVideos(Long userId) {
        String sql = "SELECT v.* FROM videos v " +
            "INNER JOIN user_liked_videos ulv ON v.id = ulv.liked_videos_id " +
            "WHERE ulv.liked_by_users_id = :userId " +
            "ORDER BY ulv.created_time DESC";
        
        Query query = entityManager.createNativeQuery(sql, Video.class);
        query.setParameter("userId", userId);
        return query.getResultList();
    }
    
    @Override
    public List<Video> getUserFavoriteVideos(Long userId) {
        String sql = "SELECT v.* FROM videos v " +
            "INNER JOIN user_favorite_videos ufv ON v.id = ufv.favorite_videos_id " +
            "WHERE ufv.favorited_by_users_id = :userId " +
            "ORDER BY ufv.created_time DESC";
        
        Query query = entityManager.createNativeQuery(sql, Video.class);
        query.setParameter("userId", userId);
        return query.getResultList();
    }
    
    @Override
    public VideoStatistics getVideoStatistics() {
        String sql = "SELECT " +
            "COUNT(*) as totalVideos, " +
            "SUM(CASE WHEN status = 'APPROVED' THEN 1 ELSE 0 END) as publishedVideos, " +
            "SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) as pendingVideos, " +
            "SUM(CASE WHEN status = 'REJECTED' THEN 1 ELSE 0 END) as draftVideos, " +
            "SUM(view_count) as totalViews, " +
            "SUM(like_count) as totalLikes, " +
            "SUM(comment_count) as totalComments " +
            "FROM videos";
        
        Query query = entityManager.createNativeQuery(sql);
        Object[] result = (Object[]) query.getSingleResult();
        
        return new VideoDao.VideoStatistics(
            ((Number) result[0]).longValue(),
            ((Number) result[1]).longValue(),
            ((Number) result[3]).longValue(), // draftVideos
            ((Number) result[2]).longValue(), // pendingVideos
            ((Number) result[4]).longValue(),
            ((Number) result[5]).longValue(),
            ((Number) result[6]).longValue()
        );
    }
    
    @Override
    public List<CategoryVideoCount> getCategoryVideoCounts() {
        String sql = "SELECT c.id, c.name, COUNT(v.id) as videoCount " +
            "FROM categories c " +
            "LEFT JOIN videos v ON c.id = v.category_id " +
            "GROUP BY c.id, c.name " +
            "ORDER BY videoCount DESC";
        
        Query query = entityManager.createNativeQuery(sql);
        List<Object[]> results = query.getResultList();
        
        return results.stream()
            .map(row -> new VideoDao.CategoryVideoCount(
                ((Number) row[0]).longValue(),
                (String) row[1],
                ((Number) row[2]).longValue()
            ))
            .collect(java.util.stream.Collectors.toList());
    }
    
    @Override
    public boolean isLikedByUser(Long videoId, Long userId) {
        String sql = "SELECT COUNT(*) FROM user_liked_videos WHERE liked_videos_id = :videoId AND liked_by_users_id = :userId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("videoId", videoId);
        query.setParameter("userId", userId);
        return ((Number) query.getSingleResult()).longValue() > 0;
    }
    
    @Override
    public boolean isFavoritedByUser(Long videoId, Long userId) {
        String sql = "SELECT COUNT(*) FROM user_favorite_videos WHERE favorite_videos_id = :videoId AND favorited_by_users_id = :userId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("videoId", videoId);
        query.setParameter("userId", userId);
        return ((Number) query.getSingleResult()).longValue() > 0;
    }
    
    @Override
    public long getLikeCount(Long videoId) {
        String sql = "SELECT COUNT(*) FROM user_liked_videos WHERE liked_videos_id = :videoId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("videoId", videoId);
        return ((Number) query.getSingleResult()).longValue();
    }
    
    @Override
    public long getFavoriteCount(Long videoId) {
        String sql = "SELECT COUNT(*) FROM user_favorite_videos WHERE favorite_videos_id = :videoId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("videoId", videoId);
        return ((Number) query.getSingleResult()).longValue();
    }
    
    @Override
    public long getCommentCount(Long videoId) {
        // 使用原生SQL查询评论数量
        String sql = "SELECT COUNT(*) FROM comments WHERE video_id = :videoId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("videoId", videoId);
        return ((Number) query.getSingleResult()).longValue();
    }
    
    @Override
    public long getViewCount(Long videoId) {
        Optional<Video> video = videoRepository.findById(videoId);
        return video.map(Video::getViewCount).orElse(0L);
    }
    
    @Override
    public void incrementViewCount(Long videoId) {
        String sql = "UPDATE videos SET view_count = view_count + 1 WHERE id = :videoId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("videoId", videoId);
        query.executeUpdate();
    }
} 