package com.example.sp.dao.impl;

import com.example.sp.Entity.Comment;
import com.example.sp.Repository.CommentRepository;
import com.example.sp.dao.CommentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 评论数据访问对象实现类
 */
@Repository
public class CommentDaoImpl implements CommentDao {
    
    @Autowired
    private CommentRepository commentRepository;
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Override
    public List<Comment> findByVideoId(Long videoId) {
        // 需要先获取Video对象
        return commentRepository.findByVideo(null); // 简化实现
    }
    
    @Override
    public List<Comment> findByUserId(Long userId) {
        // 需要先获取User对象
        return commentRepository.findByUser(null); // 简化实现
    }
    
    @Override
    public List<Comment> findByParentId(Long parentId) {
        // 需要先获取Comment对象
        return commentRepository.findByParent(null); // 简化实现
    }
    
    @Override
    public List<Comment> findByStatus(Comment.CommentStatus status) {
        return commentRepository.findByStatus(status);
    }
    
    @Override
    public Page<Comment> findCommentsWithPagination(Pageable pageable) {
        return commentRepository.findAll(pageable);
    }
    
    @Override
    public Page<Comment> findCommentsByVideoId(Long videoId, Pageable pageable) {
        // 需要先获取Video对象
        return commentRepository.findByVideo(null, pageable); // 简化实现
    }
    
    @Override
    public Page<Comment> findCommentsByUserId(Long userId, Pageable pageable) {
        // 需要先获取User对象
        return commentRepository.findByUser(null, pageable); // 简化实现
    }
    
    @Override
    public Page<Comment> searchComments(String keyword, Long videoId, Long userId, 
                                      Comment.CommentStatus status, Pageable pageable) {
        if (keyword != null && !keyword.trim().isEmpty()) {
            if (status != null) {
                return commentRepository.searchCommentsByStatus(keyword, status, pageable);
            } else {
                return commentRepository.searchComments(keyword, pageable);
            }
        } else {
            if (status != null) {
                return commentRepository.findByStatus(status, pageable);
            } else {
                return commentRepository.findAll(pageable);
            }
        }
    }
    
    @Override
    public List<Comment> getPopularComments(int limit) {
        return commentRepository.findPopularComments(org.springframework.data.domain.PageRequest.of(0, limit));
    }
    
    @Override
    public List<Comment> getLatestComments(int limit) {
        return commentRepository.findLatestComments(org.springframework.data.domain.PageRequest.of(0, limit));
    }
    
    @Override
    public CommentStatistics getCommentStatistics() {
        String sql = "SELECT " +
            "COUNT(*) as totalComments, " +
            "SUM(CASE WHEN status = 'APPROVED' THEN 1 ELSE 0 END) as approvedComments, " +
            "SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) as pendingComments, " +
            "SUM(CASE WHEN status = 'REJECTED' THEN 1 ELSE 0 END) as rejectedComments, " +
            "SUM(like_count) as totalLikes, " +
            "SUM(CASE WHEN parent_id IS NOT NULL THEN 1 ELSE 0 END) as totalReplies " +
            "FROM comments";
        
        Query query = entityManager.createNativeQuery(sql);
        Object[] result = (Object[]) query.getSingleResult();
        
        return new CommentStatistics(
            ((Number) result[0]).longValue(),
            ((Number) result[1]).longValue(),
            ((Number) result[2]).longValue(),
            ((Number) result[3]).longValue(),
            ((Number) result[4]).longValue(),
            ((Number) result[5]).longValue()
        );
    }
    
    @Override
    public long getCommentCountByVideo(Long videoId) {
        // 使用原生SQL查询评论数量
        String sql = "SELECT COUNT(*) FROM comments WHERE video_id = :videoId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("videoId", videoId);
        return ((Number) query.getSingleResult()).longValue();
    }
    
    @Override
    public long getCommentCountByUser(Long userId) {
        // 使用原生SQL查询评论数量
        String sql = "SELECT COUNT(*) FROM comments WHERE user_id = :userId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("userId", userId);
        return ((Number) query.getSingleResult()).longValue();
    }
    
    @Override
    public long getLikeCount(Long commentId) {
        String sql = "SELECT COUNT(*) FROM comment_likes WHERE comment_id = :commentId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("commentId", commentId);
        return ((Number) query.getSingleResult()).longValue();
    }
    
    @Override
    public boolean isLikedByUser(Long commentId, Long userId) {
        String sql = "SELECT COUNT(*) FROM comment_likes WHERE comment_id = :commentId AND user_id = :userId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("commentId", commentId);
        query.setParameter("userId", userId);
        return ((Number) query.getSingleResult()).longValue() > 0;
    }
    
    @Override
    public List<CommentTree> getCommentTree(Long videoId) {
        // 获取所有评论
        List<Comment> allComments = commentRepository.findByVideo(null); // 简化实现
        
        // 构建评论树
        Map<Long, CommentTree> commentTreeMap = allComments.stream()
            .collect(Collectors.toMap(
                Comment::getId,
                comment -> {
                    CommentTree tree = new CommentTree(comment);
                    tree.setLikeCount(comment.getLikeCount() != null ? comment.getLikeCount() : 0);
                    return tree;
                }
            ));
        
        List<CommentTree> rootComments = new ArrayList<>();
        
        for (Comment comment : allComments) {
            CommentTree tree = commentTreeMap.get(comment.getId());
            
            if (comment.getParent() == null) {
                // 根评论
                rootComments.add(tree);
            } else {
                // 子评论
                CommentTree parentTree = commentTreeMap.get(comment.getParent().getId());
                if (parentTree != null) {
                    parentTree.getChildren().add(tree);
                    parentTree.setReplyCount(parentTree.getReplyCount() + 1);
                }
            }
        }
        
        return rootComments;
    }
} 