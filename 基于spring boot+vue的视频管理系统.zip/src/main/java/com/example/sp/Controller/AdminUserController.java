package com.example.sp.Controller;

import com.example.sp.Entity.User;
import com.example.sp.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/users")
@CrossOrigin(origins = "*")
public class AdminUserController {

    @Autowired
    private UserService userService;

    /**
     * 获取用户列表
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String role,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate) {
        
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<User> userPage;
            
            if (keyword != null && !keyword.trim().isEmpty()) {
                userPage = userService.searchUsers(keyword, pageable);
            } else {
                userPage = userService.findAllUsers(pageable);
            }
            
            Map<String, Object> response = new HashMap<>();
            response.put("content", userPage.getContent());
            response.put("totalElements", userPage.getTotalElements());
            response.put("totalPages", userPage.getTotalPages());
            response.put("currentPage", page);
            response.put("size", size);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "获取用户列表失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 创建用户
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> createUser(@RequestBody User user) {
        try {
            User savedUser = userService.registerUser(user);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "用户创建成功");
            response.put("user", savedUser);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "创建用户失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 更新用户
     */
    @PutMapping("/{id}")
    public ResponseEntity<Map<String, Object>> updateUser(@PathVariable Long id, @RequestBody User user) {
        try {
            User existingUser = userService.findUserById(id)
                    .orElseThrow(() -> new RuntimeException("用户不存在"));
            
            // 更新用户信息
            if (user.getNickname() != null) {
                existingUser.setNickname(user.getNickname());
            }
            if (user.getEmail() != null) {
                existingUser.setEmail(user.getEmail());
            }
            if (user.getRole() != null) {
                existingUser.setRole(user.getRole());
            }
            if (user.getStatus() != null) {
                existingUser.setStatus(user.getStatus());
            }
            
            User updatedUser = userService.saveUser(existingUser);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "用户更新成功");
            response.put("user", updatedUser);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "更新用户失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 删除用户
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Object>> deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUserById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "用户删除成功");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "删除用户失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 重置用户密码
     */
    @PostMapping("/{id}/reset-password")
    public ResponseEntity<Map<String, Object>> resetPassword(@PathVariable Long id) {
        try {
            userService.resetPassword(id, "123456"); // 默认密码
            Map<String, Object> response = new HashMap<>();
            response.put("message", "密码重置成功");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "密码重置失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 切换用户状态
     */
    @PostMapping("/{id}/toggle-status")
    public ResponseEntity<Map<String, Object>> toggleStatus(@PathVariable Long id) {
        try {
            User user = userService.findUserById(id)
                    .orElseThrow(() -> new RuntimeException("用户不存在"));
            
            User.UserStatus newStatus = user.getStatus() == User.UserStatus.ACTIVE ? 
                    User.UserStatus.INACTIVE : User.UserStatus.ACTIVE;
            user.setStatus(newStatus);
            
            User updatedUser = userService.saveUser(user);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "用户状态更新成功");
            response.put("user", updatedUser);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "状态更新失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 批量启用用户
     */
    @PostMapping("/batch-enable")
    public ResponseEntity<Map<String, Object>> batchEnable(@RequestBody List<Long> ids) {
        try {
            userService.batchUpdateUserStatus(ids, User.UserStatus.ACTIVE);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "批量启用成功");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "批量启用失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 批量禁用用户
     */
    @PostMapping("/batch-disable")
    public ResponseEntity<Map<String, Object>> batchDisable(@RequestBody List<Long> ids) {
        try {
            userService.batchUpdateUserStatus(ids, User.UserStatus.INACTIVE);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "批量禁用成功");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "批量禁用失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 批量删除用户
     */
    @PostMapping("/batch-delete")
    public ResponseEntity<Map<String, Object>> batchDelete(@RequestBody List<Long> ids) {
        try {
            userService.batchDeleteUsers(ids);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "批量删除成功");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("error", "批量删除失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
} 