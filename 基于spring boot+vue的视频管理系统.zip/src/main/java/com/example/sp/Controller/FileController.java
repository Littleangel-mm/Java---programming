package com.example.sp.Controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/files")
@CrossOrigin(origins = "*")
public class FileController {
    
    @Value("${file.upload.path:uploads/}")
    private String uploadPath;
    
    @Value("${file.upload.max-size:5242880}") // 5MB
    private long maxFileSize;
    
    @Value("${file.upload.video.max-size:104857600}") // 100MB
    private long maxVideoSize;
    
    @PostMapping("/upload")
    public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            // 检查文件是否为空
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "文件不能为空"));
            }
            
            // 检查文件类型
            String contentType = file.getContentType();
            if (contentType == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "无法识别文件类型"));
            }
            
            // 检查文件大小
            if (contentType.startsWith("video/")) {
                // 视频文件
                if (file.getSize() > maxVideoSize) {
                    return ResponseEntity.badRequest().body(Map.of("error", "视频文件大小不能超过100MB"));
                }
            } else if (contentType.startsWith("image/")) {
                // 图片文件
                if (file.getSize() > maxFileSize) {
                    return ResponseEntity.badRequest().body(Map.of("error", "图片文件大小不能超过5MB"));
                }
            } else {
                return ResponseEntity.badRequest().body(Map.of("error", "不支持的文件类型，只能上传图片或视频文件"));
            }
            
            // 创建上传目录
            String datePath = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
            String fullUploadPath = uploadPath + datePath;
            Path uploadDir = Paths.get(fullUploadPath);
            if (!Files.exists(uploadDir)) {
                Files.createDirectories(uploadDir);
            }
            
            // 生成唯一文件名
            String originalFilename = file.getOriginalFilename();
            String extension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }
            String filename = UUID.randomUUID().toString() + extension;
            
            // 保存文件
            Path filePath = uploadDir.resolve(filename);
            Files.copy(file.getInputStream(), filePath);
            
            // 返回文件URL
            String fileUrl = "/api/files/" + datePath + "/" + filename;
            
            Map<String, Object> response = new HashMap<>();
            response.put("url", fileUrl);
            response.put("filePath", datePath + "/" + filename); // 相对路径，用于数据库存储
            response.put("filename", filename);
            response.put("originalName", originalFilename);
            response.put("size", file.getSize());
            response.put("contentType", contentType);
            
            return ResponseEntity.ok(response);
            
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "文件上传失败: " + e.getMessage()));
        }
    }
    
    @PostMapping("/upload/video")
    public ResponseEntity<?> uploadVideo(@RequestParam("file") MultipartFile file) {
        try {
            // 检查文件是否为空
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "视频文件不能为空"));
            }
            
            // 检查文件类型
            String contentType = file.getContentType();
            if (contentType == null || !contentType.startsWith("video/")) {
                return ResponseEntity.badRequest().body(Map.of("error", "只能上传视频文件"));
            }
            
            // 检查文件大小
            if (file.getSize() > maxVideoSize) {
                return ResponseEntity.badRequest().body(Map.of("error", "视频文件大小不能超过100MB"));
            }
            
            // 创建上传目录
            String datePath = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
            String fullUploadPath = uploadPath + "videos/" + datePath;
            Path uploadDir = Paths.get(fullUploadPath);
            if (!Files.exists(uploadDir)) {
                Files.createDirectories(uploadDir);
            }
            
            // 生成唯一文件名
            String originalFilename = file.getOriginalFilename();
            String extension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }
            String filename = UUID.randomUUID().toString() + extension;
            
            // 保存文件
            Path filePath = uploadDir.resolve(filename);
            Files.copy(file.getInputStream(), filePath);
            
            // 返回文件URL
            String fileUrl = "/api/files/videos/" + datePath + "/" + filename;
            
            Map<String, Object> response = new HashMap<>();
            response.put("url", fileUrl);
            response.put("filePath", "videos/" + datePath + "/" + filename); // 相对路径，用于数据库存储
            response.put("filename", filename);
            response.put("originalName", originalFilename);
            response.put("size", file.getSize());
            response.put("contentType", contentType);
            response.put("format", extension.replace(".", ""));
            
            return ResponseEntity.ok(response);
            
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "视频上传失败: " + e.getMessage()));
        }
    }
    
    @GetMapping("/{year}/{month}/{day}/{filename}")
    public ResponseEntity<?> getFile(@PathVariable String year,
                                   @PathVariable String month,
                                   @PathVariable String day,
                                   @PathVariable String filename) {
        try {
            String filePath = uploadPath + year + "/" + month + "/" + day + "/" + filename;
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                return ResponseEntity.notFound().build();
            }
            
            byte[] fileContent = Files.readAllBytes(path);
            String contentType = Files.probeContentType(path);
            
            return ResponseEntity.ok()
                    .header("Content-Type", contentType)
                    .body(fileContent);
                    
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "文件读取失败: " + e.getMessage()));
        }
    }
    
    @GetMapping("/videos/{year}/{month}/{day}/{filename}")
    public ResponseEntity<?> getVideoFile(@PathVariable String year,
                                        @PathVariable String month,
                                        @PathVariable String day,
                                        @PathVariable String filename) {
        try {
            String filePath = uploadPath + "videos/" + year + "/" + month + "/" + day + "/" + filename;
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                return ResponseEntity.notFound().build();
            }
            
            byte[] fileContent = Files.readAllBytes(path);
            String contentType = Files.probeContentType(path);
            
            return ResponseEntity.ok()
                    .header("Content-Type", contentType)
                    .body(fileContent);
                    
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "视频文件读取失败: " + e.getMessage()));
        }
    }
    
    @DeleteMapping("/{year}/{month}/{day}/{filename}")
    public ResponseEntity<?> deleteFile(@PathVariable String year,
                                      @PathVariable String month,
                                      @PathVariable String day,
                                      @PathVariable String filename) {
        try {
            String filePath = uploadPath + year + "/" + month + "/" + day + "/" + filename;
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                return ResponseEntity.notFound().build();
            }
            
            Files.delete(path);
            
            return ResponseEntity.ok(Map.of("message", "文件删除成功"));
            
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "文件删除失败: " + e.getMessage()));
        }
    }
    
    @DeleteMapping("/videos/{year}/{month}/{day}/{filename}")
    public ResponseEntity<?> deleteVideoFile(@PathVariable String year,
                                           @PathVariable String month,
                                           @PathVariable String day,
                                           @PathVariable String filename) {
        try {
            String filePath = uploadPath + "videos/" + year + "/" + month + "/" + day + "/" + filename;
            Path path = Paths.get(filePath);
            
            if (!Files.exists(path)) {
                return ResponseEntity.notFound().build();
            }
            
            Files.delete(path);
            
            return ResponseEntity.ok(Map.of("message", "视频文件删除成功"));
            
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "视频文件删除失败: " + e.getMessage()));
        }
    }
} 