package com.example.sp.Controller;

import com.example.sp.Entity.Comment;
import com.example.sp.Entity.User;
import com.example.sp.Entity.Video;
import com.example.sp.Service.CommentService;
import com.example.sp.Service.UserService;
import com.example.sp.Service.VideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/comments")
@CrossOrigin(origins = "*")
public class CommentController {
    
    @Autowired
    private CommentService commentService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private VideoService videoService;
    
    // 添加评论
    @PostMapping
    public ResponseEntity<?> addComment(@Valid @RequestBody Comment comment, 
                                       @RequestParam Long userId, 
                                       @RequestParam Long videoId) {
        try {
            User user = userService.findUserById(userId)
                    .orElseThrow(() -> new RuntimeException("用户不存在"));
            Video video = videoService.findVideoById(videoId)
                    .orElseThrow(() -> new RuntimeException("视频不存在"));
            
            Comment savedComment = commentService.addComment(comment, user, video);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedComment);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取所有评论（分页）
    @GetMapping
    public ResponseEntity<Page<Comment>> getAllComments(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Comment> comments = commentService.findAllComments(pageable);
        return ResponseEntity.ok(comments);
    }
    
    // 支持按视频ID分页查询评论
    @GetMapping("/page")
    public ResponseEntity<Page<Comment>> listComments(
            @RequestParam(value = "videoId", required = false) Long videoId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Comment> comments;
        if (videoId != null) {
            comments = commentService.findCommentsByVideoId(videoId, pageable);
        } else {
            comments = commentService.findAllComments(pageable);
        }
        return ResponseEntity.ok(comments);
    }
    
    // 根据ID获取评论
    @GetMapping("/{id}")
    public ResponseEntity<?> getCommentById(@PathVariable Long id) {
        return commentService.findCommentById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    // 更新评论
    @PutMapping("/{id}")
    public ResponseEntity<?> updateComment(@PathVariable Long id, @RequestBody Comment commentDetails) {
        try {
            Comment updatedComment = commentService.updateComment(id, commentDetails);
            return ResponseEntity.ok(updatedComment);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 删除评论
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteComment(@PathVariable Long id) {
        try {
            commentService.deleteCommentById(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "评论删除成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 评论审核 - 通过
    @PutMapping("/{id}/approve")
    public ResponseEntity<?> approveComment(@PathVariable Long id, @RequestParam Long approvedBy) {
        try {
            Comment approvedComment = commentService.approveComment(id, approvedBy);
            return ResponseEntity.ok(approvedComment);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 评论审核 - 拒绝
    @PutMapping("/{id}/reject")
    public ResponseEntity<?> rejectComment(
            @PathVariable Long id, 
            @RequestParam Long rejectedBy,
            @RequestBody Map<String, String> request) {
        
        String reason = request.get("reason");
        try {
            Comment rejectedComment = commentService.rejectComment(id, rejectedBy, reason);
            return ResponseEntity.ok(rejectedComment);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 根据视频获取评论
    @GetMapping("/video/{videoId}")
    public ResponseEntity<List<Comment>> getCommentsByVideo(
            @PathVariable Long videoId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        try {
            Video video = videoService.findVideoById(videoId)
                    .orElseThrow(() -> new RuntimeException("视频不存在"));
            
            Pageable pageable = PageRequest.of(page, size);
            List<Comment> comments = commentService.findCommentsByVideo(video, pageable).getContent();
            return ResponseEntity.ok(comments);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    // 根据用户获取评论
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Comment>> getCommentsByUser(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        try {
            User user = userService.findUserById(userId)
                    .orElseThrow(() -> new RuntimeException("用户不存在"));
            
            Pageable pageable = PageRequest.of(page, size);
            List<Comment> comments = commentService.findCommentsByUser(user, pageable).getContent();
            return ResponseEntity.ok(comments);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    // 根据状态获取评论
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Comment>> getCommentsByStatus(
            @PathVariable String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        try {
            Comment.CommentStatus commentStatus = Comment.CommentStatus.valueOf(status.toUpperCase());
            Pageable pageable = PageRequest.of(page, size);
            List<Comment> comments = commentService.findCommentsByStatus(commentStatus, pageable).getContent();
            return ResponseEntity.ok(comments);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    // 用户点赞评论
    @PostMapping("/{commentId}/like")
    public ResponseEntity<?> likeComment(@PathVariable Long commentId, @RequestParam Long userId) {
        try {
            commentService.likeComment(userId, commentId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "点赞成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 用户取消点赞评论
    @DeleteMapping("/{commentId}/like")
    public ResponseEntity<?> unlikeComment(@PathVariable Long commentId, @RequestParam Long userId) {
        try {
            commentService.unlikeComment(userId, commentId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "取消点赞成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 检查用户是否点赞评论
    @GetMapping("/{commentId}/liked")
    public ResponseEntity<?> isLikedByUser(@PathVariable Long commentId, @RequestParam Long userId) {
        try {
            boolean isLiked = commentService.isLikedByUser(userId, commentId);
            Map<String, Boolean> response = new HashMap<>();
            response.put("isLiked", isLiked);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取用户点赞的评论
    @GetMapping("/user/{userId}/liked")
    public ResponseEntity<List<Comment>> getLikedCommentsByUser(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Comment> comments = commentService.findLikedCommentsByUser(userId, pageable);
        return ResponseEntity.ok(comments);
    }
    
    // 获取评论树
    @GetMapping("/video/{videoId}/tree")
    public ResponseEntity<List<Comment>> getCommentTreeByVideo(@PathVariable Long videoId) {
        try {
            Video video = videoService.findVideoById(videoId)
                    .orElseThrow(() -> new RuntimeException("视频不存在"));
            
            List<Comment> comments = commentService.findCommentTreeByVideo(video);
            return ResponseEntity.ok(comments);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    // 获取评论回复
    @GetMapping("/{commentId}/replies")
    public ResponseEntity<List<Comment>> getCommentReplies(@PathVariable Long commentId) {
        try {
            Comment parentComment = commentService.findCommentById(commentId)
                    .orElseThrow(() -> new RuntimeException("评论不存在"));
            
            List<Comment> replies = commentService.findCommentReplies(parentComment);
            return ResponseEntity.ok(replies);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    // 获取评论深度
    @GetMapping("/{commentId}/depth")
    public ResponseEntity<?> getCommentDepth(@PathVariable Long commentId) {
        try {
            Comment comment = commentService.findCommentById(commentId)
                    .orElseThrow(() -> new RuntimeException("评论不存在"));
            int depth = commentService.getCommentDepth(comment);
            Map<String, Integer> response = new HashMap<>();
            response.put("depth", depth);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取热门评论
    @GetMapping("/video/{videoId}/hot")
    public ResponseEntity<List<Comment>> getHotCommentsByVideo(
            @PathVariable Long videoId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        try {
            Video video = videoService.findVideoById(videoId)
                    .orElseThrow(() -> new RuntimeException("视频不存在"));
            
            Pageable pageable = PageRequest.of(page, size);
            List<Comment> comments = commentService.findHotCommentsByVideo(video, pageable);
            return ResponseEntity.ok(comments);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    // 获取热门评论
    @GetMapping("/hot")
    public ResponseEntity<List<Comment>> getHotComments(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Comment> comments = commentService.findHotComments(pageable);
        return ResponseEntity.ok(comments);
    }
    
    // 搜索评论
    @GetMapping("/search")
    public ResponseEntity<Page<Comment>> searchComments(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Comment> comments = commentService.searchComments(keyword, pageable);
        return ResponseEntity.ok(comments);
    }
    
    // 获取待审核评论
    @GetMapping("/pending")
    public ResponseEntity<List<Comment>> getPendingComments(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Comment> comments = commentService.findPendingComments(pageable);
        return ResponseEntity.ok(comments);
    }
    
    // 获取被拒绝评论
    @GetMapping("/rejected")
    public ResponseEntity<List<Comment>> getRejectedComments(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Comment> comments = commentService.findRejectedComments(pageable);
        return ResponseEntity.ok(comments);
    }
    
    // 获取已审核评论
    @GetMapping("/approved")
    public ResponseEntity<List<Comment>> getApprovedComments(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Comment> comments = commentService.findApprovedComments(pageable);
        return ResponseEntity.ok(comments);
    }
    
    // 批量审核评论
    @PutMapping("/batch/approve")
    public ResponseEntity<?> batchApproveComments(
            @RequestBody Map<String, Object> request) {
        
        @SuppressWarnings("unchecked")
        List<Long> commentIds = (List<Long>) request.get("commentIds");
        Long approvedBy = Long.valueOf(request.get("approvedBy").toString());
        
        try {
            commentService.batchApproveComments(commentIds, approvedBy);
            Map<String, String> response = new HashMap<>();
            response.put("message", "批量审核成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 批量拒绝评论
    @PutMapping("/batch/reject")
    public ResponseEntity<?> batchRejectComments(
            @RequestBody Map<String, Object> request) {
        
        @SuppressWarnings("unchecked")
        List<Long> commentIds = (List<Long>) request.get("commentIds");
        Long rejectedBy = Long.valueOf(request.get("rejectedBy").toString());
        String reason = (String) request.get("reason");
        
        try {
            commentService.batchRejectComments(commentIds, rejectedBy, reason);
            Map<String, String> response = new HashMap<>();
            response.put("message", "批量拒绝成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 批量删除评论
    @DeleteMapping("/batch")
    public ResponseEntity<?> batchDeleteComments(@RequestBody List<Long> commentIds) {
        try {
            commentService.batchDeleteComments(commentIds);
            Map<String, String> response = new HashMap<>();
            response.put("message", "批量删除成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 标记评论为不当内容
    @PutMapping("/{commentId}/flag")
    public ResponseEntity<?> flagCommentAsInappropriate(
            @PathVariable Long commentId,
            @RequestParam Long flaggedBy,
            @RequestBody Map<String, String> request) {
        
        String reason = request.get("reason");
        try {
            commentService.flagCommentAsInappropriate(commentId, flaggedBy, reason);
            Map<String, String> response = new HashMap<>();
            response.put("message", "评论已标记为不当内容");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取被标记的评论
    @GetMapping("/flagged")
    public ResponseEntity<List<Comment>> getFlaggedComments(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Comment> comments = commentService.findFlaggedComments(pageable);
        return ResponseEntity.ok(comments);
    }
    
    // 获取评论统计信息
    @GetMapping("/stats")
    public ResponseEntity<?> getCommentStats() {
        Map<String, Object> stats = new HashMap<>();
        
        // 这里需要根据实际的CommentStatus枚举值来统计
        // stats.put("totalComments", commentService.countCommentsByStatus(Comment.CommentStatus.APPROVED));
        // stats.put("pendingComments", commentService.countCommentsByStatus(Comment.CommentStatus.PENDING));
        // stats.put("rejectedComments", commentService.countCommentsByStatus(Comment.CommentStatus.REJECTED));
        
        return ResponseEntity.ok(stats);
    }
} 