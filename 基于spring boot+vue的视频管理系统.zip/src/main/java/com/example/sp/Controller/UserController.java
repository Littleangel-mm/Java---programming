package com.example.sp.Controller;

import com.example.sp.Entity.User;
import com.example.sp.Service.UserService;
import com.example.sp.config.ApiResponse;
import com.example.sp.dto.RegisterRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/users")
@CrossOrigin(origins = "*")
public class UserController {
    
    @Autowired
    private UserService userService;
    
    // 用户注册
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@Valid @RequestBody RegisterRequest registerRequest) {
        try {
            System.out.println("注册请求 - 用户名: " + registerRequest.getUsername() + ", 邮箱: " + registerRequest.getEmail());
            
            // 创建User对象
            User user = new User();
            user.setUsername(registerRequest.getUsername());
            user.setEmail(registerRequest.getEmail());
            user.setPassword(registerRequest.getPassword());
            user.setNickname(registerRequest.getNickname());
            
            User registeredUser = userService.registerUser(user);
            
            // 构建与登录一致的响应格式
            Map<String, Object> loginData = new HashMap<>();
            loginData.put("token", "dummy-token-" + System.currentTimeMillis()); // 临时token
            Map<String, Object> userMap = new HashMap<>();
            userMap.put("id", registeredUser.getId());
            userMap.put("username", registeredUser.getUsername());
            userMap.put("email", registeredUser.getEmail());
            userMap.put("nickname", registeredUser.getNickname() != null ? registeredUser.getNickname() : registeredUser.getUsername());
            userMap.put("role", registeredUser.getRole().toString());
            userMap.put("avatar", registeredUser.getAvatar());
            loginData.put("user", userMap);
            
            System.out.println("注册成功 - 用户: " + registeredUser.getUsername());
            return ResponseEntity.ok(ApiResponse.success("注册成功", loginData));
        } catch (RuntimeException e) {
            System.out.println("注册失败 - 错误: " + e.getMessage());
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage(), 400));
        } catch (Exception e) {
            System.out.println("注册异常 - 错误: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("服务器内部错误: " + e.getMessage(), 500));
        }
    }
    
    // 用户登录
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody Map<String, String> loginRequest) {
        // 参数验证
        if (loginRequest == null) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("请求参数不能为空", 400));
        }
        
        String username = loginRequest.get("username");
        String password = loginRequest.get("password");
        
        if (username == null || username.trim().isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("用户名不能为空", 400));
        }
        
        if (password == null || password.trim().isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("密码不能为空", 400));
        }
        
        // 调试信息
        System.out.println("登录请求 - 用户名: " + username + ", 密码长度: " + password.length());
        
        if (userService.validateUserCredentials(username, password)) {
            // 获取用户信息
            Optional<User> userOpt = userService.findUserByUsername(username);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                
                // 更新最后登录时间
                userService.updateLastLoginTime(user.getId());
                userService.incrementLoginCount(user.getId());
                
                // 构建响应
                Map<String, Object> loginData = new HashMap<>();
                loginData.put("token", "dummy-token-" + System.currentTimeMillis()); // 临时token
                Map<String, Object> userMap = new HashMap<>();
                userMap.put("id", user.getId());
                userMap.put("username", user.getUsername());
                userMap.put("email", user.getEmail());
                userMap.put("nickname", user.getNickname() != null ? user.getNickname() : user.getUsername());
                userMap.put("role", user.getRole().toString());
                userMap.put("avatar", user.getAvatar());
                loginData.put("user", userMap);
                
                System.out.println("登录成功 - 用户: " + username);
                return ResponseEntity.ok(ApiResponse.success("登录成功", loginData));
            }
        }
        
        System.out.println("登录失败 - 用户名: " + username);
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(ApiResponse.error("用户名或密码错误", 401));
    }
    
    // 用户退出登录
    @PostMapping("/logout")
    public ResponseEntity<?> logoutUser() {
        try {
            // 这里可以添加token失效逻辑
            Map<String, String> response = new HashMap<>();
            response.put("message", "退出登录成功");
            return ResponseEntity.ok(ApiResponse.success("退出登录成功", response));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("退出登录失败: " + e.getMessage(), 500));
        }
    }
    
    // 获取所有用户（分页）
    @GetMapping
    public ResponseEntity<Page<User>> getAllUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir) {
        
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<User> users = userService.findAllUsers(pageable);
        return ResponseEntity.ok(users);
    }
    
    // 根据ID获取用户
    @GetMapping("/{id}")
    public ResponseEntity<?> getUserById(@PathVariable Long id) {
        return userService.findUserById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    // 根据用户名获取用户
    @GetMapping("/username/{username}")
    public ResponseEntity<?> getUserByUsername(@PathVariable String username) {
        return userService.findUserByUsername(username)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    // 根据邮箱获取用户
    @GetMapping("/email/{email}")
    public ResponseEntity<?> getUserByEmail(@PathVariable String email) {
        return userService.findUserByEmail(email)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    // 更新用户资料
    @PutMapping("/{id}/profile")
    public ResponseEntity<?> updateUserProfile(@PathVariable Long id, @RequestBody User userDetails) {
        try {
            User updatedUser = userService.updateUserProfile(id, userDetails);
            return ResponseEntity.ok(updatedUser);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 更新用户角色
    @PutMapping("/{id}/role")
    public ResponseEntity<?> updateUserRole(@PathVariable Long id, @RequestBody Map<String, String> request) {
        try {
            User.UserRole role = User.UserRole.valueOf(request.get("role"));
            User updatedUser = userService.updateUserRole(id, role);
            return ResponseEntity.ok(updatedUser);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 更新用户状态
    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateUserStatus(@PathVariable Long id, @RequestBody Map<String, String> request) {
        try {
            User.UserStatus status = User.UserStatus.valueOf(request.get("status"));
            User updatedUser = userService.updateUserStatus(id, status);
            return ResponseEntity.ok(updatedUser);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 删除用户
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUserById(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "用户删除成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 搜索用户
    @GetMapping("/search")
    public ResponseEntity<Page<User>> searchUsers(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<User> users = userService.searchUsers(keyword, pageable);
        return ResponseEntity.ok(users);
    }
    
    // 根据角色获取用户
    @GetMapping("/role/{role}")
    public ResponseEntity<List<User>> getUsersByRole(@PathVariable String role) {
        try {
            User.UserRole userRole = User.UserRole.valueOf(role.toUpperCase());
            List<User> users = userService.findUsersByRole(userRole);
            return ResponseEntity.ok(users);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    // 根据状态获取用户
    @GetMapping("/status/{status}")
    public ResponseEntity<List<User>> getUsersByStatus(@PathVariable String status) {
        try {
            User.UserStatus userStatus = User.UserStatus.valueOf(status.toUpperCase());
            List<User> users = userService.findUsersByStatus(userStatus);
            return ResponseEntity.ok(users);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    // 获取活跃用户
    @GetMapping("/active")
    public ResponseEntity<List<User>> getActiveUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "5") Integer minLoginCount) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<User> users = userService.findActiveUsers(minLoginCount, pageable);
        return ResponseEntity.ok(users);
    }
    
    // 获取最近注册的用户
    @GetMapping("/recent")
    public ResponseEntity<List<User>> getRecentUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<User> users = userService.findRecentUsers(pageable);
        return ResponseEntity.ok(users);
    }
    
    // 获取最近登录的用户
    @GetMapping("/recent-login")
    public ResponseEntity<List<User>> getRecentlyLoggedInUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<User> users = userService.findRecentlyLoggedInUsers(pageable);
        return ResponseEntity.ok(users);
    }
    
    // 关注用户
    @PostMapping("/{followerId}/follow/{followingId}")
    public ResponseEntity<?> followUser(@PathVariable Long followerId, @PathVariable Long followingId) {
        try {
            userService.followUser(followerId, followingId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "关注成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 取消关注用户
    @DeleteMapping("/{followerId}/follow/{followingId}")
    public ResponseEntity<?> unfollowUser(@PathVariable Long followerId, @PathVariable Long followingId) {
        try {
            userService.unfollowUser(followerId, followingId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "取消关注成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 检查是否关注
    @GetMapping("/{followerId}/following/{followingId}")
    public ResponseEntity<?> isFollowing(@PathVariable Long followerId, @PathVariable Long followingId) {
        try {
            boolean isFollowing = userService.isFollowing(followerId, followingId);
            Map<String, Boolean> response = new HashMap<>();
            response.put("isFollowing", isFollowing);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取用户的粉丝
    @GetMapping("/{userId}/followers")
    public ResponseEntity<List<User>> getFollowers(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<User> followers = userService.findFollowers(userId, pageable);
        return ResponseEntity.ok(followers);
    }
    
    // 获取用户关注的人
    @GetMapping("/{userId}/following")
    public ResponseEntity<List<User>> getFollowing(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<User> following = userService.findFollowing(userId, pageable);
        return ResponseEntity.ok(following);
    }
    
    // 获取粉丝数量
    @GetMapping("/{userId}/followers/count")
    public ResponseEntity<?> getFollowersCount(@PathVariable Long userId) {
        try {
            long count = userService.countFollowers(userId);
            Map<String, Long> response = new HashMap<>();
            response.put("followersCount", count);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取关注数量
    @GetMapping("/{userId}/following/count")
    public ResponseEntity<?> getFollowingCount(@PathVariable Long userId) {
        try {
            long count = userService.countFollowing(userId);
            Map<String, Long> response = new HashMap<>();
            response.put("followingCount", count);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 修改密码
    @PutMapping("/{id}/password")
    public ResponseEntity<?> changePassword(
            @PathVariable Long id,
            @RequestBody Map<String, String> request) {
        
        String oldPassword = request.get("oldPassword");
        String newPassword = request.get("newPassword");
        
        try {
            userService.changePassword(id, oldPassword, newPassword);
            Map<String, String> response = new HashMap<>();
            response.put("message", "密码修改成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 重置密码
    @PutMapping("/{id}/password/reset")
    public ResponseEntity<?> resetPassword(
            @PathVariable Long id,
            @RequestBody Map<String, String> request) {
        
        String newPassword = request.get("newPassword");
        
        try {
            userService.resetPassword(id, newPassword);
            Map<String, String> response = new HashMap<>();
            response.put("message", "密码重置成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 批量更新用户状态
    @PutMapping("/batch/status")
    public ResponseEntity<?> batchUpdateUserStatus(
            @RequestBody Map<String, Object> request) {
        
        @SuppressWarnings("unchecked")
        List<Long> userIds = (List<Long>) request.get("userIds");
        String statusStr = (String) request.get("status");
        
        try {
            User.UserStatus status = User.UserStatus.valueOf(statusStr.toUpperCase());
            userService.batchUpdateUserStatus(userIds, status);
            Map<String, String> response = new HashMap<>();
            response.put("message", "批量更新成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 批量删除用户
    @DeleteMapping("/batch")
    public ResponseEntity<?> batchDeleteUsers(@RequestBody List<Long> userIds) {
        try {
            userService.batchDeleteUsers(userIds);
            Map<String, String> response = new HashMap<>();
            response.put("message", "批量删除成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取用户统计信息
    @GetMapping("/stats")
    public ResponseEntity<?> getUserStats() {
        Map<String, Object> stats = new HashMap<>();
        
        stats.put("totalUsers", userService.countUsersByRole(User.UserRole.USER));
        stats.put("totalAdmins", userService.countUsersByRole(User.UserRole.ADMIN));
        stats.put("activeUsers", userService.countUsersByStatus(User.UserStatus.ACTIVE));
        stats.put("inactiveUsers", userService.countUsersByStatus(User.UserStatus.INACTIVE));
        stats.put("bannedUsers", userService.countUsersByStatus(User.UserStatus.BANNED));
        
        return ResponseEntity.ok(stats);
    }
    
    // 检查用户名是否存在
    @GetMapping("/check-username/{username}")
    public ResponseEntity<?> checkUsernameExists(@PathVariable String username) {
        boolean exists = userService.existsByUsername(username);
        Map<String, Boolean> response = new HashMap<>();
        response.put("exists", exists);
        return ResponseEntity.ok(response);
    }
    
    // 检查邮箱是否存在
    @GetMapping("/check-email/{email}")
    public ResponseEntity<?> checkEmailExists(@PathVariable String email) {
        boolean exists = userService.existsByEmail(email);
        Map<String, Boolean> response = new HashMap<>();
        response.put("exists", exists);
        return ResponseEntity.ok(response);
    }
} 