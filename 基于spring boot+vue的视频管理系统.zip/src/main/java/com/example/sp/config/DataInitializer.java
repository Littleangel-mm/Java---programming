package com.example.sp.config;

import com.example.sp.Entity.User;
import com.example.sp.Entity.Video;
import com.example.sp.Entity.Category;
import com.example.sp.Repository.UserRepository;
import com.example.sp.Repository.VideoRepository;
import com.example.sp.Repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class DataInitializer implements CommandLineRunner {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private VideoRepository videoRepository;
    
    @Autowired
    private CategoryRepository categoryRepository;
    
    @Override
    public void run(String... args) throws Exception {
        // 检查是否已有数据
        if (userRepository.count() == 0) {
            initializeTestData();
        }
    }
    
    private void initializeTestData() {
        System.out.println("初始化测试数据...");
        
        // 创建测试用户
        User adminUser = new User();
        adminUser.setUsername("admin");
        adminUser.setEmail("admin@example.com");
        adminUser.setPassword("123456");
        adminUser.setNickname("管理员");
        adminUser.setRole(User.UserRole.ADMIN);
        adminUser.setStatus(User.UserStatus.ACTIVE);
        adminUser.setCreatedTime(LocalDateTime.now());
        adminUser = userRepository.save(adminUser);
        
        User normalUser = new User();
        normalUser.setUsername("user");
        normalUser.setEmail("user@example.com");
        normalUser.setPassword("123456");
        normalUser.setNickname("普通用户");
        normalUser.setRole(User.UserRole.USER);
        normalUser.setStatus(User.UserStatus.ACTIVE);
        normalUser.setCreatedTime(LocalDateTime.now());
        normalUser = userRepository.save(normalUser);
        
        // 创建测试分类
        Category category1 = new Category();
        category1.setName("娱乐");
        category1.setDescription("娱乐视频");
        category1.setCreatedTime(LocalDateTime.now());
        category1 = categoryRepository.save(category1);
        
        Category category2 = new Category();
        category2.setName("教育");
        category2.setDescription("教育视频");
        category2.setCreatedTime(LocalDateTime.now());
        category2 = categoryRepository.save(category2);
        
        // 创建测试视频
        Video video1 = new Video();
        video1.setTitle("测试视频1");
        video1.setDescription("这是一个测试视频");
        video1.setFilePath("videos/2024/01/15/test-video-1.mp4");
        video1.setThumbnailUrl("thumbnails/2024/01/15/test-thumb-1.jpg");
        video1.setDuration(120L);
        video1.setViewCount(100L);
        video1.setLikeCount(10L);
        video1.setCommentCount(5L);
        video1.setStatus(Video.VideoStatus.APPROVED);
        video1.setVisibility(Video.VideoVisibility.PUBLIC);
        video1.setIsApproved(true);
        video1.setUser(normalUser);
        video1.setCategory(category1);
        video1.setCreatedTime(LocalDateTime.now());
        videoRepository.save(video1);
        
        Video video2 = new Video();
        video2.setTitle("测试视频2");
        video2.setDescription("这是另一个测试视频");
        video2.setFilePath("videos/2024/01/15/test-video-2.mp4");
        video2.setThumbnailUrl("thumbnails/2024/01/15/test-thumb-2.jpg");
        video2.setDuration(180L);
        video2.setViewCount(200L);
        video2.setLikeCount(20L);
        video2.setCommentCount(8L);
        video2.setStatus(Video.VideoStatus.PENDING);
        video2.setVisibility(Video.VideoVisibility.PUBLIC);
        video2.setIsApproved(false);
        video2.setUser(normalUser);
        video2.setCategory(category2);
        video2.setCreatedTime(LocalDateTime.now());
        videoRepository.save(video2);
        
        Video video3 = new Video();
        video3.setTitle("待审核视频");
        video3.setDescription("这是一个待审核的视频");
        video3.setFilePath("videos/2024/01/15/test-video-3.mp4");
        video3.setThumbnailUrl("thumbnails/2024/01/15/test-thumb-3.jpg");
        video3.setDuration(90L);
        video3.setViewCount(0L);
        video3.setLikeCount(0L);
        video3.setCommentCount(0L);
        video3.setStatus(Video.VideoStatus.PENDING);
        video3.setVisibility(Video.VideoVisibility.PUBLIC);
        video3.setIsApproved(false);
        video3.setUser(normalUser);
        video3.setCategory(category1);
        video3.setCreatedTime(LocalDateTime.now());
        videoRepository.save(video3);
        
        System.out.println("测试数据初始化完成！");
        System.out.println("管理员账户: admin / 123456");
        System.out.println("普通用户账户: user / 123456");
    }
} 