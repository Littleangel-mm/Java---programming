package com.example.sp.Service;

import com.example.sp.Entity.Video;
import com.example.sp.Entity.User;
import com.example.sp.Entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface VideoService {
    
    // 基本CRUD操作
    Video saveVideo(Video video);
    
    Optional<Video> findVideoById(Long id);
    
    List<Video> findAllVideos();
    
    Page<Video> findAllVideos(Pageable pageable);
    
    void deleteVideoById(Long id);
    
    // 视频上传和管理
    Video uploadVideo(Video video, User user);
    
    Video updateVideo(Long videoId, Video videoDetails);
    
    Video approveVideo(Long videoId, Long approvedBy);
    
    Video rejectVideo(Long videoId, Long rejectedBy, String reason);
    
    // 视频查询
    List<Video> findVideosByUser(User user);
    
    Page<Video> findVideosByUser(User user, Pageable pageable);
    
    List<Video> findVideosByCategory(Category category);
    
    Page<Video> findVideosByCategory(Category category, Pageable pageable);
    
    List<Video> findVideosByStatus(Video.VideoStatus status);
    
    Page<Video> findVideosByStatus(Video.VideoStatus status, Pageable pageable);
    
    List<Video> findVideosByVisibility(Video.VideoVisibility visibility);
    
    Page<Video> findVideosByVisibility(Video.VideoVisibility visibility, Pageable pageable);
    
    // 热门和推荐视频
    List<Video> findPopularVideos(Pageable pageable);
    
    List<Video> findLatestVideos(Pageable pageable);
    
    List<Video> findRecommendedVideos(Pageable pageable);
    
    List<Video> findTrendingVideos(Pageable pageable);
    
    // 搜索功能
    List<Video> searchVideos(String keyword);
    
    Page<Video> searchVideos(String keyword, Pageable pageable);
    
    List<Video> findVideosByTag(String tagName, Pageable pageable);
    
    // 用户互动
    void likeVideo(Long userId, Long videoId);
    
    void unlikeVideo(Long userId, Long videoId);
    
    void favoriteVideo(Long userId, Long videoId);
    
    void unfavoriteVideo(Long userId, Long videoId);
    
    boolean isLikedByUser(Long userId, Long videoId);
    
    boolean isFavoritedByUser(Long userId, Long videoId);
    
    Page<Video> findLikedVideosByUser(Long userId, Pageable pageable);
    
    Page<Video> findFavoriteVideosByUser(Long userId, Pageable pageable);
    
    // 视频统计
    void incrementViewCount(Long videoId);
    
    void incrementLikeCount(Long videoId);
    
    void decrementLikeCount(Long videoId);
    
    void incrementCommentCount(Long videoId);
    
    void decrementCommentCount(Long videoId);
    
    void incrementShareCount(Long videoId);
    
    void incrementFavoriteCount(Long videoId);
    
    void decrementFavoriteCount(Long videoId);
    
    // 审核管理
    Page<Video> findPendingVideos(Pageable pageable);
    
    Page<Video> findRejectedVideos(Pageable pageable);
    
    Page<Video> findApprovedVideos(Pageable pageable);
    
    // 时间范围查询
    List<Video> findVideosByDateRange(LocalDateTime startDate, LocalDateTime endDate);
    
    List<Video> findVideosByCreatedTimeAfter(LocalDateTime startTime);
    
    // 排序查询
    List<Video> findVideosByStatusOrderByViewCountDesc(Video.VideoStatus status);
    
    List<Video> findVideosByStatusOrderByLikeCountDesc(Video.VideoStatus status);
    
    List<Video> findVideosByStatusOrderByCommentCountDesc(Video.VideoStatus status);
    
    List<Video> findVideosByStatusOrderByCreatedTimeDesc(Video.VideoStatus status);
    
    // 统计查询
    long countVideosByStatus(Video.VideoStatus status);
    
    long countVideosByUser(User user);
    
    long countVideosByCategory(Category category);
    
    long countVideosByIsApproved(Boolean isApproved);
    
    long countVideosByCreatedTimeAfter(LocalDateTime startTime);
    
    // 批量操作
    void batchApproveVideos(List<Long> videoIds, Long approvedBy);
    
    void batchRejectVideos(List<Long> videoIds, Long rejectedBy, String reason);
    
    void batchDeleteVideos(List<Long> videoIds);
    
    void batchUpdateVideoStatus(List<Long> videoIds, Video.VideoStatus status);
    
    // 视频处理
    void processVideoUpload(Video video);
    
    void generateVideoThumbnail(Video video);
    
    void extractVideoMetadata(Video video);
    
    // 推荐算法
    List<Video> getPersonalizedRecommendations(Long userId, Pageable pageable);
    
    List<Video> getSimilarVideos(Long videoId, Pageable pageable);
    
    // 缓存管理
    void clearVideoCache(Long videoId);
    
    void refreshVideoStatistics(Long videoId);
    
    // 管理员统计方法
    long countAllVideos();
    
    long getTotalViews();
    
    long countTodayNewVideos();
    
    long getTodayViews();
    
    long countPendingVideos();
    
    long countReportedContent();
} 