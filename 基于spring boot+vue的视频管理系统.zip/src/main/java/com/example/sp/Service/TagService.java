package com.example.sp.Service;

import com.example.sp.Entity.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface TagService {
    
    // 基本CRUD操作
    Tag saveTag(Tag tag);
    
    Optional<Tag> findTagById(Long id);
    
    Optional<Tag> findTagByName(String name);
    
    List<Tag> findAllTags();
    
    Page<Tag> findAllTags(Pageable pageable);
    
    void deleteTagById(Long id);
    
    boolean existsByName(String name);
    
    // 标签管理
    Tag createTag(Tag tag);
    
    Tag updateTag(Long tagId, Tag tagDetails);
    
    Tag updateTagStatus(Long tagId, Boolean isActive);
    
    Tag updateTagUsageCount(Long tagId);
    
    // 标签查询
    List<Tag> findTagsByStatus(Boolean isActive);
    
    Page<Tag> findTagsByStatus(Boolean isActive, Pageable pageable);
    
    List<Tag> findActiveTags();
    
    List<Tag> findPopularTags(Pageable pageable);
    
    List<Tag> findTrendingTags(Pageable pageable);
    
    List<Tag> findTagsByUsageCountGreaterThan(Long minUsageCount);
    
    Page<Tag> findTagsByUsageCountGreaterThan(Long minUsageCount, Pageable pageable);
    
    // 排序查询
    List<Tag> findTagsOrderByName();
    
    List<Tag> findTagsOrderByUsageCount();
    
    List<Tag> findTagsOrderByCreatedTime();
    
    List<Tag> findTagsOrderByUpdatedTime();
    
    // 统计查询
    long countTagsByStatus(Boolean isActive);
    
    long countActiveTags();
    
    long countTagsByUsageCountGreaterThan(Long minUsageCount);
    
    long getTagUsageCount(Long tagId);
    
    // 搜索功能
    List<Tag> searchTags(String keyword);
    
    Page<Tag> searchTags(String keyword, Pageable pageable);
    
    List<Tag> findTagsByNameContaining(String name);
    
    Page<Tag> findTagsByNameContaining(String name, Pageable pageable);
    
    // 批量操作
    void batchUpdateTagStatus(List<Long> tagIds, Boolean isActive);
    
    void batchDeleteTags(List<Long> tagIds);
    
    void batchUpdateTagUsageCount(List<Long> tagIds);
    
    // 标签关联
    List<Tag> findTagsByVideoId(Long videoId);
    
    List<Tag> findRelatedTags(Long tagId, Pageable pageable);
    
    List<Tag> findSimilarTags(String tagName, Pageable pageable);
    
    // 标签推荐
    List<Tag> getRecommendedTags(String keyword, Pageable pageable);
    
    List<Tag> getPopularTagsForCategory(Long categoryId, Pageable pageable);
    
    // 标签统计
    void incrementTagUsageCount(Long tagId);
    
    void decrementTagUsageCount(Long tagId);
    
    void updateTagUsageStatistics();
    
    // 标签合并
    Tag mergeTags(Long targetTagId, List<Long> sourceTagIds);
    
    // 标签清理
    void cleanupUnusedTags();
    
    void removeDuplicateTags();
    
    // 标签导入导出
    List<Tag> importTags(List<Tag> tags);
    
    List<Tag> exportTags();
    
    // 标签缓存
    void refreshTagCache();
    
    void clearTagCache();
    
    // 标签验证
    boolean isValidTagName(String tagName);
    
    boolean isTagNameReserved(String tagName);
    
    // 标签别名
    List<Tag> findTagAliases(Long tagId);
    
    void addTagAlias(Long tagId, String alias);
    
    void removeTagAlias(Long tagId, String alias);
} 