package com.example.sp.Service;

import com.example.sp.Entity.Comment;
import com.example.sp.Entity.User;
import com.example.sp.Entity.Video;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface CommentService {
    
    // 基本CRUD操作
    Comment saveComment(Comment comment);
    
    Optional<Comment> findCommentById(Long id);
    
    List<Comment> findAllComments();
    
    Page<Comment> findAllComments(Pageable pageable);
    
    void deleteCommentById(Long id);
    
    // 评论管理
    Comment addComment(Comment comment, User user, Video video);
    
    Comment updateComment(Long commentId, Comment commentDetails);
    
    Comment approveComment(Long commentId, Long approvedBy);
    
    Comment rejectComment(Long commentId, Long rejectedBy, String reason);
    
    // 评论查询
    List<Comment> findCommentsByVideo(Video video);
    
    Page<Comment> findCommentsByVideo(Video video, Pageable pageable);
    
    List<Comment> findCommentsByUser(User user);
    
    Page<Comment> findCommentsByUser(User user, Pageable pageable);
    
    List<Comment> findCommentsByStatus(Comment.CommentStatus status);
    
    Page<Comment> findCommentsByStatus(Comment.CommentStatus status, Pageable pageable);
    
    List<Comment> findCommentsByParentComment(Comment parentComment);
    
    Page<Comment> findCommentsByParentComment(Comment parentComment, Pageable pageable);
    
    // 用户互动
    void likeComment(Long userId, Long commentId);
    
    void unlikeComment(Long userId, Long commentId);
    
    boolean isLikedByUser(Long userId, Long commentId);
    
    List<Comment> findLikedCommentsByUser(Long userId, Pageable pageable);
    
    // 评论统计
    void incrementLikeCount(Long commentId);
    
    void decrementLikeCount(Long commentId);
    
    void incrementReplyCount(Long commentId);
    
    void decrementReplyCount(Long commentId);
    
    // 审核管理
    List<Comment> findPendingComments(Pageable pageable);
    
    List<Comment> findRejectedComments(Pageable pageable);
    
    List<Comment> findApprovedComments(Pageable pageable);
    
    // 时间范围查询
    List<Comment> findCommentsByDateRange(LocalDateTime startDate, LocalDateTime endDate);
    
    List<Comment> findCommentsByCreatedTimeAfter(LocalDateTime startTime);
    
    // 排序查询
    List<Comment> findCommentsByStatusOrderByLikeCountDesc(Comment.CommentStatus status);
    
    List<Comment> findCommentsByStatusOrderByCreatedTimeDesc(Comment.CommentStatus status);
    
    List<Comment> findCommentsByVideoOrderByCreatedTimeDesc(Video video);
    
    List<Comment> findCommentsByVideoOrderByLikeCountDesc(Video video);
    
    // 统计查询
    long countCommentsByStatus(Comment.CommentStatus status);
    
    long countCommentsByUser(User user);
    
    long countCommentsByVideo(Video video);
    
    long countCommentsByIsApproved(Boolean isApproved);
    
    long countCommentsByCreatedTimeAfter(LocalDateTime startTime);
    
    // 批量操作
    void batchApproveComments(List<Long> commentIds, Long approvedBy);
    
    void batchRejectComments(List<Long> commentIds, Long rejectedBy, String reason);
    
    void batchDeleteComments(List<Long> commentIds);
    
    void batchUpdateCommentStatus(List<Long> commentIds, Comment.CommentStatus status);
    
    // 评论树结构
    List<Comment> findCommentTreeByVideo(Video video);
    
    List<Comment> findCommentReplies(Comment parentComment);
    
    int getCommentDepth(Comment comment);
    
    // 热门评论
    List<Comment> findHotCommentsByVideo(Video video, Pageable pageable);
    
    List<Comment> findHotComments(Pageable pageable);
    
    // 搜索功能
    List<Comment> searchComments(String keyword);
    
    Page<Comment> searchComments(String keyword, Pageable pageable);
    
    // 评论通知
    void notifyCommentReply(Comment comment, Comment parentComment);
    
    void notifyCommentLike(Comment comment, User liker);
    
    // 内容审核
    boolean isCommentContentAppropriate(String content);
    
    void flagCommentAsInappropriate(Long commentId, Long flaggedBy, String reason);
    
    List<Comment> findFlaggedComments(Pageable pageable);
    
    // 管理员统计方法
    long countAllComments();
    
    long countTodayComments();
    
    long countPendingComments();

    Page<Comment> findCommentsByVideoId(Long videoId, Pageable pageable);
} 