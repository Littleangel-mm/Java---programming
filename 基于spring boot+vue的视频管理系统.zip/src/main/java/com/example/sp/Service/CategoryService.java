package com.example.sp.Service;

import com.example.sp.Entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface CategoryService {
    
    // 基本CRUD操作
    Category saveCategory(Category category);
    
    Optional<Category> findCategoryById(Long id);
    
    Optional<Category> findCategoryByName(String name);
    
    List<Category> findAllCategories();
    
    Page<Category> findAllCategories(Pageable pageable);
    
    void deleteCategoryById(Long id);
    
    boolean existsByName(String name);
    
    // 分类管理
    Category createCategory(Category category);
    
    Category updateCategory(Long categoryId, Category categoryDetails);
    
    Category updateCategoryStatus(Long categoryId, Boolean isActive);
    
    Category updateCategorySortOrder(Long categoryId, Integer sortOrder);
    
    // 分类查询
    List<Category> findCategoriesByStatus(Boolean isActive);
    
    Page<Category> findCategoriesByStatus(Boolean isActive, Pageable pageable);
    
    List<Category> findActiveCategories();
    
    List<Category> findCategoriesByParentCategory(Category parentCategory);
    
    Page<Category> findCategoriesByParentCategory(Category parentCategory, Pageable pageable);
    
    List<Category> findRootCategories();
    
    List<Category> findLeafCategories();
    
    // 分类树结构
    List<Category> findCategoryTree();
    
    List<Category> findSubCategories(Long parentId);
    
    List<Category> findCategoryPath(Long categoryId);
    
    int getCategoryDepth(Category category);
    
    int getCategoryLevel(Long categoryId);
    
    // 排序查询
    List<Category> findCategoriesOrderBySortOrder();
    
    List<Category> findCategoriesOrderByName();
    
    List<Category> findCategoriesOrderByCreatedTime();
    
    List<Category> findCategoriesOrderByVideoCount();
    
    // 统计查询
    long countCategoriesByStatus(Boolean isActive);
    
    long countCategoriesByParentCategory(Category parentCategory);
    
    long countRootCategories();
    
    long countLeafCategories();
    
    long countVideosInCategory(Long categoryId);
    
    // 搜索功能
    List<Category> searchCategories(String keyword);
    
    Page<Category> searchCategories(String keyword, Pageable pageable);
    
    // 批量操作
    void batchUpdateCategoryStatus(List<Long> categoryIds, Boolean isActive);
    
    void batchDeleteCategories(List<Long> categoryIds);
    
    void batchUpdateCategorySortOrder(List<Long> categoryIds, List<Integer> sortOrders);
    
    // 分类移动
    void moveCategory(Long categoryId, Long newParentId);
    
    void moveCategoriesToRoot(List<Long> categoryIds);
    
    // 分类合并
    Category mergeCategories(Long targetCategoryId, List<Long> sourceCategoryIds);
    
    // 分类复制
    Category copyCategory(Long sourceCategoryId, String newName, Long newParentId);
    
    // 分类验证
    boolean isValidCategoryHierarchy(Category category);
    
    boolean hasCircularReference(Category category);
    
    // 热门分类
    List<Category> findPopularCategories(Pageable pageable);
    
    List<Category> findTrendingCategories(Pageable pageable);
    
    // 分类缓存
    void refreshCategoryCache();
    
    void clearCategoryCache();
    
    // 分类导入导出
    List<Category> importCategories(List<Category> categories);
    
    List<Category> exportCategories();
} 