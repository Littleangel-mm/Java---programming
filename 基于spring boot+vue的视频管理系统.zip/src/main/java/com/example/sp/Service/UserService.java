package com.example.sp.Service;

import com.example.sp.Entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface UserService {
    
    // 基本CRUD操作
    User saveUser(User user);
    
    Optional<User> findUserById(Long id);
    
    Optional<User> findUserByUsername(String username);
    
    Optional<User> findUserByEmail(String email);
    
    List<User> findAllUsers();
    
    Page<User> findAllUsers(Pageable pageable);
    
    void deleteUserById(Long id);
    
    boolean existsByUsername(String username);
    
    boolean existsByEmail(String email);
    
    // 用户注册和认证
    User registerUser(User user);
    
    User updateUserProfile(Long userId, User userDetails);
    
    void updateLastLoginTime(Long userId);
    
    void incrementLoginCount(Long userId);
    
    // 角色和状态管理
    List<User> findUsersByRole(User.UserRole role);
    
    Page<User> findUsersByRole(User.UserRole role, Pageable pageable);
    
    List<User> findUsersByStatus(User.UserStatus status);
    
    Page<User> findUsersByStatus(User.UserStatus status, Pageable pageable);
    
    User updateUserRole(Long userId, User.UserRole role);
    
    User updateUserStatus(Long userId, User.UserStatus status);
    
    // 搜索和查询
    List<User> searchUsers(String keyword);
    
    Page<User> searchUsers(String keyword, Pageable pageable);
    
    List<User> findUsersByDateRange(LocalDateTime startDate, LocalDateTime endDate);
    
    List<User> findActiveUsers(Integer minLoginCount, Pageable pageable);
    
    List<User> findRecentUsers(Pageable pageable);
    
    List<User> findRecentlyLoggedInUsers(Pageable pageable);
    
    // 用户统计
    long countUsersByRole(User.UserRole role);
    
    long countUsersByStatus(User.UserStatus status);
    
    long countUsersByCreatedTimeAfter(LocalDateTime startTime);
    
    // 用户关系管理
    void followUser(Long followerId, Long followingId);
    
    void unfollowUser(Long followerId, Long followingId);
    
    boolean isFollowing(Long followerId, Long followingId);
    
    List<User> findFollowers(Long userId, Pageable pageable);
    
    List<User> findFollowing(Long userId, Pageable pageable);
    
    long countFollowers(Long userId);
    
    long countFollowing(Long userId);
    
    // 密码管理
    void changePassword(Long userId, String oldPassword, String newPassword);
    
    void resetPassword(Long userId, String newPassword);
    
    // 用户验证
    boolean validateUserCredentials(String username, String password);
    
    // 批量操作
    void batchUpdateUserStatus(List<Long> userIds, User.UserStatus status);
    
    void batchDeleteUsers(List<Long> userIds);
    
    // 管理员统计方法
    long countAllUsers();
    
    long countTodayNewUsers();
    
    long countOnlineUsers();
} 