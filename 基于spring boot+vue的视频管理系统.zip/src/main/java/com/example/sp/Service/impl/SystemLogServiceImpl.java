package com.example.sp.Service.impl;

import com.example.sp.Entity.SystemLog;
import com.example.sp.Repository.SystemLogRepository;
import com.example.sp.Service.SystemLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SystemLogServiceImpl implements SystemLogService {

    @Autowired
    private SystemLogRepository systemLogRepository;
    
    private final long systemStartTime = System.currentTimeMillis();

    @Override
    public SystemLog saveLog(SystemLog log) {
        return systemLogRepository.save(log);
    }

    @Override
    public SystemLog findById(Long id) {
        return systemLogRepository.findById(id).orElse(null);
    }

    @Override
    public Page<SystemLog> findLogs(String keyword, String level, String module, 
                                  String startTime, String endTime, Pageable pageable) {
        // 这里需要根据实际需求实现查询逻辑
        // 暂时返回所有日志
        return systemLogRepository.findAll(pageable);
    }

    @Override
    public Map<String, Long> getLogStats() {
        Map<String, Long> stats = new HashMap<>();
        
        // 获取各级别日志数量
        stats.put("infoCount", systemLogRepository.countByLevel(SystemLog.LogLevel.INFO));
        stats.put("warnCount", systemLogRepository.countByLevel(SystemLog.LogLevel.WARN));
        stats.put("errorCount", systemLogRepository.countByLevel(SystemLog.LogLevel.ERROR));
        stats.put("totalCount", systemLogRepository.count());
        
        return stats;
    }

    @Override
    public void deleteLog(Long id) {
        systemLogRepository.deleteById(id);
    }

    @Override
    public void batchDeleteLogs(List<Long> ids) {
        systemLogRepository.deleteAllById(ids);
    }

    @Override
    public void clearAllLogs() {
        systemLogRepository.deleteAll();
    }

    @Override
    public long getSystemStartTime() {
        return systemStartTime;
    }
} 