package com.example.sp.Service;

import com.example.sp.Entity.SystemLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

public interface SystemLogService {
    
    /**
     * 保存系统日志
     */
    SystemLog saveLog(SystemLog log);
    
    /**
     * 根据ID查找日志
     */
    SystemLog findById(Long id);
    
    /**
     * 分页查询日志
     */
    Page<SystemLog> findLogs(String keyword, String level, String module, 
                           String startTime, String endTime, Pageable pageable);
    
    /**
     * 获取日志统计信息
     */
    Map<String, Long> getLogStats();
    
    /**
     * 删除日志
     */
    void deleteLog(Long id);
    
    /**
     * 批量删除日志
     */
    void batchDeleteLogs(List<Long> ids);
    
    /**
     * 清空所有日志
     */
    void clearAllLogs();
    
    /**
     * 获取系统启动时间
     */
    long getSystemStartTime();
} 