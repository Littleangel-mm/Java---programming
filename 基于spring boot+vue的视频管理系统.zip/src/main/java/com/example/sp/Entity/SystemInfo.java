package com.example.sp.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "system_info")
@EntityListeners(AuditingEntityListener.class)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SystemInfo {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "config_key", unique = true)
    private String configKey;
    
    @Column(name = "config_value")
    private String configValue;
    
    private String description;
    
    @Enumerated(EnumType.STRING)
    private ConfigType type;
    
    @Column(name = "is_active")
    private Boolean isActive = true;
    
    @Column(name = "created_time", updatable = false)
    @CreatedDate
    private LocalDateTime createdTime;
    
    @Column(name = "updated_time")
    @LastModifiedDate
    private LocalDateTime updatedTime;
    
    public enum ConfigType {
        SYSTEM, FEATURE, LIMIT, NOTIFICATION, SECURITY
    }
    
    // 自定义构造函数
    public SystemInfo(String configKey, String configValue, String description) {
        this.configKey = configKey;
        this.configValue = configValue;
        this.description = description;
    }
} 