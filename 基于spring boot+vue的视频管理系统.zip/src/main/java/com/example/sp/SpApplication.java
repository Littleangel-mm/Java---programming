package com.example.sp;

import com.example.sp.Entity.User;
import com.example.sp.Service.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
// @EnableJpaAuditing  // 已在 JpaConfig.java 配置，无需重复

import java.util.Optional;

@SpringBootApplication
public class SpApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpApplication.class, args);
    }
    
    @Bean
    public CommandLineRunner initData(UserService userService) {
        return args -> {
            System.out.println("开始初始化数据...");
            long userCount = userService.countAllUsers();
            System.out.println("当前用户数量: " + userCount);
            
            // 检查admin用户是否存在，如果存在则重置密码
            Optional<User> adminOpt = userService.findUserByUsername("admin");
            if (adminOpt.isPresent()) {
                System.out.println("管理员用户已存在，重置密码...");
                User adminUser = adminOpt.get();
                adminUser.setPassword("admin123"); // 重新设置明文密码
                userService.saveUser(adminUser); // 这会重新加密密码
                System.out.println("管理员密码已重置: admin/admin123");
            } else {
                System.out.println("管理员用户不存在，创建中...");
                User adminUser = new User();
                adminUser.setUsername("admin");
                adminUser.setPassword("admin123");
                adminUser.setEmail("admin@example.com");
                adminUser.setNickname("管理员");
                adminUser.setRole(User.UserRole.ADMIN);
                adminUser.setStatus(User.UserStatus.ACTIVE);
                
                try {
                    User savedAdmin = userService.registerUser(adminUser);
                    System.out.println("管理员用户创建成功: " + savedAdmin.getUsername() + "/admin123");
                } catch (Exception e) {
                    System.out.println("管理员用户创建失败: " + e.getMessage());
                }
            }
            
            // 检查test用户是否存在
            Optional<User> testOpt = userService.findUserByUsername("test");
            if (testOpt.isPresent()) {
                System.out.println("测试用户已存在，重置密码...");
                User testUser = testOpt.get();
                testUser.setPassword("test123"); // 重新设置明文密码
                userService.saveUser(testUser); // 这会重新加密密码
                System.out.println("测试用户密码已重置: test/test123");
            } else {
                System.out.println("测试用户不存在，创建中...");
                User testUser = new User();
                testUser.setUsername("test");
                testUser.setPassword("test123");
                testUser.setEmail("test@example.com");
                testUser.setNickname("测试用户");
                testUser.setRole(User.UserRole.USER);
                testUser.setStatus(User.UserStatus.ACTIVE);
                
                try {
                    User savedTest = userService.registerUser(testUser);
                    System.out.println("测试用户创建成功: " + savedTest.getUsername() + "/test123");
                } catch (Exception e) {
                    System.out.println("测试用户创建失败: " + e.getMessage());
                }
            }
            
            System.out.println("数据初始化完成，当前用户总数: " + userService.countAllUsers());
        };
    }
}
