package com.example.sp.Repository;

import com.example.sp.Entity.SystemLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface SystemLogRepository extends JpaRepository<SystemLog, Long> {
    
    // 基本查询方法
    List<SystemLog> findByLevel(SystemLog.LogLevel level);
    
    Page<SystemLog> findByLevel(SystemLog.LogLevel level, Pageable pageable);
    
    List<SystemLog> findByType(SystemLog.LogType type);
    
    Page<SystemLog> findByType(SystemLog.LogType type, Pageable pageable);
    
    // 根据用户查询
    List<SystemLog> findByUserId(Long userId);
    
    Page<SystemLog> findByUserId(Long userId, Pageable pageable);
    
    List<SystemLog> findByUserUsername(String userUsername);
    
    Page<SystemLog> findByUserUsername(String userUsername, Pageable pageable);
    
    // 根据IP地址查询
    List<SystemLog> findByIpAddress(String ipAddress);
    
    Page<SystemLog> findByIpAddress(String ipAddress, Pageable pageable);
    
    // 根据响应状态查询
    List<SystemLog> findByResponseStatus(Integer responseStatus);
    
    Page<SystemLog> findByResponseStatus(Integer responseStatus, Pageable pageable);
    
    // 根据创建时间查询
    List<SystemLog> findByCreatedTimeBetween(LocalDateTime startTime, LocalDateTime endTime);
    
    List<SystemLog> findByCreatedTimeAfter(LocalDateTime startTime);
    
    List<SystemLog> findByCreatedTimeBefore(LocalDateTime endTime);
    
    // 根据级别和类型查询
    List<SystemLog> findByLevelAndType(SystemLog.LogLevel level, SystemLog.LogType type);
    
    Page<SystemLog> findByLevelAndType(SystemLog.LogLevel level, SystemLog.LogType type, Pageable pageable);
    
    // 根据用户和类型查询
    List<SystemLog> findByUserIdAndType(Long userId, SystemLog.LogType type);
    
    Page<SystemLog> findByUserIdAndType(Long userId, SystemLog.LogType type, Pageable pageable);
    
    // 根据创建时间排序
    List<SystemLog> findByLevelOrderByCreatedTimeDesc(SystemLog.LogLevel level);
    
    List<SystemLog> findByTypeOrderByCreatedTimeDesc(SystemLog.LogType type);
    
    Page<SystemLog> findByLevelOrderByCreatedTimeDesc(SystemLog.LogLevel level, Pageable pageable);
    
    Page<SystemLog> findByTypeOrderByCreatedTimeDesc(SystemLog.LogType type, Pageable pageable);
    
    // 统计查询
    @Query("SELECT COUNT(l) FROM SystemLog l WHERE l.level = :level")
    long countByLevel(@Param("level") SystemLog.LogLevel level);
    
    @Query("SELECT COUNT(l) FROM SystemLog l WHERE l.type = :type")
    long countByType(@Param("type") SystemLog.LogType type);
    
    @Query("SELECT COUNT(l) FROM SystemLog l WHERE l.userId = :userId")
    long countByUserId(@Param("userId") Long userId);
    
    @Query("SELECT COUNT(l) FROM SystemLog l WHERE l.responseStatus = :responseStatus")
    long countByResponseStatus(@Param("responseStatus") Integer responseStatus);
    
    @Query("SELECT COUNT(l) FROM SystemLog l WHERE l.createdTime >= :startTime")
    long countByCreatedTimeAfter(@Param("startTime") LocalDateTime startTime);
    
    @Query("SELECT COUNT(l) FROM SystemLog l WHERE l.createdTime BETWEEN :startTime AND :endTime")
    long countByCreatedTimeBetween(@Param("startTime") LocalDateTime startTime, @Param("endTime") LocalDateTime endTime);
    
    // 复杂查询
    @Query("SELECT l FROM SystemLog l WHERE l.message LIKE %:keyword% OR l.details LIKE %:keyword%")
    Page<SystemLog> searchLogs(@Param("keyword") String keyword, Pageable pageable);
    
    @Query("SELECT l FROM SystemLog l WHERE l.level = :level AND (l.message LIKE %:keyword% OR l.details LIKE %:keyword%)")
    Page<SystemLog> searchLogsByLevel(@Param("keyword") String keyword, @Param("level") SystemLog.LogLevel level, Pageable pageable);
    
    @Query("SELECT l FROM SystemLog l WHERE l.type = :type AND (l.message LIKE %:keyword% OR l.details LIKE %:keyword%)")
    Page<SystemLog> searchLogsByType(@Param("keyword") String keyword, @Param("type") SystemLog.LogType type, Pageable pageable);
    
    // 获取错误日志
    @Query("SELECT l FROM SystemLog l WHERE l.level = 'ERROR' ORDER BY l.createdTime DESC")
    List<SystemLog> findErrorLogs(Pageable pageable);
    
    // 获取警告日志
    @Query("SELECT l FROM SystemLog l WHERE l.level = 'WARN' ORDER BY l.createdTime DESC")
    List<SystemLog> findWarningLogs(Pageable pageable);
    
    // 获取用户操作日志
    @Query("SELECT l FROM SystemLog l WHERE l.userId = :userId ORDER BY l.createdTime DESC")
    List<SystemLog> findUserOperationLogs(@Param("userId") Long userId, Pageable pageable);
    
    // 获取登录日志
    @Query("SELECT l FROM SystemLog l WHERE l.type = 'LOGIN' ORDER BY l.createdTime DESC")
    List<SystemLog> findLoginLogs(Pageable pageable);
    
    // 获取登出日志
    @Query("SELECT l FROM SystemLog l WHERE l.type = 'LOGOUT' ORDER BY l.createdTime DESC")
    List<SystemLog> findLogoutLogs(Pageable pageable);
    
    // 获取系统错误日志
    @Query("SELECT l FROM SystemLog l WHERE l.level = 'ERROR' AND l.type = 'SYSTEM' ORDER BY l.createdTime DESC")
    List<SystemLog> findSystemErrorLogs(Pageable pageable);
    
    // 获取特定时间范围内的日志
    @Query("SELECT l FROM SystemLog l WHERE l.createdTime >= :startDate AND l.createdTime <= :endDate ORDER BY l.createdTime DESC")
    List<SystemLog> findLogsByDateRange(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    // 获取执行时间超过阈值的日志
    @Query("SELECT l FROM SystemLog l WHERE l.executionTime > :threshold ORDER BY l.executionTime DESC")
    List<SystemLog> findSlowOperationLogs(@Param("threshold") Long threshold, Pageable pageable);
    
    // 获取特定IP地址的日志
    @Query("SELECT l FROM SystemLog l WHERE l.ipAddress = :ipAddress ORDER BY l.createdTime DESC")
    List<SystemLog> findLogsByIpAddress(@Param("ipAddress") String ipAddress, Pageable pageable);
    
    // 获取特定URL的日志
    @Query("SELECT l FROM SystemLog l WHERE l.requestUrl LIKE %:url% ORDER BY l.createdTime DESC")
    List<SystemLog> findLogsByUrl(@Param("url") String url, Pageable pageable);
    
    // 统计各类型日志数量
    @Query("SELECT l.type, COUNT(l) FROM SystemLog l GROUP BY l.type ORDER BY COUNT(l) DESC")
    List<Object[]> countLogsByType();
    
    // 统计各级别日志数量
    @Query("SELECT l.level, COUNT(l) FROM SystemLog l GROUP BY l.level ORDER BY COUNT(l) DESC")
    List<Object[]> countLogsByLevel();
    
    // 统计各用户操作数量
    @Query("SELECT l.userUsername, COUNT(l) FROM SystemLog l WHERE l.userId IS NOT NULL GROUP BY l.userUsername ORDER BY COUNT(l) DESC")
    List<Object[]> countLogsByUser();
} 