package com.example.sp.Repository;

import com.example.sp.Entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    // 基本查询方法
    Optional<User> findByUsername(String username);
    
    Optional<User> findByEmail(String email);
    
    boolean existsByUsername(String username);
    
    boolean existsByEmail(String email);
    
    // 根据角色查询
    List<User> findByRole(User.UserRole role);
    
    Page<User> findByRole(User.UserRole role, Pageable pageable);
    
    // 根据状态查询
    List<User> findByStatus(User.UserStatus status);
    
    Page<User> findByStatus(User.UserStatus status, Pageable pageable);
    
    // 根据角色和状态查询
    List<User> findByRoleAndStatus(User.UserRole role, User.UserStatus status);
    
    Page<User> findByRoleAndStatus(User.UserRole role, User.UserStatus status, Pageable pageable);
    
    // 模糊查询
    List<User> findByUsernameContainingOrNicknameContaining(String username, String nickname);
    
    Page<User> findByUsernameContainingOrNicknameContaining(String username, String nickname, Pageable pageable);
    
    // 根据创建时间查询
    List<User> findByCreatedTimeBetween(LocalDateTime startTime, LocalDateTime endTime);
    
    // 根据最后登录时间查询
    List<User> findByLastLoginTimeBetween(LocalDateTime startTime, LocalDateTime endTime);
    
    // 根据登录次数查询
    List<User> findByLoginCountGreaterThan(Integer minLoginCount);
    
    // 根据年龄范围查询
    List<User> findByAgeBetween(Integer minAge, Integer maxAge);
    
    // 根据位置查询
    List<User> findByLocationContaining(String location);
    
    // 统计查询
    @Query("SELECT COUNT(u) FROM User u WHERE u.role = :role")
    long countByRole(@Param("role") User.UserRole role);
    
    @Query("SELECT COUNT(u) FROM User u WHERE u.status = :status")
    long countByStatus(@Param("status") User.UserStatus status);
    
    @Query("SELECT COUNT(u) FROM User u WHERE u.createdTime >= :startTime")
    long countByCreatedTimeAfter(@Param("startTime") LocalDateTime startTime);
    
    // 复杂查询
    @Query("SELECT u FROM User u WHERE u.username LIKE %:keyword% OR u.nickname LIKE %:keyword% OR u.email LIKE %:keyword%")
    Page<User> searchUsers(@Param("keyword") String keyword, Pageable pageable);
    
    @Query("SELECT u FROM User u WHERE u.createdTime >= :startDate AND u.createdTime <= :endDate ORDER BY u.createdTime DESC")
    List<User> findUsersByDateRange(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    // 获取活跃用户（登录次数大于指定值）
    @Query("SELECT u FROM User u WHERE u.loginCount > :minLoginCount ORDER BY u.loginCount DESC")
    List<User> findActiveUsers(@Param("minLoginCount") Integer minLoginCount, Pageable pageable);
    
    // 获取最近注册的用户
    @Query("SELECT u FROM User u ORDER BY u.createdTime DESC")
    List<User> findRecentUsers(Pageable pageable);
    
    // 获取最近登录的用户
    @Query("SELECT u FROM User u WHERE u.lastLoginTime IS NOT NULL ORDER BY u.lastLoginTime DESC")
    List<User> findRecentlyLoggedInUsers(Pageable pageable);
} 