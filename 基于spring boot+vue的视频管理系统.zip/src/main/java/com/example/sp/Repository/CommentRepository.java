package com.example.sp.Repository;

import com.example.sp.Entity.Comment;
import com.example.sp.Entity.User;
import com.example.sp.Entity.Video;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {
    
    // 基本查询方法
    List<Comment> findByUser(User user);
    
    Page<Comment> findByUser(User user, Pageable pageable);
    
    List<Comment> findByVideo(Video video);
    
    Page<Comment> findByVideo(Video video, Pageable pageable);
    
    // 根据状态查询
    List<Comment> findByStatus(Comment.CommentStatus status);
    
    Page<Comment> findByStatus(Comment.CommentStatus status, Pageable pageable);
    
    // 根据用户和状态查询
    List<Comment> findByUserAndStatus(User user, Comment.CommentStatus status);
    
    Page<Comment> findByUserAndStatus(User user, Comment.CommentStatus status, Pageable pageable);
    
    // 根据视频和状态查询
    List<Comment> findByVideoAndStatus(Video video, Comment.CommentStatus status);
    
    Page<Comment> findByVideoAndStatus(Video video, Comment.CommentStatus status, Pageable pageable);
    
    // 根据父评论查询（多级评论）
    List<Comment> findByParent(Comment parent);
    
    List<Comment> findByParentOrderByCreatedTimeAsc(Comment parent);
    
    // 查询顶级评论（没有父评论的）
    List<Comment> findByParentIsNull();
    
    List<Comment> findByParentIsNullOrderByCreatedTimeDesc();
    
    Page<Comment> findByParentIsNullOrderByCreatedTimeDesc(Pageable pageable);
    
    // 根据视频查询顶级评论
    List<Comment> findByVideoAndParentIsNull(Video video);
    
    List<Comment> findByVideoAndParentIsNullOrderByCreatedTimeDesc(Video video);
    
    Page<Comment> findByVideoAndParentIsNullOrderByCreatedTimeDesc(Video video, Pageable pageable);
    
    // 根据创建时间查询
    List<Comment> findByCreatedTimeBetween(LocalDateTime startTime, LocalDateTime endTime);
    
    List<Comment> findByCreatedTimeAfter(LocalDateTime startTime);
    
    // 根据点赞次数排序
    List<Comment> findByStatusOrderByLikeCountDesc(Comment.CommentStatus status);
    
    Page<Comment> findByStatusOrderByLikeCountDesc(Comment.CommentStatus status, Pageable pageable);
    
    // 根据创建时间排序
    List<Comment> findByStatusOrderByCreatedTimeDesc(Comment.CommentStatus status);
    
    Page<Comment> findByStatusOrderByCreatedTimeDesc(Comment.CommentStatus status, Pageable pageable);
    
    // 根据回复次数排序
    List<Comment> findByStatusOrderByReplyCountDesc(Comment.CommentStatus status);
    
    Page<Comment> findByStatusOrderByReplyCountDesc(Comment.CommentStatus status, Pageable pageable);
    
    // 统计查询
    @Query("SELECT COUNT(c) FROM Comment c WHERE c.status = :status")
    long countByStatus(@Param("status") Comment.CommentStatus status);
    
    @Query("SELECT COUNT(c) FROM Comment c WHERE c.user = :user")
    long countByUser(@Param("user") User user);
    
    @Query("SELECT COUNT(c) FROM Comment c WHERE c.video = :video")
    long countByVideo(@Param("video") Video video);
    
    @Query("SELECT COUNT(c) FROM Comment c WHERE c.parent IS NULL")
    long countTopLevelComments();
    
    @Query("SELECT COUNT(c) FROM Comment c WHERE c.video = :video AND c.parent IS NULL")
    long countTopLevelCommentsByVideo(@Param("video") Video video);
    
    @Query("SELECT COUNT(c) FROM Comment c WHERE c.createdTime >= :startTime")
    long countByCreatedTimeAfter(@Param("startTime") LocalDateTime startTime);
    
    // 复杂查询
    @Query("SELECT c FROM Comment c WHERE c.content LIKE %:keyword%")
    Page<Comment> searchComments(@Param("keyword") String keyword, Pageable pageable);
    
    @Query("SELECT c FROM Comment c WHERE c.status = :status AND c.content LIKE %:keyword%")
    Page<Comment> searchCommentsByStatus(@Param("keyword") String keyword, @Param("status") Comment.CommentStatus status, Pageable pageable);
    
    // 获取热门评论（点赞数最多的）
    @Query("SELECT c FROM Comment c WHERE c.status = 'ACTIVE' ORDER BY c.likeCount DESC")
    List<Comment> findPopularComments(Pageable pageable);
    
    // 获取最新评论
    @Query("SELECT c FROM Comment c WHERE c.status = 'ACTIVE' ORDER BY c.createdTime DESC")
    List<Comment> findLatestComments(Pageable pageable);
    
    // 获取用户的所有评论（包括回复）
    @Query("SELECT c FROM Comment c WHERE c.user = :user ORDER BY c.createdTime DESC")
    List<Comment> findAllCommentsByUser(@Param("user") User user, Pageable pageable);
    
    // 获取视频的所有评论（包括回复）
    @Query("SELECT c FROM Comment c WHERE c.video = :video ORDER BY c.createdTime DESC")
    List<Comment> findAllCommentsByVideo(@Param("video") Video video, Pageable pageable);
    
    // 获取评论树（顶级评论及其回复）
    @Query("SELECT c FROM Comment c WHERE c.video = :video AND c.parent IS NULL ORDER BY c.createdTime DESC")
    List<Comment> findCommentTreeByVideo(@Param("video") Video video, Pageable pageable);
    
    // 获取特定时间范围内的评论
    @Query("SELECT c FROM Comment c WHERE c.createdTime >= :startDate AND c.createdTime <= :endDate ORDER BY c.createdTime DESC")
    List<Comment> findCommentsByDateRange(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    // 获取被隐藏的评论
    @Query("SELECT c FROM Comment c WHERE c.status = 'HIDDEN' ORDER BY c.updatedTime DESC")
    Page<Comment> findHiddenComments(Pageable pageable);
    
    // 获取被删除的评论
    @Query("SELECT c FROM Comment c WHERE c.status = 'DELETED' ORDER BY c.updatedTime DESC")
    Page<Comment> findDeletedComments(Pageable pageable);
    
    // 获取评论及其回复数量
    @Query("SELECT c, COUNT(r) as replyCount FROM Comment c LEFT JOIN c.replies r WHERE c.parent IS NULL GROUP BY c ORDER BY c.createdTime DESC")
    List<Object[]> findCommentsWithReplyCount(Pageable pageable);

    Page<Comment> findByVideo_Id(Long videoId, Pageable pageable);
} 