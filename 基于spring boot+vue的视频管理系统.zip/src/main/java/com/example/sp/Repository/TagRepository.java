package com.example.sp.Repository;

import com.example.sp.Entity.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TagRepository extends JpaRepository<Tag, Long> {
    
    // 基本查询方法
    Optional<Tag> findByName(String name);
    
    boolean existsByName(String name);
    
    // 根据激活状态查询
    List<Tag> findByIsActive(Boolean isActive);
    
    Page<Tag> findByIsActive(Boolean isActive, Pageable pageable);
    
    // 根据使用次数查询
    List<Tag> findByUseCountGreaterThan(Integer minUseCount);
    
    List<Tag> findByUseCountBetween(Integer minUseCount, Integer maxUseCount);
    
    // 根据使用次数排序
    List<Tag> findByIsActiveOrderByUseCountDesc(Boolean isActive);
    
    Page<Tag> findByIsActiveOrderByUseCountDesc(Boolean isActive, Pageable pageable);
    
    // 模糊查询
    List<Tag> findByNameContainingOrDescriptionContaining(String name, String description);
    
    Page<Tag> findByNameContainingOrDescriptionContaining(String name, String description, Pageable pageable);
    
    // 根据名称列表查询
    List<Tag> findByNameIn(List<String> names);
    
    // 统计查询
    @Query("SELECT COUNT(t) FROM Tag t WHERE t.isActive = :isActive")
    long countByIsActive(@Param("isActive") Boolean isActive);
    
    @Query("SELECT COUNT(t) FROM Tag t WHERE t.useCount > :minUseCount")
    long countByUseCountGreaterThan(@Param("minUseCount") Integer minUseCount);
    
    // 复杂查询
    @Query("SELECT t FROM Tag t WHERE t.name LIKE %:keyword% OR t.description LIKE %:keyword%")
    Page<Tag> searchTags(@Param("keyword") String keyword, Pageable pageable);
    
    // 获取热门标签（使用次数最多的）
    @Query("SELECT t FROM Tag t WHERE t.isActive = true ORDER BY t.useCount DESC")
    List<Tag> findPopularTags(Pageable pageable);
    
    // 获取所有激活的标签（按使用次数排序）
    @Query("SELECT t FROM Tag t WHERE t.isActive = true ORDER BY t.useCount DESC")
    List<Tag> findAllActiveOrderByUseCount();
    
    // 获取标签及其视频数量
    @Query("SELECT t, COUNT(v) as videoCount FROM Tag t LEFT JOIN t.videos v WHERE t.isActive = true GROUP BY t ORDER BY t.useCount DESC")
    List<Object[]> findTagsWithVideoCount();
    
    // 获取有视频的标签
    @Query("SELECT DISTINCT t FROM Tag t JOIN t.videos v WHERE t.isActive = true ORDER BY t.useCount DESC")
    List<Tag> findTagsWithVideos();
    
    // 获取空标签（没有视频的标签）
    @Query("SELECT t FROM Tag t WHERE t.isActive = true AND SIZE(t.videos) = 0 ORDER BY t.useCount DESC")
    List<Tag> findEmptyTags();
    
    // 根据视频数量查询标签
    @Query("SELECT t FROM Tag t WHERE t.isActive = true AND SIZE(t.videos) > :minVideoCount ORDER BY t.useCount DESC")
    List<Tag> findTagsByVideoCount(@Param("minVideoCount") Integer minVideoCount);
    
    // 获取最近使用的标签
    @Query("SELECT t FROM Tag t WHERE t.isActive = true ORDER BY t.updatedTime DESC")
    List<Tag> findRecentlyUsedTags(Pageable pageable);
} 