package com.example.sp.Repository;

import com.example.sp.Entity.Operation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OperationRepository extends JpaRepository<Operation, Long> {
    
    // 基本查询方法
    List<Operation> findByType(Operation.OperationType type);
    
    Page<Operation> findByType(Operation.OperationType type, Pageable pageable);
    
    List<Operation> findByStatus(Operation.OperationStatus status);
    
    Page<Operation> findByStatus(Operation.OperationStatus status, Pageable pageable);
    
    // 根据操作者查询
    List<Operation> findByOperatorId(Long operatorId);
    
    Page<Operation> findByOperatorId(Long operatorId, Pageable pageable);
    
    List<Operation> findByOperatorName(String operatorName);
    
    Page<Operation> findByOperatorName(String operatorName, Pageable pageable);
    
    // 根据目标类型查询
    List<Operation> findByTargetType(Operation.TargetType targetType);
    
    Page<Operation> findByTargetType(Operation.TargetType targetType, Pageable pageable);
    
    // 根据目标ID查询
    List<Operation> findByTargetId(Long targetId);
    
    Page<Operation> findByTargetId(Long targetId, Pageable pageable);
    
    // 根据类型和状态查询
    List<Operation> findByTypeAndStatus(Operation.OperationType type, Operation.OperationStatus status);
    
    Page<Operation> findByTypeAndStatus(Operation.OperationType type, Operation.OperationStatus status, Pageable pageable);
    
    // 根据目标类型和状态查询
    List<Operation> findByTargetTypeAndStatus(Operation.TargetType targetType, Operation.OperationStatus status);
    
    Page<Operation> findByTargetTypeAndStatus(Operation.TargetType targetType, Operation.OperationStatus status, Pageable pageable);
    
    // 根据时间范围查询
    List<Operation> findByStartTimeBetween(LocalDateTime startTime, LocalDateTime endTime);
    
    List<Operation> findByEndTimeBetween(LocalDateTime startTime, LocalDateTime endTime);
    
    List<Operation> findByCreatedTimeBetween(LocalDateTime startTime, LocalDateTime endTime);
    
    // 根据开始时间查询
    List<Operation> findByStartTimeAfter(LocalDateTime startTime);
    
    List<Operation> findByStartTimeBefore(LocalDateTime endTime);
    
    // 根据结束时间查询
    List<Operation> findByEndTimeAfter(LocalDateTime startTime);
    
    List<Operation> findByEndTimeBefore(LocalDateTime endTime);
    
    // 根据创建时间排序
    List<Operation> findByTypeOrderByCreatedTimeDesc(Operation.OperationType type);
    
    List<Operation> findByStatusOrderByCreatedTimeDesc(Operation.OperationStatus status);
    
    Page<Operation> findByTypeOrderByCreatedTimeDesc(Operation.OperationType type, Pageable pageable);
    
    Page<Operation> findByStatusOrderByCreatedTimeDesc(Operation.OperationStatus status, Pageable pageable);
    
    // 统计查询
    @Query("SELECT COUNT(o) FROM Operation o WHERE o.type = :type")
    long countByType(@Param("type") Operation.OperationType type);
    
    @Query("SELECT COUNT(o) FROM Operation o WHERE o.status = :status")
    long countByStatus(@Param("status") Operation.OperationStatus status);
    
    @Query("SELECT COUNT(o) FROM Operation o WHERE o.operatorId = :operatorId")
    long countByOperatorId(@Param("operatorId") Long operatorId);
    
    @Query("SELECT COUNT(o) FROM Operation o WHERE o.targetType = :targetType")
    long countByTargetType(@Param("targetType") Operation.TargetType targetType);
    
    @Query("SELECT COUNT(o) FROM Operation o WHERE o.createdTime >= :startTime")
    long countByCreatedTimeAfter(@Param("startTime") LocalDateTime startTime);
    
    // 复杂查询
    @Query("SELECT o FROM Operation o WHERE o.title LIKE %:keyword% OR o.description LIKE %:keyword%")
    Page<Operation> searchOperations(@Param("keyword") String keyword, Pageable pageable);
    
    @Query("SELECT o FROM Operation o WHERE o.type = :type AND (o.title LIKE %:keyword% OR o.description LIKE %:keyword%)")
    Page<Operation> searchOperationsByType(@Param("keyword") String keyword, @Param("type") Operation.OperationType type, Pageable pageable);
    
    @Query("SELECT o FROM Operation o WHERE o.status = :status AND (o.title LIKE %:keyword% OR o.description LIKE %:keyword%)")
    Page<Operation> searchOperationsByStatus(@Param("keyword") String keyword, @Param("status") Operation.OperationStatus status, Pageable pageable);
    
    // 获取活跃的运营活动
    @Query("SELECT o FROM Operation o WHERE o.status = 'ACTIVE' AND (o.endTime IS NULL OR o.endTime > :currentTime) ORDER BY o.startTime DESC")
    List<Operation> findActiveOperations(@Param("currentTime") LocalDateTime currentTime, Pageable pageable);
    
    // 获取已完成的运营活动
    @Query("SELECT o FROM Operation o WHERE o.status = 'COMPLETED' ORDER BY o.endTime DESC")
    List<Operation> findCompletedOperations(Pageable pageable);
    
    // 获取待执行的运营活动
    @Query("SELECT o FROM Operation o WHERE o.status = 'PENDING' AND o.startTime > :currentTime ORDER BY o.startTime ASC")
    List<Operation> findPendingOperations(@Param("currentTime") LocalDateTime currentTime, Pageable pageable);
    
    // 获取过期的运营活动
    @Query("SELECT o FROM Operation o WHERE o.endTime IS NOT NULL AND o.endTime < :currentTime ORDER BY o.endTime DESC")
    List<Operation> findExpiredOperations(@Param("currentTime") LocalDateTime currentTime, Pageable pageable);
    
    // 获取特定类型的活跃活动
    @Query("SELECT o FROM Operation o WHERE o.type = :type AND o.status = 'ACTIVE' AND (o.endTime IS NULL OR o.endTime > :currentTime) ORDER BY o.startTime DESC")
    List<Operation> findActiveOperationsByType(@Param("type") Operation.OperationType type, @Param("currentTime") LocalDateTime currentTime, Pageable pageable);
    
    // 获取特定目标的运营活动
    @Query("SELECT o FROM Operation o WHERE o.targetType = :targetType AND o.targetId = :targetId ORDER BY o.createdTime DESC")
    List<Operation> findOperationsByTarget(@Param("targetType") Operation.TargetType targetType, @Param("targetId") Long targetId, Pageable pageable);
    
    // 获取特定时间范围内的运营活动
    @Query("SELECT o FROM Operation o WHERE o.createdTime >= :startDate AND o.createdTime <= :endDate ORDER BY o.createdTime DESC")
    List<Operation> findOperationsByDateRange(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    // 获取即将开始的运营活动
    @Query("SELECT o FROM Operation o WHERE o.status = 'PENDING' AND o.startTime BETWEEN :currentTime AND :futureTime ORDER BY o.startTime ASC")
    List<Operation> findUpcomingOperations(@Param("currentTime") LocalDateTime currentTime, @Param("futureTime") LocalDateTime futureTime, Pageable pageable);
    
    // 统计各类型运营活动数量
    @Query("SELECT o.type, COUNT(o) FROM Operation o GROUP BY o.type ORDER BY COUNT(o) DESC")
    List<Object[]> countOperationsByType();
    
    // 统计各状态运营活动数量
    @Query("SELECT o.status, COUNT(o) FROM Operation o GROUP BY o.status ORDER BY COUNT(o) DESC")
    List<Object[]> countOperationsByStatus();
    
    // 统计各操作者活动数量
    @Query("SELECT o.operatorName, COUNT(o) FROM Operation o WHERE o.operatorId IS NOT NULL GROUP BY o.operatorName ORDER BY COUNT(o) DESC")
    List<Object[]> countOperationsByOperator();
} 