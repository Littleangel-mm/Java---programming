package com.example.sp.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;

/**
 * 视频工具类
 * 用于提取视频时长、分辨率等元数据
 */
public class VideoUtils {
    
    /**
     * 提取视频时长（秒）
     * 注意：这是一个简化实现，实际项目中建议使用FFmpeg
     * 
     * @param videoPath 视频文件路径
     * @return 视频时长（秒），如果提取失败返回0
     */
    public static Long extractVideoDuration(Path videoPath) {
        try {
            // 使用ffprobe命令提取视频时长
            ProcessBuilder pb = new ProcessBuilder(
                "ffprobe",
                "-v", "quiet",
                "-show_entries", "format=duration",
                "-of", "csv=p=0",
                videoPath.toAbsolutePath().toString()
            );
            pb.redirectErrorStream(true);
            Process process = pb.start();
            java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(process.getInputStream()));
            String line = reader.readLine();
            process.waitFor();
            if (line != null) {
                double seconds = Double.parseDouble(line.trim());
                return (long) seconds;
            }
        } catch (Exception e) {
            System.err.println("提取视频时长失败: " + e.getMessage());
        }
        return 0L;
    }
    
    /**
     * 提取视频分辨率
     * 
     * @param videoPath 视频文件路径
     * @return 分辨率字符串（如：1920x1080），如果提取失败返回null
     */
    public static String extractVideoResolution(Path videoPath) {
        try {
            // 示例FFmpeg命令：
            // ffprobe -v quiet -select_streams v:0 -show_entries stream=width,height -of csv=p=0 video.mp4
            
            // 暂时返回默认值
            return null;
            
        } catch (Exception e) {
            System.err.println("提取视频分辨率失败: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * 生成视频缩略图
     * 
     * @param videoPath 视频文件路径
     * @param thumbnailPath 缩略图保存路径
     * @param time 截取时间点（秒）
     * @return 是否成功
     */
    public static boolean generateThumbnail(Path videoPath, Path thumbnailPath, int time) {
        try {
            // 示例FFmpeg命令：
            // ffmpeg -i video.mp4 -ss 00:00:10 -vframes 1 thumbnail.jpg
            
            // 暂时返回false
            return false;
            
        } catch (Exception e) {
            System.err.println("生成缩略图失败: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * 检查文件是否为有效的视频文件
     * 
     * @param file 文件对象
     * @return 是否为有效视频文件
     */
    public static boolean isValidVideoFile(File file) {
        if (!file.exists() || !file.isFile()) {
            return false;
        }
        
        String fileName = file.getName().toLowerCase();
        return fileName.endsWith(".mp4") || 
               fileName.endsWith(".avi") || 
               fileName.endsWith(".mov") || 
               fileName.endsWith(".wmv") || 
               fileName.endsWith(".flv") || 
               fileName.endsWith(".webm") || 
               fileName.endsWith(".mkv");
    }
    
    /**
     * 格式化视频时长
     * 
     * @param durationSeconds 时长（秒）
     * @return 格式化后的时长字符串（如：12:34）
     */
    public static String formatDuration(Long durationSeconds) {
        if (durationSeconds == null || durationSeconds <= 0) {
            return "00:00";
        }
        
        long minutes = durationSeconds / 60;
        long seconds = durationSeconds % 60;
        
        return String.format("%02d:%02d", minutes, seconds);
    }
    
    /**
     * 格式化文件大小
     * 
     * @param bytes 字节数
     * @return 格式化后的文件大小字符串
     */
    public static String formatFileSize(Long bytes) {
        if (bytes == null || bytes <= 0) {
            return "0 B";
        }
        
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int unitIndex = 0;
        double size = bytes;
        
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        
        return String.format("%.1f %s", size, units[unitIndex]);
    }
} 