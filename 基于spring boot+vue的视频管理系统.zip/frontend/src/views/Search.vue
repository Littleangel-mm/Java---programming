<template>
  <div class="search-page">
    <div class="search-header">
      <div class="search-input-container">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索视频..."
          size="large"
          @keyup.enter="handleSearch"
        >
          <template #append>
            <el-button @click="handleSearch">
              <el-icon><Search /></el-icon>
            </el-button>
          </template>
        </el-input>
      </div>
      
      <div class="search-filters">
        <el-select v-model="sortBy" placeholder="排序方式" @change="handleSearch">
          <el-option label="相关度" value="relevance" />
          <el-option label="最新" value="latest" />
          <el-option label="最热" value="popular" />
          <el-option label="观看次数" value="views" />
        </el-select>
        
        <el-select v-model="duration" placeholder="时长" @change="handleSearch">
          <el-option label="全部" value="" />
          <el-option label="4分钟以下" value="short" />
          <el-option label="4-20分钟" value="medium" />
          <el-option label="20分钟以上" value="long" />
        </el-select>
      </div>
    </div>
    
    <!-- 搜索结果 -->
    <div class="search-results" v-loading="loading">
      <div class="results-header">
        <h3>搜索结果</h3>
        <span class="results-count">找到 {{ total }} 个视频</span>
      </div>
      
      <div v-if="videos.length === 0 && !loading" class="no-results">
        <el-empty description="没有找到相关视频" />
      </div>
      
      <div v-else class="video-grid">
        <div
          v-for="video in videos"
          :key="video.id"
          class="video-card"
          @click="goToVideo(video.id)"
        >
          <div class="video-thumbnail">
            <img :src="video.thumbnailUrl || '/default-thumbnail.jpg'" :alt="video.title">
            <div class="video-duration">{{ formatDuration(video.duration) }}</div>
          </div>
          <div class="video-info">
            <h4 class="video-title">{{ video.title }}</h4>
            <p class="video-author">{{ video.user.nickname || video.user.username }}</p>
            <div class="video-stats">
              <span>{{ formatNumber(video.viewCount) }} 次观看</span>
              <span>{{ formatTime(video.createdTime) }}</span>
            </div>
            <p class="video-description">{{ video.description }}</p>
          </div>
        </div>
      </div>
      
      <!-- 分页 -->
      <div class="pagination-container" v-if="totalPages > 1">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[12, 24, 48]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { videoApi } from '@/api'
import type { Video } from '@/types'
import { ElMessage } from 'element-plus'

const route = useRoute()
const router = useRouter()

// 响应式数据
const videos = ref<Video[]>([])
const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(12)
const total = ref(0)
const searchKeyword = ref('')
const sortBy = ref('relevance')
const duration = ref('')

// 计算属性
const totalPages = computed(() => Math.ceil(total.value / pageSize.value))

// 搜索视频
const handleSearch = async () => {
  if (!searchKeyword.value.trim()) {
    ElMessage.warning('请输入搜索关键词')
    return
  }
  
  loading.value = true
  currentPage.value = 1
  
  try {
    const response = await videoApi.searchVideos(searchKeyword.value, 0, pageSize.value)
    videos.value = response.content
    total.value = response.totalElements
    
    // 更新URL参数
    router.push({
      query: {
        q: searchKeyword.value,
        sort: sortBy.value,
        duration: duration.value
      }
    })
  } catch (error) {
    console.error('搜索失败:', error)
    ElMessage.error('搜索失败')
  } finally {
    loading.value = false
  }
}

// 分页处理
const handleSizeChange = (size: number) => {
  pageSize.value = size
  currentPage.value = 1
  fetchSearchResults()
}

const handleCurrentChange = (page: number) => {
  currentPage.value = page
  fetchSearchResults()
}

// 获取搜索结果
const fetchSearchResults = async () => {
  if (!searchKeyword.value.trim()) return
  
  loading.value = true
  try {
    const response = await videoApi.searchVideos(
      searchKeyword.value, 
      currentPage.value - 1, 
      pageSize.value
    )
    videos.value = response.content
    total.value = response.totalElements
  } catch (error) {
    console.error('获取搜索结果失败:', error)
    ElMessage.error('获取搜索结果失败')
  } finally {
    loading.value = false
  }
}

// 跳转到视频详情
const goToVideo = (videoId: number) => {
  router.push(`/video/${videoId}`)
}

// 格式化数字
const formatNumber = (num: number) => {
  if (num >= 10000) {
    return (num / 10000).toFixed(1) + '万'
  }
  return num.toString()
}

// 格式化时间
const formatTime = (timeStr: string) => {
  const date = new Date(timeStr)
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  
  if (days === 0) return '今天'
  if (days === 1) return '昨天'
  if (days < 7) return `${days}天前`
  if (days < 30) return `${Math.floor(days / 7)}周前`
  if (days < 365) return `${Math.floor(days / 30)}个月前`
  return `${Math.floor(days / 365)}年前`
}

// 格式化时长
const formatDuration = (duration?: number) => {
  if (!duration) return '00:00'
  const minutes = Math.floor(duration / 60)
  const seconds = duration % 60
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
}

// 监听路由参数变化
watch(
  () => route.query,
  (query) => {
    if (query.q) {
      searchKeyword.value = query.q as string
      sortBy.value = (query.sort as string) || 'relevance'
      duration.value = (query.duration as string) || ''
      handleSearch()
    }
  },
  { immediate: true }
)

// 初始化
onMounted(() => {
  // 如果URL中有搜索参数，自动执行搜索
  if (route.query.q) {
    searchKeyword.value = route.query.q as string
    sortBy.value = (route.query.sort as string) || 'relevance'
    duration.value = (route.query.duration as string) || ''
    handleSearch()
  }
})
</script>

<style scoped>
.search-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.search-header {
  margin-bottom: 30px;
}

.search-input-container {
  margin-bottom: 20px;
}

.search-filters {
  display: flex;
  gap: 16px;
}

.search-filters .el-select {
  width: 150px;
}

.results-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.results-header h3 {
  margin: 0;
  font-size: 20px;
  color: #333;
}

.results-count {
  color: #666;
  font-size: 14px;
}

.no-results {
  text-align: center;
  padding: 60px 0;
}

.video-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.video-card {
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.3s, box-shadow 0.3s;
}

.video-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
}

.video-thumbnail {
  position: relative;
  width: 100%;
  height: 180px;
  overflow: hidden;
}

.video-thumbnail img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.video-duration {
  position: absolute;
  bottom: 8px;
  right: 8px;
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 12px;
}

.video-info {
  padding: 16px;
}

.video-title {
  margin: 0 0 8px 0;
  font-size: 16px;
  font-weight: 500;
  color: #333;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.video-author {
  margin: 0 0 8px 0;
  font-size: 14px;
  color: #666;
}

.video-stats {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #999;
  margin-bottom: 8px;
}

.video-description {
  margin: 0;
  font-size: 13px;
  color: #666;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.pagination-container {
  display: flex;
  justify-content: center;
  margin-top: 30px;
}
</style> 