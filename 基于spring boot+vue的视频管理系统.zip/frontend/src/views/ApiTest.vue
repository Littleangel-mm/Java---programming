<template>
  <div class="api-test-page">
    <el-card class="test-card">
      <template #header>
        <div class="card-header">
          <h2>🔧 API接口测试</h2>
          <el-button type="primary" @click="runAllTests" :loading="testing">
            运行所有测试
          </el-button>
        </div>
      </template>

      <div class="test-section">
        <h3>测试结果</h3>
        <div v-if="testResults.length === 0" class="no-results">
          点击"运行所有测试"按钮开始测试
        </div>
        <div v-else class="results-list">
          <div 
            v-for="result in testResults" 
            :key="result.name"
            class="result-item"
            :class="{ success: result.success, error: !result.success }"
          >
            <div class="result-header">
              <span class="status-icon">
                {{ result.success ? '✅' : '❌' }}
              </span>
              <span class="test-name">{{ result.name }}</span>
            </div>
            <div v-if="!result.success && result.error" class="error-message">
              {{ result.error }}
            </div>
          </div>
        </div>
      </div>

      <div class="test-summary" v-if="testResults.length > 0">
        <el-divider />
        <div class="summary-stats">
          <div class="stat-item">
            <span class="stat-label">总测试数:</span>
            <span class="stat-value">{{ testResults.length }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">成功:</span>
            <span class="stat-value success">{{ successCount }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">失败:</span>
            <span class="stat-value error">{{ errorCount }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">成功率:</span>
            <span class="stat-value">{{ successRate }}%</span>
          </div>
        </div>
      </div>

      <div class="test-actions">
        <el-button @click="clearResults">清除结果</el-button>
        <el-button type="success" @click="exportResults">导出结果</el-button>
      </div>
    </el-card>

    <el-card class="info-card">
      <template #header>
        <h3>📋 测试说明</h3>
      </template>
      
      <div class="info-content">
        <p>此页面用于测试前端与后端API接口的连接性，确保数据交互正常。</p>
        
        <h4>测试内容：</h4>
        <ul>
          <li>用户相关接口（统计、查询等）</li>
          <li>视频相关接口（列表、统计、审核等）</li>
          <li>评论相关接口（列表、统计、审核等）</li>
          <li>分类相关接口（列表、树形结构、统计等）</li>
          <li>管理员接口（仪表板、系统信息等）</li>
        </ul>

        <h4>注意事项：</h4>
        <ul>
          <li>确保后端服务已启动（端口8080）</li>
          <li>确保数据库连接正常</li>
          <li>部分接口可能需要管理员权限</li>
          <li>测试结果仅供参考，实际功能请以页面操作为准</li>
        </ul>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { apiTester } from '@/utils/apiTest'

const testing = ref(false)
const testResults = ref<Array<{ name: string; success: boolean; error?: string }>>([])

const successCount = computed(() => 
  testResults.value.filter(r => r.success).length
)

const errorCount = computed(() => 
  testResults.value.filter(r => !r.success).length
)

const successRate = computed(() => {
  if (testResults.value.length === 0) return 0
  return Math.round((successCount.value / testResults.value.length) * 100)
})

const runAllTests = async () => {
  testing.value = true
  try {
    await apiTester.runAllTests()
    testResults.value = apiTester.getResults()
    
    if (successCount.value === testResults.value.length) {
      ElMessage.success('所有API接口测试通过！')
    } else {
      ElMessage.warning(`部分API接口存在问题，请检查后端服务`)
    }
  } catch (error) {
    ElMessage.error('测试过程中发生错误')
    console.error('API测试错误:', error)
  } finally {
    testing.value = false
  }
}

const clearResults = () => {
  testResults.value = []
  ElMessage.info('测试结果已清除')
}

const exportResults = () => {
  const data = {
    timestamp: new Date().toISOString(),
    results: testResults.value,
    summary: {
      total: testResults.value.length,
      success: successCount.value,
      error: errorCount.value,
      successRate: successRate.value
    }
  }
  
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `api-test-results-${new Date().toISOString().split('T')[0]}.json`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
  
  ElMessage.success('测试结果已导出')
}
</script>

<style scoped>
.api-test-page {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.test-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-header h2 {
  margin: 0;
  color: #303133;
}

.test-section {
  margin-bottom: 20px;
}

.test-section h3 {
  margin-bottom: 15px;
  color: #606266;
}

.no-results {
  text-align: center;
  color: #909399;
  padding: 40px;
  background: #fafafa;
  border-radius: 8px;
}

.results-list {
  max-height: 400px;
  overflow-y: auto;
}

.result-item {
  padding: 12px;
  margin-bottom: 8px;
  border-radius: 6px;
  border-left: 4px solid;
}

.result-item.success {
  background: #f0f9ff;
  border-left-color: #67c23a;
}

.result-item.error {
  background: #fef0f0;
  border-left-color: #f56c6c;
}

.result-header {
  display: flex;
  align-items: center;
  gap: 8px;
}

.status-icon {
  font-size: 16px;
}

.test-name {
  font-weight: 500;
  color: #303133;
}

.error-message {
  margin-top: 8px;
  padding: 8px;
  background: rgba(245, 108, 108, 0.1);
  border-radius: 4px;
  color: #f56c6c;
  font-size: 12px;
  word-break: break-all;
}

.test-summary {
  margin: 20px 0;
}

.summary-stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 15px;
}

.stat-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background: #f5f7fa;
  border-radius: 6px;
}

.stat-label {
  color: #606266;
  font-weight: 500;
}

.stat-value {
  font-weight: bold;
  color: #303133;
}

.stat-value.success {
  color: #67c23a;
}

.stat-value.error {
  color: #f56c6c;
}

.test-actions {
  display: flex;
  gap: 10px;
  justify-content: center;
  margin-top: 20px;
}

.info-card {
  background: #f8f9fa;
}

.info-card h3 {
  margin: 0;
  color: #303133;
}

.info-content {
  color: #606266;
  line-height: 1.6;
}

.info-content h4 {
  color: #303133;
  margin: 20px 0 10px 0;
}

.info-content ul {
  margin: 10px 0;
  padding-left: 20px;
}

.info-content li {
  margin-bottom: 5px;
}

@media (max-width: 768px) {
  .api-test-page {
    padding: 10px;
  }
  
  .card-header {
    flex-direction: column;
    gap: 10px;
    align-items: stretch;
  }
  
  .summary-stats {
    grid-template-columns: 1fr;
  }
  
  .test-actions {
    flex-direction: column;
  }
}
</style> 