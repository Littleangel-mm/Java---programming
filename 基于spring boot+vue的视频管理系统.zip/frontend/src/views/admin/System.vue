<template>
  <div class="system-page">
    <div class="page-header">
      <h2>系统设置</h2>
    </div>
    
    <!-- 系统信息 -->
    <el-card class="system-card">
      <template #header>
        <div class="card-header">
          <span>系统信息</span>
          <el-button type="primary" size="small" @click="refreshSystemInfo">
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
        </div>
      </template>
      
      <div class="system-info-grid">
        <div class="info-item">
          <div class="info-label">运行时间</div>
          <div class="info-value">{{ systemInfo.uptime }}</div>
        </div>
        <div class="info-item">
          <div class="info-label">在线用户</div>
          <div class="info-value">{{ systemInfo.onlineUsers }}</div>
        </div>
        <div class="info-item">
          <div class="info-label">CPU使用率</div>
          <div class="info-value">
            <el-progress 
              :percentage="systemInfo.cpuUsage" 
              :color="getProgressColor(systemInfo.cpuUsage)"
            />
          </div>
        </div>
        <div class="info-item">
          <div class="info-label">内存使用率</div>
          <div class="info-value">
            <el-progress 
              :percentage="systemInfo.memoryUsage" 
              :color="getProgressColor(systemInfo.memoryUsage)"
            />
          </div>
        </div>
        <div class="info-item">
          <div class="info-label">磁盘使用率</div>
          <div class="info-value">
            <el-progress 
              :percentage="systemInfo.diskUsage" 
              :color="getProgressColor(systemInfo.diskUsage)"
            />
          </div>
        </div>
      </div>
    </el-card>
    
    <!-- 系统配置 -->
    <el-card class="system-card">
      <template #header>
        <span>系统配置</span>
      </template>
      
      <el-form :model="systemConfig" label-width="120px">
        <el-form-item label="网站名称">
          <el-input v-model="systemConfig.siteName" />
        </el-form-item>
        <el-form-item label="网站描述">
          <el-input 
            v-model="systemConfig.siteDescription" 
            type="textarea" 
            :rows="3"
          />
        </el-form-item>
        <el-form-item label="视频上传限制">
          <el-input-number 
            v-model="systemConfig.maxVideoSize" 
            :min="1" 
            :max="1000"
          />
          <span style="margin-left: 8px;">MB</span>
        </el-form-item>
        <el-form-item label="允许的视频格式">
          <el-select v-model="systemConfig.allowedVideoFormats" multiple>
            <el-option label="MP4" value="mp4" />
            <el-option label="AVI" value="avi" />
            <el-option label="MOV" value="mov" />
            <el-option label="WMV" value="wmv" />
            <el-option label="FLV" value="flv" />
          </el-select>
        </el-form-item>
        <el-form-item label="用户注册">
          <el-switch v-model="systemConfig.allowRegistration" />
        </el-form-item>
        <el-form-item label="视频审核">
          <el-switch v-model="systemConfig.requireVideoApproval" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="saveSystemConfig" :loading="saving">
            保存配置
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
    
    <!-- 系统维护 -->
    <el-card class="system-card">
      <template #header>
        <span>系统维护</span>
      </template>
      
      <div class="maintenance-actions">
        <el-button type="warning" @click="clearCache">
          <el-icon><Delete /></el-icon>
          清理缓存
        </el-button>
        <el-button type="info" @click="backupDatabase">
          <el-icon><Download /></el-icon>
          备份数据库
        </el-button>
        <el-button type="danger" @click="restartSystem">
          <el-icon><RefreshRight /></el-icon>
          重启系统
        </el-button>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { adminApi } from '@/api'
import type { SystemInfo } from '@/types'
import { ElMessage, ElMessageBox } from 'element-plus'

// 响应式数据
const systemInfo = ref<SystemInfo>({
  uptime: '',
  cpuUsage: 0,
  memoryUsage: 0,
  diskUsage: 0,
  onlineUsers: 0
})

const saving = ref(false)

const systemConfig = reactive({
  siteName: 'SP视频平台',
  siteDescription: '一个现代化的视频分享平台',
  maxVideoSize: 100,
  allowedVideoFormats: ['mp4', 'avi', 'mov'],
  allowRegistration: true,
  requireVideoApproval: true
})

// 获取系统信息
const fetchSystemInfo = async () => {
  try {
    const response = await adminApi.getSystemInfo()
    systemInfo.value = response
  } catch (error) {
    console.error('获取系统信息失败:', error)
    ElMessage.error('获取系统信息失败')
  }
}

// 刷新系统信息
const refreshSystemInfo = () => {
  fetchSystemInfo()
  ElMessage.success('系统信息已刷新')
}

// 获取进度条颜色
const getProgressColor = (percentage: number) => {
  if (percentage < 50) return '#67c23a'
  if (percentage < 80) return '#e6a23c'
  return '#f56c6c'
}

// 保存系统配置
const saveSystemConfig = async () => {
  saving.value = true
  try {
    // 这里需要调用实际的API
    await new Promise(resolve => setTimeout(resolve, 1000))
    ElMessage.success('配置保存成功')
  } catch (error) {
    console.error('保存配置失败:', error)
    ElMessage.error('保存配置失败')
  } finally {
    saving.value = false
  }
}

// 清理缓存
const clearCache = async () => {
  try {
    await ElMessageBox.confirm(
      '确定要清理系统缓存吗？',
      '确认操作',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    // 这里需要调用实际的API
    await new Promise(resolve => setTimeout(resolve, 1000))
    ElMessage.success('缓存清理成功')
  } catch (error) {
    if (error !== 'cancel') {
      console.error('清理缓存失败:', error)
      ElMessage.error('清理缓存失败')
    }
  }
}

// 备份数据库
const backupDatabase = async () => {
  try {
    await ElMessageBox.confirm(
      '确定要备份数据库吗？',
      '确认操作',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'info'
      }
    )
    
    // 这里需要调用实际的API
    await new Promise(resolve => setTimeout(resolve, 2000))
    ElMessage.success('数据库备份成功')
  } catch (error) {
    if (error !== 'cancel') {
      console.error('备份数据库失败:', error)
      ElMessage.error('备份数据库失败')
    }
  }
}

// 重启系统
const restartSystem = async () => {
  try {
    await ElMessageBox.confirm(
      '确定要重启系统吗？这将导致系统暂时不可用。',
      '确认操作',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'error'
      }
    )
    
    // 这里需要调用实际的API
    ElMessage.success('系统重启命令已发送')
  } catch (error) {
    if (error !== 'cancel') {
      console.error('重启系统失败:', error)
      ElMessage.error('重启系统失败')
    }
  }
}

// 初始化
onMounted(() => {
  fetchSystemInfo()
  
  // 定时刷新系统信息
  setInterval(() => {
    fetchSystemInfo()
  }, 30000) // 每30秒刷新一次
})
</script>

<style scoped>
.system-page {
  max-width: 1200px;
  margin: 0 auto;
}

.page-header {
  margin-bottom: 20px;
}

.page-header h2 {
  margin: 0;
  font-size: 24px;
  color: #333;
}

.system-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.system-info-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
}

.info-item {
  padding: 16px;
  background: #f8f9fa;
  border-radius: 8px;
}

.info-label {
  font-size: 14px;
  color: #666;
  margin-bottom: 8px;
}

.info-value {
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

.maintenance-actions {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
}
</style> 