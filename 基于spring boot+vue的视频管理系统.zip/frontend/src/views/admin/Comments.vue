<template>
  <div class="comments-page">
    <div class="page-header">
      <h2>评论管理</h2>
      <div class="header-actions">
        <el-input
          v-model="searchKeyword"
          placeholder="搜索评论..."
          style="width: 300px; margin-right: 16px;"
          @keyup.enter="handleSearch"
        >
          <template #append>
            <el-button @click="handleSearch">
              <el-icon><Search /></el-icon>
            </el-button>
          </template>
        </el-input>
      </div>
    </div>
    
    <!-- 评论表格 -->
    <el-card>
      <el-table
        :data="comments"
        v-loading="loading"
        style="width: 100%"
      >
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column label="用户" width="120">
          <template #default="{ row }">
            <div class="user-info">
              <el-avatar :src="row.user.avatar" :size="32">
                {{ row.user.nickname?.[0] || row.user.username?.[0] }}
              </el-avatar>
              <span class="username">{{ row.user.nickname || row.user.username }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="content" label="评论内容" min-width="300">
          <template #default="{ row }">
            <div class="comment-content">
              {{ row.content }}
            </div>
          </template>
        </el-table-column>
        <el-table-column label="审核状态" width="100">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">
              {{ getStatusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="video.title" label="视频" width="200">
          <template #default="{ row }">
            <el-link @click="goToVideo(row.video.id)">
              {{ row.video.title }}
            </el-link>
          </template>
        </el-table-column>
        <el-table-column prop="likeCount" label="点赞数" width="100" />
        <el-table-column prop="createdTime" label="评论时间" width="180">
          <template #default="{ row }">
            {{ formatTime(row.createdTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button size="small" @click="handleView(row)">查看</el-button>
            <el-button 
              size="small" 
              type="danger" 
              @click="handleDelete(row)"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      
      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { commentApi } from '@/api'
import type { Comment } from '@/types'
import { ElMessage, ElMessageBox } from 'element-plus'

// 响应式数据
const comments = ref<Comment[]>([])
const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)
const searchKeyword = ref('')

// 获取评论列表
const fetchComments = async () => {
  loading.value = true
  try {
    const response = await commentApi.getCommentList(currentPage.value - 1, pageSize.value)
    comments.value = response.content
    total.value = response.totalElements
  } catch (error) {
    console.error('获取评论列表失败:', error)
    ElMessage.error('获取评论列表失败')
  } finally {
    loading.value = false
  }
}

// 搜索评论
const handleSearch = async () => {
  currentPage.value = 1
  await fetchComments()
}

// 分页处理
const handleSizeChange = (size: number) => {
  pageSize.value = size
  currentPage.value = 1
  fetchComments()
}

const handleCurrentChange = (page: number) => {
  currentPage.value = page
  fetchComments()
}

// 查看评论
const handleView = (comment: Comment) => {
  // 跳转到视频详情页并定位到评论
  window.open(`/video/${comment.video.id}?comment=${comment.id}`, '_blank')
}

// 删除评论
const handleDelete = async (comment: Comment) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除这条评论吗？`,
      '确认删除',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    await commentApi.deleteComment(comment.id)
    ElMessage.success('删除成功')
    fetchComments()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除评论失败:', error)
      ElMessage.error('删除评论失败')
    }
  }
}

// 跳转到视频
const goToVideo = (videoId: number) => {
  window.open(`/video/${videoId}`, '_blank')
}

// 格式化时间
const formatTime = (timeStr: string) => {
  return new Date(timeStr).toLocaleString('zh-CN')
}

// 获取状态类型
const getStatusType = (status: string) => {
  const types: Record<string, string> = {
    PENDING: 'warning',
    ACTIVE: 'success',
    REJECTED: 'danger',
    HIDDEN: 'info',
    DELETED: 'info'
  }
  return types[status] || 'info'
}

// 获取状态文本
const getStatusText = (status: string) => {
  const texts: Record<string, string> = {
    PENDING: '待审核',
    ACTIVE: '已通过',
    REJECTED: '已拒绝',
    HIDDEN: '隐藏',
    DELETED: '已删除'
  }
  return texts[status] || status
}

// 初始化
onMounted(() => {
  fetchComments()
})
</script>

<style scoped>
.comments-page {
  max-width: 1200px;
  margin: 0 auto;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.page-header h2 {
  margin: 0;
  font-size: 24px;
  color: #333;
}

.header-actions {
  display: flex;
  align-items: center;
}

.user-info {
  display: flex;
  align-items: center;
}

.username {
  margin-left: 8px;
  font-size: 14px;
  color: #333;
}

.comment-content {
  max-width: 300px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.pagination-container {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
</style> 