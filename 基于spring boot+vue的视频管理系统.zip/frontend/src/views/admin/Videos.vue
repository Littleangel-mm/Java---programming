<template>
  <div class="videos-page">
    <div class="page-header">
      <h2>视频管理</h2>
      <div class="header-actions">
        <el-tabs v-model="activeTab" @tab-click="handleTabChange">
          <el-tab-pane label="全部视频" name="all" />
          <el-tab-pane label="待审核" name="pending" />
        </el-tabs>
        <el-input
          v-if="activeTab === 'all'"
          v-model="searchKeyword"
          placeholder="搜索视频..."
          style="width: 300px; margin-left: 16px;"
          @keyup.enter="handleSearch"
        >
          <template #append>
            <el-button @click="handleSearch">
              <el-icon><Search /></el-icon>
            </el-button>
          </template>
        </el-input>
      </div>
    </div>
    
    <!-- 视频表格 -->
    <el-card>
      <el-table
        :data="videos"
        v-loading="loading"
        style="width: 100%"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column label="缩略图" width="120">
          <template #default="{ row }">
            <img 
              :src="row.thumbnailUrl || '/default-thumbnail.jpg'" 
              :alt="row.title"
              style="width: 80px; height: 45px; object-fit: cover; border-radius: 4px;"
            >
          </template>
        </el-table-column>
        <el-table-column prop="title" label="标题" width="200" />
        <el-table-column prop="user.username" label="上传者" width="120" />
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">
              {{ getStatusText(row.status) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="viewCount" label="观看次数" width="100" />
        <el-table-column prop="likeCount" label="点赞数" width="100" />
        <el-table-column prop="commentCount" label="评论数" width="100" />
        <el-table-column prop="createdTime" label="上传时间" width="180">
          <template #default="{ row }">
            {{ formatTime(row.createdTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <div class="action-buttons">
              <div class="button-row">
                <el-button size="small" @click="handleView(row)">查看</el-button>
                <el-button 
                  v-if="activeTab === 'pending'"
                  size="small" 
                  type="success" 
                  @click="handleApprove(row)"
                >
                  通过
                </el-button>
              </div>
              <div class="button-row">
                <el-button 
                  v-if="activeTab === 'pending'"
                  size="small" 
                  type="danger" 
                  @click="handleReject(row)"
                >
                  拒绝
                </el-button>
                <el-button 
                  size="small" 
                  type="danger" 
                  @click="handleDelete(row)"
                >
                  删除
                </el-button>
              </div>
            </div>
          </template>
        </el-table-column>
      </el-table>
      
      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
    
    <!-- 拒绝原因对话框 -->
    <el-dialog
      v-model="showRejectDialog"
      title="拒绝视频"
      width="400px"
    >
      <el-form>
        <el-form-item label="拒绝原因">
          <el-input
            v-model="rejectReason"
            type="textarea"
            :rows="3"
            placeholder="请输入拒绝原因"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showRejectDialog = false">取消</el-button>
        <el-button type="danger" @click="confirmReject" :loading="rejecting">
          确认拒绝
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { useUserStore } from '@/stores/user'
import { videoApi, adminVideoApi } from '@/api'
import type { Video } from '@/types'
import { ElMessage, ElMessageBox } from 'element-plus'

const userStore = useUserStore()
const activeTab = ref<'all' | 'pending'>('all')

// 响应式数据
const videos = ref<Video[]>([])
const loading = ref(false)
const rejecting = ref(false)
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)
const searchKeyword = ref('')
const statusFilter = ref('')
const showRejectDialog = ref(false)
const rejectReason = ref('')
const rejectingVideo = ref<Video | null>(null)

// 获取视频列表
const fetchVideos = async () => {
  loading.value = true
  try {
    let response
    if (activeTab.value === 'pending') {
      response = await adminVideoApi.getPendingVideos(currentPage.value - 1, pageSize.value)
      if (response.success) {
        videos.value = response.content
        total.value = response.totalElements
      } else {
        ElMessage.error(response.message || '获取待审核视频失败')
      }
    } else if (searchKeyword.value.trim()) {
      response = await videoApi.searchVideos(searchKeyword.value, currentPage.value - 1, pageSize.value)
      videos.value = response.content
      total.value = response.totalElements
    } else {
      response = await videoApi.getAllVideos(currentPage.value - 1, pageSize.value)
      videos.value = response.content
      total.value = response.totalElements
    }
  } catch (error) {
    ElMessage.error(`获取视频列表失败: ${error.response?.data?.message || error.message}`)
  } finally {
    loading.value = false
  }
}

// 标签页切换
const handleTabChange = () => {
  currentPage.value = 1
  fetchVideos()
}

// 搜索视频
const handleSearch = async () => {
  currentPage.value = 1
  await fetchVideos()
}

// 分页处理
const handleSizeChange = (size: number) => {
  pageSize.value = size
  currentPage.value = 1
  fetchVideos()
}

const handleCurrentChange = (page: number) => {
  currentPage.value = page
  fetchVideos()
}

// 查看视频
const handleView = (video: Video) => {
  window.open(`/video/${video.id}`, '_blank')
}

// 通过视频
const handleApprove = async (video: Video) => {
  if (!userStore.user) return
  try {
    await ElMessageBox.confirm(
      `确定要通过视频 "${video.title}" 吗？`,
      '确认通过',
      { confirmButtonText: '确定', cancelButtonText: '取消', type: 'success' }
    )
    let response
    if (activeTab.value === 'pending') {
      response = await adminVideoApi.approveVideo(video.id, userStore.user.id)
    } else {
      response = await videoApi.approveVideo(video.id, userStore.user.id)
    }
    
    if (response.success) {
      ElMessage.success(response.message || '审核通过成功')
      fetchVideos()
    } else {
      ElMessage.error(response.message || '审核通过失败')
    }
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error(`审核通过失败: ${error.response?.data?.message || error.message}`)
    }
  }
}

// 拒绝视频
const handleReject = (video: Video) => {
  rejectingVideo.value = video
  rejectReason.value = ''
  showRejectDialog.value = true
}

// 确认拒绝
const confirmReject = async () => {
  if (!rejectingVideo.value || !userStore.user) return
  try {
    rejecting.value = true
    let response
    if (activeTab.value === 'pending') {
      response = await adminVideoApi.rejectVideo(rejectingVideo.value.id, userStore.user.id, rejectReason.value)
    } else {
      response = await videoApi.rejectVideo(rejectingVideo.value.id, userStore.user.id, rejectReason.value)
    }
    
    if (response.success) {
      ElMessage.success(response.message || '拒绝成功')
      showRejectDialog.value = false
      fetchVideos()
    } else {
      ElMessage.error(response.message || '拒绝失败')
    }
  } catch (error) {
    ElMessage.error(`拒绝失败: ${error.response?.data?.message || error.message}`)
  } finally {
    rejecting.value = false
  }
}

// 删除视频
const handleDelete = async (video: Video) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除视频 "${video.title}" 吗？`,
      '确认删除',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    
    await videoApi.deleteVideo(video.id)
    ElMessage.success('删除成功')
    fetchVideos()
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除视频失败:', error)
      console.error('错误详情:', error.response?.data)
      ElMessage.error(`删除视频失败: ${error.response?.data?.error || error.message}`)
    }
  }
}

// 获取状态类型
const getStatusType = (status: string) => {
  const types: Record<string, string> = {
    PENDING: 'warning',
    APPROVED: 'success',
    REJECTED: 'danger'
  }
  return types[status] || 'info'
}

// 获取状态文本
const getStatusText = (status: string) => {
  const texts: Record<string, string> = {
    PENDING: '待审核',
    APPROVED: '已通过',
    REJECTED: '已拒绝'
  }
  return texts[status] || status
}

// 格式化时间
const formatTime = (timeStr: string) => {
  return new Date(timeStr).toLocaleString('zh-CN')
}

// 监听状态筛选变化
watch(activeTab, () => {
  currentPage.value = 1
  fetchVideos()
})

// 初始化
onMounted(() => {
  fetchVideos()
})
</script>

<style scoped>
.videos-page {
  max-width: 1200px;
  margin: 0 auto;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.page-header h2 {
  margin: 0;
  font-size: 24px;
  color: #333;
}

.header-actions {
  display: flex;
  align-items: center;
}

.pagination-container {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}

.action-buttons {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.button-row {
  display: flex;
  gap: 4px;
}

.button-row .el-button {
  flex: 1;
  min-width: 60px;
}
</style> 