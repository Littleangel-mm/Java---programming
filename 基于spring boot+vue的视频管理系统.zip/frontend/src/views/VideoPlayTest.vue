<template>
  <div class="video-play-test">
    <h2>视频播放测试</h2>
    
    <!-- 测试表单 -->
    <div class="test-form">
      <el-form :model="testForm" label-width="120px">
        <el-form-item label="视频ID">
          <el-input v-model="testForm.videoId" placeholder="输入视频ID" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="testVideoPlay">测试视频播放</el-button>
          <el-button @click="testVideoInfo">测试视频信息</el-button>
          <el-button @click="testVideoDetail">测试视频详情</el-button>
        </el-form-item>
      </el-form>
    </div>
    
    <!-- 测试结果 -->
    <div class="test-results">
      <h3>测试结果</h3>
      
      <!-- 视频详情 -->
      <div v-if="videoDetail" class="result-section">
        <h4>视频详情</h4>
        <pre>{{ JSON.stringify(videoDetail, null, 2) }}</pre>
      </div>
      
      <!-- 视频信息 -->
      <div v-if="videoInfo" class="result-section">
        <h4>视频流信息</h4>
        <pre>{{ JSON.stringify(videoInfo, null, 2) }}</pre>
      </div>
      
      <!-- 播放URL -->
      <div v-if="playUrl" class="result-section">
        <h4>播放URL</h4>
        <p><strong>URL:</strong> {{ playUrl }}</p>
        <el-button @click="testDirectPlay" type="success">直接播放测试</el-button>
      </div>
      
      <!-- 错误信息 -->
      <div v-if="error" class="result-section error">
        <h4>错误信息</h4>
        <p style="color: red;">{{ error }}</p>
      </div>
    </div>
    
    <!-- 视频播放器 -->
    <div v-if="showPlayer" class="video-player-section">
      <h3>视频播放器</h3>
      <div class="video-container">
        <video 
          ref="videoRef"
          :src="playUrl"
          controls
          preload="metadata"
          style="width: 100%; max-width: 600px; height: auto;"
          @loadstart="onVideoLoadStart"
          @loadedmetadata="onVideoLoadedMetadata"
          @canplay="onVideoCanPlay"
          @error="onVideoError"
        >
          您的浏览器不支持视频播放
        </video>
      </div>
      <div class="video-status">
        <p>加载状态: {{ videoStatus }}</p>
        <p v-if="videoError">错误: {{ videoError }}</p>
      </div>
    </div>
    
    <!-- 网络请求测试 -->
    <div class="network-test">
      <h3>网络请求测试</h3>
      <el-button @click="testNetworkRequests">测试所有API</el-button>
      <div v-if="networkResults" class="network-results">
        <h4>网络请求结果</h4>
        <pre>{{ JSON.stringify(networkResults, null, 2) }}</pre>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { videoApi } from '@/api'
import { ElMessage } from 'element-plus'

const testForm = reactive({
  videoId: '7'
})

const videoDetail = ref(null)
const videoInfo = ref(null)
const playUrl = ref('')
const error = ref('')
const showPlayer = ref(false)
const videoRef = ref()
const videoStatus = ref('')
const videoError = ref('')
const networkResults = ref(null)

// 测试视频播放
const testVideoPlay = async () => {
  try {
    error.value = ''
    const videoId = parseInt(testForm.videoId)
    playUrl.value = videoApi.getVideoPlayUrl(videoId)
    showPlayer.value = true
    ElMessage.success('播放URL已生成')
  } catch (err) {
    error.value = `测试失败: ${err}`
    ElMessage.error('测试失败')
  }
}

// 测试视频信息
const testVideoInfo = async () => {
  try {
    error.value = ''
    const videoId = parseInt(testForm.videoId)
    const response = await videoApi.getVideoStreamInfo(videoId)
    videoInfo.value = response
    ElMessage.success('获取视频信息成功')
  } catch (err) {
    error.value = `获取视频信息失败: ${err}`
    ElMessage.error('获取视频信息失败')
  }
}

// 测试视频详情
const testVideoDetail = async () => {
  try {
    error.value = ''
    const videoId = parseInt(testForm.videoId)
    const response = await videoApi.getVideoById(videoId)
    videoDetail.value = response
    ElMessage.success('获取视频详情成功')
  } catch (err) {
    error.value = `获取视频详情失败: ${err}`
    ElMessage.error('获取视频详情失败')
  }
}

// 直接播放测试
const testDirectPlay = () => {
  if (videoRef.value) {
    videoRef.value.play().catch(err => {
      videoError.value = `播放失败: ${err.message}`
    })
  }
}

// 视频事件处理
const onVideoLoadStart = () => {
  videoStatus.value = '开始加载'
  videoError.value = ''
}

const onVideoLoadedMetadata = () => {
  videoStatus.value = '元数据加载完成'
}

const onVideoCanPlay = () => {
  videoStatus.value = '可以播放'
}

const onVideoError = (event) => {
  videoStatus.value = '播放错误'
  videoError.value = `视频播放错误: ${event.target.error?.message || '未知错误'}`
}

// 测试网络请求
const testNetworkRequests = async () => {
  const videoId = parseInt(testForm.videoId)
  const results = {}
  
  try {
    // 测试视频详情
    results.videoDetail = await videoApi.getVideoById(videoId)
  } catch (err) {
    results.videoDetail = { error: err.message }
  }
  
  try {
    // 测试视频流信息
    results.videoStreamInfo = await videoApi.getVideoStreamInfo(videoId)
  } catch (err) {
    results.videoStreamInfo = { error: err.message }
  }
  
  try {
    // 测试播放URL
    results.playUrl = videoApi.getVideoPlayUrl(videoId)
  } catch (err) {
    results.playUrl = { error: err.message }
  }
  
  networkResults.value = results
  ElMessage.success('网络请求测试完成')
}
</script>

<style scoped>
.video-play-test {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.test-form {
  background: white;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.test-results {
  background: white;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.result-section {
  margin-bottom: 20px;
  padding: 15px;
  border: 1px solid #eee;
  border-radius: 4px;
}

.result-section.error {
  border-color: #f56c6c;
  background-color: #fef0f0;
}

.result-section h4 {
  margin: 0 0 10px 0;
  color: #333;
}

.result-section pre {
  background: #f5f5f5;
  padding: 10px;
  border-radius: 4px;
  overflow-x: auto;
  font-size: 12px;
}

.video-player-section {
  background: white;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.video-container {
  margin: 20px 0;
  text-align: center;
}

.video-status {
  margin-top: 15px;
  padding: 10px;
  background: #f5f5f5;
  border-radius: 4px;
}

.video-status p {
  margin: 5px 0;
}

.network-test {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.network-results {
  margin-top: 15px;
}

.network-results pre {
  background: #f5f5f5;
  padding: 10px;
  border-radius: 4px;
  overflow-x: auto;
  font-size: 12px;
}
</style> 