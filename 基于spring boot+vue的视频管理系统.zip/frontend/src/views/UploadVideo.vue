<template>
  <div class="upload-page">
    <div class="page-header">
      <h2>上传视频</h2>
    </div>
    
    <el-card class="upload-card">
      <el-form
        ref="uploadFormRef"
        :model="uploadForm"
        :rules="uploadRules"
        label-width="100px"
      >
        <el-form-item label="视频标题" prop="title">
          <el-input 
            v-model="uploadForm.title" 
            placeholder="请输入视频标题"
            maxlength="100"
            show-word-limit
          />
        </el-form-item>
        
        <el-form-item label="视频描述" prop="description">
          <el-input 
            v-model="uploadForm.description" 
            type="textarea" 
            :rows="4"
            placeholder="请输入视频描述"
            maxlength="500"
            show-word-limit
          />
        </el-form-item>
        
        <el-form-item label="视频文件" prop="videoFile">
          <el-upload
            class="video-uploader"
            :show-file-list="false"
            :before-upload="beforeVideoUpload"
            :http-request="handleVideoUpload"
            accept="video/*"
          >
            <div v-if="uploadForm.videoFile" class="video-preview">
              <video 
                :src="uploadForm.videoPreview" 
                controls 
                class="video-preview-player"
              ></video>
              <div class="video-info">
                <p>文件名: {{ uploadForm.videoFile.name }}</p>
                <p>大小: {{ formatFileSize(uploadForm.videoFile.size) }}</p>
              </div>
            </div>
            <div v-else class="upload-placeholder">
              <el-icon class="upload-icon"><VideoPlay /></el-icon>
              <p>点击上传视频文件</p>
              <p class="upload-tip">支持MP4、AVI、MOV等格式，最大100MB</p>
            </div>
          </el-upload>
        </el-form-item>
        
        <el-form-item label="视频分类" prop="categoryId">
          <el-select v-model="uploadForm.categoryId" placeholder="请选择分类" style="width: 100%">
            <el-option 
              v-for="category in categories" 
              :key="category.id" 
              :label="category.name" 
              :value="category.id" 
            />
          </el-select>
        </el-form-item>
        
        <el-form-item label="视频标签">
          <el-input 
            v-model="uploadForm.tags" 
            placeholder="请输入标签，用逗号分隔"
          />
          <div class="form-tip">
            标签用逗号分隔，最多10个标签
          </div>
        </el-form-item>
        
        <el-form-item label="缩略图">
          <el-upload
            class="thumbnail-uploader"
            :show-file-list="false"
            :before-upload="beforeThumbnailUpload"
            :http-request="handleThumbnailUpload"
            accept="image/*"
          >
            <img v-if="uploadForm.thumbnailUrl" :src="uploadForm.thumbnailUrl" class="thumbnail">
            <el-icon v-else class="thumbnail-uploader-icon"><Plus /></el-icon>
          </el-upload>
          <div class="form-tip">
            建议尺寸：1280x720，支持JPG、PNG格式
          </div>
        </el-form-item>
        
        <el-form-item>
          <el-button 
            type="primary" 
            @click="handleUpload" 
            :loading="uploading"
            size="large"
            :disabled="!uploadForm.videoFile"
          >
            {{ uploading ? '上传中...' : '上传视频' }}
          </el-button>
          <el-button @click="$router.push('/home')" size="large">
            取消
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { videoApi, categoryApi, fileApi } from '@/api'
import type { Category } from '@/types'
import { ElMessage } from 'element-plus'
import type { FormInstance, FormRules, UploadRequestOptions } from 'element-plus'
import { VideoPlay, Plus } from '@element-plus/icons-vue'

const router = useRouter()
const userStore = useUserStore()

// 响应式数据
const categories = ref<Category[]>([])
const uploading = ref(false)
const uploadFormRef = ref<FormInstance>()

const uploadForm = reactive({
  title: '',
  description: '',
  videoFile: null as File | null,
  videoPreview: '',
  categoryId: undefined as number | undefined,
  tags: '',
  thumbnailUrl: ''
})

const uploadRules: FormRules = {
  title: [
    { required: true, message: '请输入视频标题', trigger: 'blur' },
    { min: 2, max: 100, message: '标题长度在 2 到 100 个字符', trigger: 'blur' }
  ],
  description: [
    { max: 500, message: '描述不能超过500个字符', trigger: 'blur' }
  ],
  videoFile: [
    { required: true, message: '请选择视频文件', trigger: 'change' }
  ],
  categoryId: [
    { required: true, message: '请选择视频分类', trigger: 'change' }
  ]
}

// 格式化文件大小
const formatFileSize = (bytes: number) => {
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

// 获取分类列表
const fetchCategories = async () => {
  try {
    const response = await categoryApi.getActiveCategories()
    categories.value = response
  } catch (error) {
    console.error('获取分类列表失败:', error)
    ElMessage.error('获取分类列表失败')
  }
}

// 处理视频文件上传
const handleVideoUpload = async (options: UploadRequestOptions) => {
  uploadForm.videoFile = options.file
  uploadForm.videoPreview = URL.createObjectURL(options.file)
  ElMessage.success('视频文件选择成功')
}

const beforeVideoUpload = (file: File) => {
  const isVideo = file.type.startsWith('video/')
  const isLt100M = file.size / 1024 / 1024 < 100

  if (!isVideo) {
    ElMessage.error('只能上传视频文件!')
    return false
  }
  if (!isLt100M) {
    ElMessage.error('视频文件大小不能超过 100MB!')
    return false
  }
  return true
}

// 处理缩略图上传
const handleThumbnailUpload = async (options: UploadRequestOptions) => {
  try {
    const response = await fileApi.uploadFile(options.file)
    uploadForm.thumbnailUrl = response.url
    ElMessage.success('缩略图上传成功')
  } catch (error) {
    console.error('缩略图上传失败:', error)
    ElMessage.error('缩略图上传失败')
  }
}

const beforeThumbnailUpload = (file: File) => {
  const isImage = file.type.startsWith('image/')
  const isLt2M = file.size / 1024 / 1024 < 2

  if (!isImage) {
    ElMessage.error('只能上传图片文件!')
    return false
  }
  if (!isLt2M) {
    ElMessage.error('图片大小不能超过 2MB!')
    return false
  }
  return true
}

// 上传视频
const handleUpload = async () => {
  if (!uploadFormRef.value || !userStore.user || !uploadForm.videoFile) return
  
  try {
    await uploadFormRef.value.validate()
    uploading.value = true
    
    // 创建FormData对象
    const formData = new FormData()
    formData.append('file', uploadForm.videoFile)
    formData.append('title', uploadForm.title)
    formData.append('description', uploadForm.description)
    formData.append('userId', userStore.user.id.toString())
    
    if (uploadForm.categoryId) {
      formData.append('categoryId', uploadForm.categoryId.toString())
    }
    
    if (uploadForm.thumbnailUrl) {
      // 如果有缩略图URL，需要重新上传缩略图文件
      // 这里简化处理，直接使用URL
      formData.append('thumbnailUrl', uploadForm.thumbnailUrl)
    }
    
    await videoApi.upload(formData)
    ElMessage.success('视频上传成功，等待审核')
    router.push('/home')
  } catch (error) {
    console.error('上传视频失败:', error)
    ElMessage.error('上传视频失败')
  } finally {
    uploading.value = false
  }
}

// 初始化
onMounted(() => {
  fetchCategories()
})
</script>

<style scoped>
.upload-page {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.page-header {
  margin-bottom: 20px;
}

.page-header h2 {
  margin: 0;
  font-size: 24px;
  color: #333;
}

.upload-card {
  margin-bottom: 20px;
}

.form-tip {
  font-size: 12px;
  color: #999;
  margin-top: 4px;
}

.video-uploader {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  width: 100%;
  min-height: 200px;
}

.video-uploader:hover {
  border-color: #409eff;
}

.upload-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 200px;
  color: #8c939d;
}

.upload-icon {
  font-size: 48px;
  margin-bottom: 10px;
}

.upload-tip {
  font-size: 12px;
  margin-top: 5px;
}

.video-preview {
  width: 100%;
}

.video-preview-player {
  width: 100%;
  max-height: 300px;
  object-fit: contain;
}

.video-info {
  padding: 10px;
  background: #f5f5f5;
  border-radius: 4px;
  margin-top: 10px;
}

.video-info p {
  margin: 5px 0;
  font-size: 14px;
  color: #666;
}

.thumbnail-uploader {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  width: 200px;
  height: 120px;
}

.thumbnail-uploader:hover {
  border-color: #409eff;
}

.thumbnail-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 200px;
  height: 120px;
  line-height: 120px;
  text-align: center;
}

.thumbnail {
  width: 200px;
  height: 120px;
  display: block;
  object-fit: cover;
}
</style> 