<template>
  <div class="not-found">
    <div class="not-found-content">
      <h1>404</h1>
      <h2>页面未找到</h2>
      <p>抱歉，您访问的页面不存在</p>
      <el-button type="primary" @click="$router.push('/')">
        返回首页
      </el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
// 404页面组件
</script>

<style scoped>
.not-found {
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.not-found-content {
  text-align: center;
  color: white;
}

.not-found-content h1 {
  font-size: 120px;
  margin: 0;
  font-weight: 700;
}

.not-found-content h2 {
  font-size: 32px;
  margin: 0 0 16px 0;
  font-weight: 500;
}

.not-found-content p {
  font-size: 18px;
  margin: 0 0 32px 0;
  opacity: 0.8;
}
</style> 