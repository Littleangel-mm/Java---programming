<template>
  <div class="home-container">
    <!-- 顶部导航栏 -->
    <el-header class="header">
      <div class="header-content">
        <div class="logo">
          <h2>视频平台</h2>
        </div>
        
        <div class="search-box">
          <el-input
            v-model="searchKeyword"
            placeholder="搜索视频..."
            class="search-input"
            @keyup.enter="handleSearch"
          >
            <template #append>
              <el-button @click="handleSearch">
                <el-icon><Search /></el-icon>
              </el-button>
            </template>
          </el-input>
        </div>
        
        <div class="user-menu">
          <template v-if="userStore.user">
            <el-dropdown @command="handleCommand">
              <div class="user-info">
                <el-avatar :src="userStore.user?.avatar" :size="32">
                  {{ userStore.user?.nickname?.[0] || userStore.user?.username?.[0] }}
                </el-avatar>
                <span class="username">{{ userStore.user?.nickname || userStore.user?.username }}</span>
                <el-icon><ArrowDown /></el-icon>
              </div>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item command="profile">个人资料</el-dropdown-item>
                  <el-dropdown-item command="upload">上传视频</el-dropdown-item>
                  <el-dropdown-item command="logout" divided>退出登录</el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </template>
          <template v-else>
            <el-button type="primary" @click="router.push('/login')">登录</el-button>
          </template>
        </div>
      </div>
    </el-header>
    
    <!-- 主要内容区域 -->
    <div class="main-content">
      <!-- 侧边栏 -->
      <el-aside width="200px" class="sidebar">
        <el-menu
          :default-active="activeMenu"
          class="sidebar-menu"
          @select="handleMenuSelect"
        >
          <el-menu-item index="home">
            <el-icon><House /></el-icon>
            <span>首页</span>
          </el-menu-item>
          <el-menu-item index="trending">
            <el-icon><TrendCharts /></el-icon>
            <span>热门</span>
          </el-menu-item>
          <el-menu-item index="latest">
            <el-icon><Clock /></el-icon>
            <span>最新</span>
          </el-menu-item>
          <el-menu-item index="recommended">
            <el-icon><Star /></el-icon>
            <span>推荐</span>
          </el-menu-item>
          <el-menu-item index="favorites">
            <el-icon><Heart /></el-icon>
            <span>收藏</span>
          </el-menu-item>
          <el-menu-item index="liked">
            <el-icon><ThumbsUp /></el-icon>
            <span>点赞</span>
          </el-menu-item>
          <el-menu-item
            v-for="cat in categories"
            :key="cat.id"
            :index="'category-' + cat.id"
            :class="{ 'is-active': selectedCategoryId === cat.id }"
            @click="handleCategoryClick(cat.id)"
          >
            <el-icon><Grid /></el-icon>
            <span>{{ cat.name }}</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      
      <!-- 视频列表区域 -->
      <el-main class="video-content">
        <div class="content-header">
          <h3>{{ getPageTitle() }}</h3>
          <el-button type="primary" @click="$router.push('/upload')">
            <el-icon><Plus /></el-icon>
            上传视频
          </el-button>
        </div>
        
        <!-- 视频网格 -->
        <div class="video-grid" v-loading="loading">
          <div
            v-for="video in videos"
            :key="video.id"
            class="video-card"
            @click="goToVideo(video.id)"
            @mouseenter="handleVideoHover(video)"
            @mouseleave="handleVideoLeave"
          >
            <div class="video-thumbnail">
              <!-- 视频预览 -->
              <video 
                v-if="hoveredVideo?.id === video.id && video.status === 'APPROVED'"
                :src="getVideoUrl(video)"
                class="video-preview"
                muted
                preload="metadata"
                @loadedmetadata="onVideoLoaded"
                @canplay="onVideoCanPlay"
                @error="onVideoError"
              ></video>
              <!-- 缩略图 -->
              <img 
                v-else
                :src="getVideoThumbnail(video)" 
                :alt="video.title"
                class="thumbnail-image"
              >
              <div class="video-duration">{{ getDisplayDuration(video) }}</div>
              <!-- 播放按钮 -->
              <div class="play-button" v-if="hoveredVideo?.id === video.id">
                <el-icon size="24"><VideoPlay /></el-icon>
              </div>
            </div>
            <div class="video-info">
              <h4 class="video-title">{{ video.title }}</h4>
              <p class="video-author">{{ video.user.nickname || video.user.username }}</p>
              <div class="video-stats">
                <span>{{ formatNumber(video.viewCount) }} 次观看</span>
                <span>{{ formatTime(video.createdTime) }}</span>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 分页 -->
        <div class="pagination-container" v-if="totalPages > 1">
          <el-pagination
            v-model:current-page="currentPage"
            v-model:page-size="pageSize"
            :page-sizes="[12, 24, 48]"
            :total="total"
            layout="total, sizes, prev, pager, next, jumper"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
          />
        </div>
      </el-main>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { videoApi } from '@/api'
import type { Video } from '@/types'
import { ElMessage } from 'element-plus'
import { VideoPlay } from '@element-plus/icons-vue'
import { Grid } from '@element-plus/icons-vue'
import { categoryApi } from '@/api'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()

// 响应式数据
const videos = ref<Video[]>([])
const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(12)
const total = ref(0)
const searchKeyword = ref('')
const activeMenu = ref('home')
const hoveredVideo = ref<Video | null>(null)
const favoriteVideos = ref<Video[]>([])
const likedVideos = ref<Video[]>([])
const categories = ref([])
const selectedCategoryId = ref(null)
const videoDurations = ref<Record<number, number>>({})

// 计算属性
const totalPages = computed(() => Math.ceil(total.value / pageSize.value))

// 获取视频列表
const fetchVideos = async () => {
  loading.value = true
  try {
    let response
    const page = currentPage.value - 1 // 后端从0开始
    if (selectedCategoryId.value) {
      response = await videoApi.getVideosByCategory(selectedCategoryId.value, page, pageSize.value)
      videos.value = response.content || response
      total.value = response.totalElements || videos.value.length
    } else {
      switch (activeMenu.value) {
        case 'trending':
          response = await videoApi.getTrendingVideos(page, pageSize.value)
          videos.value = response
          total.value = response.length
          break
        case 'latest':
          response = await videoApi.getLatestVideos(page, pageSize.value)
          videos.value = response
          total.value = response.length
          break
        case 'recommended':
          response = await videoApi.getPersonalizedRecommendations(userStore.user.id, page, pageSize.value)
          videos.value = response
          total.value = response.length
          break
        case 'favorites':
          await fetchFavoriteVideos()
          videos.value = favoriteVideos.value
          break
        case 'liked':
          await fetchLikedVideos()
          videos.value = likedVideos.value
          break
        default:
          response = await videoApi.getAllVideos(page, pageSize.value)
          videos.value = response.content || []
          total.value = response.totalElements || videos.value.length
          break
      }
    }
  } catch (error) {
    console.error('获取视频列表失败:', error)
    ElMessage.error('获取视频列表失败')
    videos.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}

// 搜索视频
const handleSearch = async () => {
  if (!searchKeyword.value.trim()) {
    await fetchVideos()
    return
  }
  
  loading.value = true
  try {
    const response = await videoApi.searchVideos(searchKeyword.value, currentPage.value - 1, pageSize.value)
    videos.value = response.content
    total.value = response.totalElements
  } catch (error) {
    console.error('搜索失败:', error)
    ElMessage.error('搜索失败')
  } finally {
    loading.value = false
  }
}

// 菜单选择
const handleMenuSelect = (index: string) => {
  activeMenu.value = index
  currentPage.value = 1
  if (index === 'home') {
    selectedCategoryId.value = null // 切换首页时重置分类
  }
  fetchVideos()
}

// 分类点击
const handleCategoryClick = (catId: number) => {
  selectedCategoryId.value = catId
  activeMenu.value = '' // 取消其它菜单高亮
  currentPage.value = 1
  fetchVideos()
}

// 分页处理
const handleSizeChange = (size: number) => {
  pageSize.value = size
  currentPage.value = 1
  fetchVideos()
}

const handleCurrentChange = (page: number) => {
  currentPage.value = page
  fetchVideos()
}

// 用户菜单命令处理
const handleCommand = (command: string) => {
  switch (command) {
    case 'profile':
      router.push('/profile')
      break
    case 'upload':
      router.push('/upload')
      break
    case 'logout':
      userStore.logout()
      router.push('/home')
      break
  }
}

// 跳转到视频详情页
const goToVideo = (id: number) => {
  // 暂停所有预览视频，避免资源冲突
  document.querySelectorAll('.video-preview').forEach((el) => {
    try { (el as HTMLVideoElement).pause(); } catch {}
  });
  router.push(`/video/${id}`)
}

// 视频悬停处理
const handleVideoHover = (video: Video) => {
  hoveredVideo.value = video
}

const handleVideoLeave = () => {
  hoveredVideo.value = null
}

// 视频事件处理
const onVideoLoaded = (event: Event) => {
  const video = event.target as HTMLVideoElement
  if (video && hoveredVideo.value?.id) {
    // 视频加载完成后开始播放
    video.play().catch(() => {
      // 静音播放失败时忽略错误
    })
  }
}

const onVideoCanPlay = () => {
  console.log('视频可以播放')
}

const onVideoError = (event: Event) => {
  console.error('视频播放错误:', event)
}

// 获取页面标题
const getPageTitle = () => {
  const titles: Record<string, string> = {
    home: '推荐视频',
    trending: '热门视频',
    latest: '最新视频',
    recommended: '个性化推荐',
    favorites: '我的收藏',
    liked: '我的点赞'
  }
  return titles[activeMenu.value] || '推荐视频'
}

// 格式化数字
const formatNumber = (num: number) => {
  if (num >= 10000) {
    return (num / 10000).toFixed(1) + '万'
  }
  return num.toString()
}

// 格式化时间
const formatTime = (timeStr: string) => {
  const date = new Date(timeStr)
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  
  if (days === 0) return '今天'
  if (days === 1) return '昨天'
  if (days < 7) return `${days}天前`
  if (days < 30) return `${Math.floor(days / 7)}周前`
  if (days < 365) return `${Math.floor(days / 30)}个月前`
  return `${Math.floor(days / 365)}年前`
}

// 格式化时长
const formatDuration = (duration?: number) => {
  if (!duration) return '00:00'
  const minutes = Math.floor(duration / 60)
  const seconds = duration % 60
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
}

// 获取视频URL - 使用静态资源直链
const getVideoUrl = (video: Video) => {
  if (video && video.filePath) {
    return `/api/${video.filePath}`
  }
  return ''
}

// 获取视频缩略图
const getVideoThumbnail = (video: Video) => {
  if (video.thumbnailUrl) {
    if (video.thumbnailUrl.startsWith('http')) {
      return video.thumbnailUrl
    }
    // 如果是相对路径，拼接API地址
    return `/api/files/${video.thumbnailUrl.replace('/api/files/', '')}`
  }
  return '/default-thumbnail.jpg'
}

// 获取收藏视频列表
const fetchFavoriteVideos = async () => {
  if (!userStore.user) {
    favoriteVideos.value = []
    return
  }
  try {
    const response = await videoApi.getFavoriteVideosByUser(userStore.user.id, 0, pageSize.value)
    // 只用content字段，避免赋值整个response
    favoriteVideos.value = response.content || []
    total.value = response.totalElements || favoriteVideos.value.length
  } catch (error) {
    favoriteVideos.value = []
    total.value = 0
  }
}

// 获取点赞视频列表
const fetchLikedVideos = async () => {
  if (!userStore.user) {
    likedVideos.value = []
    return
  }
  try {
    const response = await videoApi.getLikedVideosByUser(userStore.user.id, 0, pageSize.value)
    likedVideos.value = response.content || response
    total.value = response.totalElements || likedVideos.value.length
  } catch (error) {
    likedVideos.value = []
    total.value = 0
  }
}

// 加载分类
const fetchCategories = async () => {
  try {
    const res = await categoryApi.getAllCategories()
    categories.value = res.content || res // 兼容分页和非分页
  } catch (e) {
    categories.value = []
  }
}

// 监听菜单切换自动刷新
watch(activeMenu, () => {
  currentPage.value = 1
  fetchVideos()
})

// 初始化
onMounted(() => {
  fetchCategories()
  fetchVideos()
})

const onLoadedMetadata = (video: Video, event: Event) => {
  const duration = (event.target as HTMLVideoElement).duration
  if (duration && !isNaN(duration)) {
    videoDurations.value[video.id] = duration
  }
}

const getDisplayDuration = (video: Video) => {
  // 优先用后端字段，无则用前端兜底
  const d = video.duration || videoDurations.value[video.id]
  if (!d) return '00:00'
  const minutes = Math.floor(d / 60)
  const seconds = Math.floor(d % 60)
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
}
</script>

<style scoped>
.home-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
}

.header {
  background: white;
  border-bottom: 1px solid #e4e7ed;
  padding: 0;
  height: 60px;
  line-height: 60px;
}

.header-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 100%;
  padding: 0 20px;
}

.logo h2 {
  margin: 0;
  color: #409eff;
  font-size: 20px;
}

.search-box {
  flex: 1;
  max-width: 400px;
  margin: 0 20px;
}

.search-input {
  width: 100%;
}

.user-menu {
  display: flex;
  align-items: center;
}

.user-info {
  display: flex;
  align-items: center;
  cursor: pointer;
  padding: 8px 12px;
  border-radius: 6px;
  transition: background-color 0.3s;
}

.user-info:hover {
  background-color: #f5f7fa;
}

.username {
  margin: 0 8px;
  font-size: 14px;
  color: #333;
}

.main-content {
  flex: 1;
  display: flex;
  overflow: hidden;
}

.sidebar {
  background: white;
  border-right: 1px solid #e4e7ed;
}

.sidebar-menu {
  border-right: none;
}

.video-content {
  padding: 20px;
  overflow-y: auto;
}

.content-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.content-header h3 {
  margin: 0;
  font-size: 24px;
  color: #333;
}

.video-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 30px;
}

.video-card {
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  cursor: pointer;
  transition: transform 0.3s, box-shadow 0.3s;
}

.video-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
}

.video-thumbnail {
  position: relative;
  width: 100%;
  height: 160px;
  overflow: hidden;
}

.video-thumbnail img,
.video-thumbnail video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.thumbnail-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.video-preview {
  width: 100%;
  height: 100%;
  object-fit: cover;
  background: #000;
}

.play-button {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(0, 0, 0, 0.7);
  color: white;
  border-radius: 50%;
  width: 48px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: none;
}

.video-duration {
  position: absolute;
  bottom: 8px;
  right: 8px;
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 12px;
}

.video-info {
  padding: 12px;
}

.video-title {
  margin: 0 0 8px 0;
  font-size: 14px;
  font-weight: 500;
  color: #333;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.video-author {
  margin: 0 0 8px 0;
  font-size: 12px;
  color: #666;
}

.video-stats {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #999;
}

.pagination-container {
  display: flex;
  justify-content: center;
  margin-top: 30px;
}

.sidebar-menu .is-active {
  background: #f0f7ff;
  color: #409eff;
}
</style> 