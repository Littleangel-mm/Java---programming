// 用户相关类型
export interface User {
  id: number
  username: string
  email: string
  nickname?: string
  avatar?: string
  bio?: string
  role: 'ADMIN' | 'USER'
  status: 'ACTIVE' | 'INACTIVE' | 'BANNED'
  age?: number
  phone?: string
  location?: string
  lastLoginTime?: string
  loginCount: number
  createdTime: string
  updatedTime: string
}

// 登录响应类型
export interface LoginResponse {
  token: string
  user: User
}

// 视频相关类型
export interface Video {
  id: number
  title: string
  description?: string
  filePath: string
  coverUrl?: string
  thumbnailUrl?: string
  duration?: number
  fileSize?: number
  resolution?: string
  format?: string
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'DELETED'
  visibility: 'PUBLIC' | 'PRIVATE' | 'UNLISTED'
  viewCount: number
  likeCount: number
  commentCount: number
  shareCount: number
  favoriteCount: number
  isApproved: boolean
  approvedTime?: string
  approvedBy?: number
  rejectReason?: string
  user: User
  category?: Category
  tags?: Tag[]
  createdTime: string
  updatedTime: string
}

// 分类类型
export interface Category {
  id: number
  name: string
  description?: string
  icon?: string
  color?: string
  sortOrder?: number
  isActive?: boolean
  createdTime: string
  updatedTime: string
}

// 标签类型
export interface Tag {
  id: number
  name: string
  createdTime: string
}

// 评论类型
export interface Comment {
  id: number
  content: string
  status: 'ACTIVE' | 'HIDDEN' | 'DELETED'
  likeCount: number
  replyCount: number
  user: User
  video: Video
  parent?: Comment
  replies?: Comment[]
  createdTime: string
  updatedTime: string
}

// API响应类型
export interface ApiResponse<T> {
  success: boolean
  message?: string
  data?: T
  timestamp: string
  code: number
}

// 分页类型
export interface PageResponse<T> {
  content: T[]
  totalElements: number
  totalPages: number
  size: number
  number: number
  first: boolean
  last: boolean
}

// 管理员仪表板统计类型
export interface DashboardStats {
  totalUsers: number
  totalVideos: number
  totalViews: number
  totalComments: number
  todayNewUsers: number
  todayNewVideos: number
  todayViews: number
  todayComments: number
  pendingVideos: number
  pendingComments: number
  reportedContent: number
}

// 系统信息类型
export interface SystemInfo {
  uptime: string
  cpuUsage: number
  memoryUsage: number
  diskUsage: number
  onlineUsers: number
} 