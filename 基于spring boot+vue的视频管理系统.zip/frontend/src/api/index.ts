import axios from 'axios'
import type { 
  User, 
  Video, 
  Comment, 
  Category, 
  Tag, 
  LoginResponse, 
  ApiResponse, 
  PageResponse,
  DashboardStats,
  SystemInfo
} from '@/types'

// 创建axios实例
const api = axios.create({
  baseURL: '/api',
  timeout: 10000
})

// 请求拦截器 - 添加token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    
    // 如果是FormData请求，删除默认的Content-Type，让浏览器自动设置
    if (config.data instanceof FormData) {
      delete config.headers['Content-Type']
    }
    
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// 响应拦截器 - 处理错误
api.interceptors.response.use(
  (response) => {
    return response.data
  },
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// 用户相关API
export const userApi = {
  // 用户注册
  register: (userData: Partial<User> & { password: string }) => 
    api.post<ApiResponse<LoginResponse>>('/users/register', userData),
  
  // 用户登录
  login: (username: string, password: string) => 
    api.post<ApiResponse<LoginResponse>>('/users/login', { username, password }),
  
  // 用户退出
  logout: () => 
    api.post<ApiResponse<any>>('/users/logout'),
  
  // 获取所有用户
  getAllUsers: (page = 0, size = 10, sortBy = 'id', sortDir = 'desc') => 
    api.get<PageResponse<User>>(`/users?page=${page}&size=${size}&sortBy=${sortBy}&sortDir=${sortDir}`),
  
  // 根据ID获取用户
  getUserById: (id: number) => 
    api.get<User>(`/users/${id}`),
  
  // 根据用户名获取用户
  getUserByUsername: (username: string) => 
    api.get<User>(`/users/username/${username}`),
  
  // 根据邮箱获取用户
  getUserByEmail: (email: string) => 
    api.get<User>(`/users/email/${email}`),
  
  // 更新用户资料
  updateProfile: (id: number, userData: Partial<User>) => 
    api.put<User>(`/users/${id}/profile`, userData),
  
  // 更新用户角色
  updateRole: (id: number, role: string) => 
    api.put<User>(`/users/${id}/role`, { role }),
  
  // 更新用户状态
  updateStatus: (id: number, status: string) => 
    api.put<User>(`/users/${id}/status`, { status }),
  
  // 删除用户
  deleteUser: (id: number) => 
    api.delete(`/users/${id}`),
  
  // 搜索用户
  searchUsers: (keyword: string, page = 0, size = 10) => 
    api.get<PageResponse<User>>(`/users/search?keyword=${keyword}&page=${page}&size=${size}`),
  
  // 根据角色获取用户
  getUsersByRole: (role: string) => 
    api.get<User[]>(`/users/role/${role}`),
  
  // 根据状态获取用户
  getUsersByStatus: (status: string) => 
    api.get<User[]>(`/users/status/${status}`),
  
  // 获取活跃用户
  getActiveUsers: (page = 0, size = 10, minLoginCount = 5) => 
    api.get<User[]>(`/users/active?page=${page}&size=${size}&minLoginCount=${minLoginCount}`),
  
  // 获取最近注册用户
  getRecentUsers: (page = 0, size = 10) => 
    api.get<User[]>(`/users/recent?page=${page}&size=${size}`),
  
  // 获取最近登录用户
  getRecentlyLoggedInUsers: (page = 0, size = 10) => 
    api.get<User[]>(`/users/recent-login?page=${page}&size=${size}`),
  
  // 关注用户
  followUser: (followerId: number, followingId: number) => 
    api.post(`/users/${followerId}/follow/${followingId}`),
  
  // 取消关注用户
  unfollowUser: (followerId: number, followingId: number) => 
    api.delete(`/users/${followerId}/follow/${followingId}`),
  
  // 检查是否关注
  isFollowing: (followerId: number, followingId: number) => 
    api.get(`/users/${followerId}/following/${followingId}`),
  
  // 获取粉丝列表
  getFollowers: (userId: number, page = 0, size = 10) => 
    api.get<User[]>(`/users/${userId}/followers?page=${page}&size=${size}`),
  
  // 获取关注列表
  getFollowing: (userId: number, page = 0, size = 10) => 
    api.get<User[]>(`/users/${userId}/following?page=${page}&size=${size}`),
  
  // 获取粉丝数量
  getFollowersCount: (userId: number) => 
    api.get<any>(`/users/${userId}/followers/count`),
  
  // 获取关注数量
  getFollowingCount: (userId: number) => 
    api.get<any>(`/users/${userId}/following/count`),
  
  // 修改密码
  changePassword: (id: number, oldPassword: string, newPassword: string) => 
    api.put(`/users/${id}/password`, { oldPassword, newPassword }),
  
  // 重置密码
  resetPassword: (id: number, newPassword: string) => 
    api.put(`/users/${id}/password/reset`, { newPassword }),
  
  // 批量更新用户状态
  batchUpdateUserStatus: (userIds: number[], status: string) => 
    api.put('/users/batch/status', { userIds, status }),
  
  // 批量删除用户
  batchDeleteUsers: (userIds: number[]) => 
    api.delete('/users/batch', { data: userIds }),
  
  // 获取用户统计
  getUserStats: () => 
    api.get<any>('/users/stats'),
  
  // 检查用户名是否存在
  checkUsername: (username: string) => 
    api.get(`/users/check-username/${username}`),
  
  // 检查邮箱是否存在
  checkEmail: (email: string) => 
    api.get(`/users/check-email/${email}`)
}

// 视频相关API
export const videoApi = {
  // 上传视频文件
  upload: (formData: FormData) => {
    return api.post<Video>('/videos/upload', formData, {
      headers: {
        // 不设置Content-Type，让浏览器自动处理
      }
    })
  },
  
  // 获取所有视频
  getAllVideos: (page = 0, size = 10, sortBy = 'createdTime', sortDir = 'desc') => 
    api.get<PageResponse<Video>>(`/videos?page=${page}&size=${size}&sortBy=${sortBy}&sortDir=${sortDir}`),
  
  // 根据ID获取视频
  getVideoById: (id: number) => 
    api.get<Video>(`/videos/${id}`),
  
  // 更新视频
  updateVideo: (id: number, videoData: Partial<Video>) => 
    api.put<Video>(`/videos/${id}`, videoData),
  
  // 删除视频
  deleteVideo: (id: number) => 
    api.delete(`/videos/${id}`),
  
  // 审核视频 - 通过
  approveVideo: (id: number, approvedBy: number) => 
    api.put<Video>(`/videos/${id}/approve?approvedBy=${approvedBy}`),
  
  // 审核视频 - 拒绝
  rejectVideo: (id: number, rejectedBy: number, reason: string) => 
    api.put<Video>(`/videos/${id}/reject?rejectedBy=${rejectedBy}`, { reason }),
  
  // 搜索视频
  searchVideos: (keyword: string, page = 0, size = 10) => 
    api.get<PageResponse<Video>>(`/videos/search?keyword=${keyword}&page=${page}&size=${size}`),
  
  // 根据用户获取视频
  getVideosByUser: (userId: number, page = 0, size = 10) => 
    api.get<PageResponse<Video>>(`/videos/user/${userId}?page=${page}&size=${size}`),
  
  // 根据分类获取视频
  getVideosByCategory: (categoryId: number, page = 0, size = 10) => 
    api.get<Video[]>(`/videos/category/${categoryId}?page=${page}&size=${size}`),
  
  // 根据状态获取视频
  getVideosByStatus: (status: string, page = 0, size = 10) => 
    api.get<PageResponse<Video>>(`/videos/status/${status}?page=${page}&size=${size}`),
  
  // 获取热门视频
  getPopularVideos: (page = 0, size = 10) => 
    api.get<Video[]>(`/videos/popular?page=${page}&size=${size}`),
  
  // 获取最新视频
  getLatestVideos: (page = 0, size = 10) => 
    api.get<Video[]>(`/videos/latest?page=${page}&size=${size}`),
  
  // 获取推荐视频
  getRecommendedVideos: (page = 0, size = 10) => 
    api.get<Video[]>(`/videos/recommended?page=${page}&size=${size}`),
  
  // 获取趋势视频
  getTrendingVideos: (page = 0, size = 10) => 
    api.get<Video[]>(`/videos/trending?page=${page}&size=${size}`),
  
  // 点赞视频
  likeVideo: (videoId: number, userId: number) => 
    api.post(`/videos/${videoId}/like?userId=${userId}`),
  
  // 取消点赞
  unlikeVideo: (videoId: number, userId: number) => 
    api.delete(`/videos/${videoId}/like?userId=${userId}`),
  
  // 检查是否已点赞
  isLikedByUser: (videoId: number, userId: number) => 
    api.get(`/videos/${videoId}/liked?userId=${userId}`),
  
  // 收藏视频
  favoriteVideo: (videoId: number, userId: number) => 
    api.post(`/videos/${videoId}/favorite?userId=${userId}`),
  
  // 取消收藏
  unfavoriteVideo: (videoId: number, userId: number) => 
    api.delete(`/videos/${videoId}/favorite?userId=${userId}`),
  
  // 检查是否已收藏
  isFavoritedByUser: (videoId: number, userId: number) => 
    api.get(`/videos/${videoId}/favorited?userId=${userId}`),
  
  // 获取用户点赞的视频
  getLikedVideosByUser: (userId: number, page = 0, size = 10) => 
    api.get<PageResponse<Video>>(`/videos/user/${userId}/liked?page=${page}&size=${size}`),
  
  // 获取用户收藏的视频
  getFavoriteVideosByUser: (userId: number, page = 0, size = 10) => 
    api.get<PageResponse<Video>>(`/videos/user/${userId}/favorites?page=${page}&size=${size}`),
  
  // 分享视频
  shareVideo: (videoId: number) => 
    api.post(`/videos/${videoId}/share`),
  
  // 获取待审核视频
  getPendingVideos: (page = 0, size = 10) => 
    api.get<PageResponse<Video>>(`/videos/pending?page=${page}&size=${size}`),
  
  // 获取被拒绝视频
  getRejectedVideos: (page = 0, size = 10) => 
    api.get<PageResponse<Video>>(`/videos/rejected?page=${page}&size=${size}`),
  
  // 获取已审核视频
  getApprovedVideos: (page = 0, size = 10) => 
    api.get<PageResponse<Video>>(`/videos/approved?page=${page}&size=${size}`),
  
  // 批量审核视频
  batchApproveVideos: (videoIds: number[], approvedBy: number) => 
    api.put('/videos/batch/approve', { videoIds, approvedBy }),
  
  // 批量拒绝视频
  batchRejectVideos: (videoIds: number[], rejectedBy: number, reason: string) => 
    api.put('/videos/batch/reject', { videoIds, rejectedBy, reason }),
  
  // 批量删除视频
  batchDeleteVideos: (videoIds: number[]) => 
    api.delete('/videos/batch', { data: videoIds }),
  
  // 获取个性化推荐
  getPersonalizedRecommendations: (userId: number, page = 0, size = 10) => 
    api.get<Video[]>(`/videos/personalized/${userId}?page=${page}&size=${size}`),
  
  // 获取相似视频
  getSimilarVideos: (videoId: number, page = 0, size = 10) => 
    api.get<Video[]>(`/videos/${videoId}/similar?page=${page}&size=${size}`),
  
  // 根据标签获取视频
  getVideosByTag: (tagName: string, page = 0, size = 10) => 
    api.get<Video[]>(`/videos/tag/${tagName}?page=${page}&size=${size}`),
  
  // 获取视频统计
  getVideoStats: () => 
    api.get<any>('/videos/stats'),
  
  // 刷新视频统计
  refreshVideoStatistics: (videoId: number) => 
    api.put(`/videos/${videoId}/refresh-stats`),
  
  // 视频播放接口 - 获取播放URL
  getVideoPlayUrl: (id: number) => 
    `/api/videos/stream-play/${id}`,
  
  // 获取视频流信息
  getVideoStreamInfo: (id: number) => 
    api.get<any>(`/videos/stream/${id}`)
}

// 评论相关API
export const commentApi = {
  // 获取视频评论
  getCommentsByVideo: (videoId: number, page = 0, size = 10) => 
    api.get<Comment[]>(`/comments/video/${videoId}?page=${page}&size=${size}`),
  
  // 添加评论
  addComment: (commentData: {
    content: string
    userId: number
    videoId: number
    parentCommentId?: number
  }) => {
    const { content, userId, videoId } = commentData
    return api.post<Comment>('/comments', { content }, {
      params: { userId, videoId }
    })
  },
  
  // 更新评论
  updateComment: (id: number, content: string) => 
    api.put<Comment>(`/comments/${id}`, { content }),
  
  // 删除评论
  deleteComment: (id: number) => 
    api.delete(`/comments/${id}`),
  
  // 点赞评论
  likeComment: (commentId: number, userId: number) => 
    api.post(`/comments/${commentId}/like?userId=${userId}`),
  
  // 取消点赞评论
  unlikeComment: (commentId: number, userId: number) => 
    api.delete(`/comments/${commentId}/like?userId=${userId}`),
  
  // 检查是否已点赞评论
  isLikedByUser: (commentId: number, userId: number) => 
    api.get(`/comments/${commentId}/liked?userId=${userId}`),
  
  // 获取所有评论
  getAllComments: (page = 0, size = 10) => 
    api.get<PageResponse<Comment>>(`/comments?page=${page}&size=${size}`),
  
  // 根据状态获取评论
  getCommentsByStatus: (status: string, page = 0, size = 10) => 
    api.get<Comment[]>(`/comments/status/${status}?page=${page}&size=${size}`),
  
  // 获取待审核评论
  getPendingComments: (page = 0, size = 10) => 
    api.get<Comment[]>(`/comments/pending?page=${page}&size=${size}`),
  
  // 审核评论 - 通过
  approveComment: (id: number, approvedBy: number) => 
    api.put<Comment>(`/comments/${id}/approve?approvedBy=${approvedBy}`),
  
  // 审核评论 - 拒绝
  rejectComment: (id: number, rejectedBy: number, reason: string) => 
    api.put<Comment>(`/comments/${id}/reject?rejectedBy=${rejectedBy}`, { reason }),
  
  // 批量审核评论
  batchApproveComments: (commentIds: number[], approvedBy: number) => 
    api.put('/comments/batch/approve', { commentIds, approvedBy }),
  
  // 批量拒绝评论
  batchRejectComments: (commentIds: number[], rejectedBy: number, reason: string) => 
    api.put('/comments/batch/reject', { commentIds, rejectedBy, reason }),
  
  // 批量删除评论
  batchDeleteComments: (commentIds: number[]) => 
    api.delete('/comments/batch', { data: commentIds }),
  
  // 获取评论统计
  getCommentStats: () => 
    api.get<any>('/comments/stats'),
  
  // 新增：评论分页列表
  getCommentList: (page = 0, size = 10) =>
    api.get<PageResponse<Comment>>(`/comments/page?page=${page}&size=${size}`),
  
  // 按视频ID分页获取评论
  getCommentsByVideoPaged: (videoId: number, page = 0, size = 20) =>
    api.get<PageResponse<Comment>>(`/comments/page?videoId=${videoId}&page=${page}&size=${size}`),
}

// 分类相关API
export const categoryApi = {
  // 获取所有分类
  getAllCategories: (page = 0, size = 10) => 
    api.get<PageResponse<Category>>(`/categories?page=${page}&size=${size}`),
  
  // 根据ID获取分类
  getCategoryById: (id: number) => 
    api.get<Category>(`/categories/${id}`),
  
  // 根据名称获取分类
  getCategoryByName: (name: string) => 
    api.get<Category>(`/categories/name/${name}`),
  
  // 创建分类
  createCategory: (categoryData: Partial<Category>) => 
    api.post<Category>('/categories', categoryData),
  
  // 更新分类
  updateCategory: (id: number, categoryData: Partial<Category>) => 
    api.put<Category>(`/categories/${id}`, categoryData),
  
  // 删除分类
  deleteCategory: (id: number) => 
    api.delete(`/categories/${id}`),
  
  // 更新分类状态
  updateCategoryStatus: (id: number, isActive: boolean) => 
    api.put<Category>(`/categories/${id}/status`, { isActive }),
  
  // 更新分类排序
  updateCategorySortOrder: (id: number, sortOrder: number) => 
    api.put<Category>(`/categories/${id}/sort-order`, { sortOrder }),
  
  // 根据状态获取分类
  getCategoriesByStatus: (isActive: boolean) => 
    api.get<Category[]>(`/categories/status/${isActive}`),
  
  // 获取活跃分类
  getActiveCategories: () => 
    api.get<Category[]>('/categories/active'),
  
  // 获取根分类
  getRootCategories: () => 
    api.get<Category[]>('/categories/root'),
  
  // 获取叶子分类
  getLeafCategories: () => 
    api.get<Category[]>('/categories/leaf'),
  
  // 获取分类树
  getCategoryTree: () => 
    api.get<Category[]>('/categories/tree'),
  
  // 获取子分类
  getSubCategories: (parentId: number) => 
    api.get<Category[]>(`/categories/${parentId}/subcategories`),
  
  // 获取分类路径
  getCategoryPath: (categoryId: number) => 
    api.get<Category[]>(`/categories/${categoryId}/path`),
  
  // 搜索分类
  searchCategories: (keyword: string, page = 0, size = 10) => 
    api.get<PageResponse<Category>>(`/categories/search?keyword=${keyword}&page=${page}&size=${size}`),
  
  // 批量更新分类状态
  batchUpdateCategoryStatus: (categoryIds: number[], isActive: boolean) => 
    api.put('/categories/batch/status', { categoryIds, isActive }),
  
  // 批量删除分类
  batchDeleteCategories: (categoryIds: number[]) => 
    api.delete('/categories/batch', { data: categoryIds }),
  
  // 获取热门分类
  getPopularCategories: (page = 0, size = 10) => 
    api.get<Category[]>(`/categories/popular?page=${page}&size=${size}`),
  
  // 获取趋势分类
  getTrendingCategories: (page = 0, size = 10) => 
    api.get<Category[]>(`/categories/trending?page=${page}&size=${size}`),
  
  // 刷新分类缓存
  refreshCategoryCache: () => 
    api.post('/categories/refresh-cache'),
  
  // 清除分类缓存
  clearCategoryCache: () => 
    api.delete('/categories/clear-cache'),
  
  // 导入分类
  importCategories: (categories: Category[]) => 
    api.post('/categories/import', categories),
  
  // 导出分类
  exportCategories: () => 
    api.get<Category[]>('/categories/export'),
  
  // 获取分类统计
  getCategoryStats: () => 
    api.get<any>('/categories/stats'),
  
  // 检查分类名称是否存在
  checkCategoryName: (name: string) => 
    api.get(`/categories/check-name/${name}`)
}

// 文件上传相关API
export const fileApi = {
  // 上传文件
  uploadFile: (file: File) => {
    const formData = new FormData()
    formData.append('file', file)
    return api.post('/files/upload', formData)
  },
  
  // 获取文件
  getFile: (year: string, month: string, day: string, filename: string) => 
    api.get(`/files/${year}/${month}/${day}/${filename}`, {
      responseType: 'blob'
    }),
  
  // 删除文件
  deleteFile: (year: string, month: string, day: string, filename: string) => 
    api.delete(`/files/${year}/${month}/${day}/${filename}`)
}

// 管理员相关API
export const adminApi = {
  // 获取仪表板统计
  getDashboardStats: () => 
    api.get<DashboardStats>('/admin/dashboard/stats'),
  
  // 获取系统信息
  getSystemInfo: () => 
    api.get<SystemInfo>('/admin/system/info')
}

// 管理后台专用API
export const adminVideoApi = {
  // 获取待审核视频
  getPendingVideos: (page = 0, size = 10) =>
    api.get<any>('/admin/audit/videos/pending?page=' + page + '&size=' + size),

  // 审核通过
  approveVideo: (id: number, adminId: number) =>
    api.post<any>(`/admin/audit/videos/${id}/approve?adminId=${adminId}`),

  // 审核拒绝
  rejectVideo: (id: number, adminId: number, reason: string) =>
    api.post<any>(`/admin/audit/videos/${id}/reject?adminId=${adminId}`, { reason }),

  // 批量审核通过
  batchApproveVideos: (videoIds: number[], adminId: number) =>
    api.post<any>('/admin/audit/videos/batch/approve', { videoIds, adminId }),

  // 批量审核拒绝
  batchRejectVideos: (videoIds: number[], adminId: number, reason: string) =>
    api.post<any>('/admin/audit/videos/batch/reject', { videoIds, adminId, reason }),

  // 获取审核统计
  getAuditStats: () =>
    api.get<any>('/admin/audit/videos/stats'),
}

export default api 