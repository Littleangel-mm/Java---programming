# SP视频平台前端

基于Vue 3 + TypeScript + Element Plus的现代化视频平台前端应用。

## 功能特性

### 用户功能
- 用户注册/登录
- 视频浏览和搜索
- 视频点赞/收藏
- 个人资料管理
- 视频上传

### 管理员功能
- 仪表板统计
- 用户管理
- 视频审核
- 评论管理
- 分类管理
- 系统监控

## 技术栈

- **Vue 3** - 渐进式JavaScript框架
- **TypeScript** - 类型安全的JavaScript
- **Vue Router** - 官方路由管理器
- **Pinia** - 状态管理库
- **Element Plus** - Vue 3组件库
- **Axios** - HTTP客户端
- **Vite** - 构建工具

## 项目结构

```
src/
├── api/           # API接口
├── assets/        # 静态资源
├── components/    # 公共组件
├── router/        # 路由配置
├── stores/        # 状态管理
├── types/         # TypeScript类型定义
├── utils/         # 工具函数
├── views/         # 页面组件
│   ├── admin/     # 管理员页面
│   └── ...
├── App.vue        # 根组件
└── main.ts        # 入口文件
```

## 开发环境要求

- Node.js 18.20.8+
- npm 或 yarn

## 安装和运行

1. 安装依赖
```bash
npm install
```

2. 启动开发服务器
```bash
npm run dev
```

3. 构建生产版本
```bash
npm run build
```

4. 预览生产版本
```bash
npm run preview
```

## 环境配置

项目已配置代理，开发时会自动代理API请求到后端服务器（http://localhost:8080）。

## 路由说明

### 公共路由
- `/login` - 登录页面
- `/register` - 注册页面

### 用户路由
- `/home` - 用户首页
- `/video/:id` - 视频详情页
- `/upload` - 视频上传页
- `/profile` - 个人资料页
- `/search` - 搜索页面

### 管理员路由
- `/admin/dashboard` - 仪表板
- `/admin/users` - 用户管理
- `/admin/videos` - 视频管理
- `/admin/comments` - 评论管理
- `/admin/categories` - 分类管理
- `/admin/system` - 系统设置

## 开发说明

### 状态管理
使用Pinia进行状态管理，主要包含：
- `userStore` - 用户状态管理

### API接口
所有API接口都封装在`src/api/index.ts`中，按功能模块分类：
- `userApi` - 用户相关接口
- `videoApi` - 视频相关接口
- `commentApi` - 评论相关接口
- `categoryApi` - 分类相关接口
- `adminApi` - 管理员相关接口

### 类型定义
所有TypeScript类型定义都在`src/types/index.ts`中。

## 部署

1. 构建项目
```bash
npm run build
```

2. 将`dist`目录下的文件部署到Web服务器

## 注意事项

- 确保后端API服务器正在运行
- 管理员用户需要后端数据库中用户角色设置为`ADMIN`
- 开发时建议使用Chrome浏览器以获得最佳体验 