# API接口指南

## 概述

本文档详细说明了前端Vue 3应用与后端Spring Boot API的接口对应关系，确保前后端数据交互正常。

## 基础配置

### 后端配置
- **服务端口**: 8080
- **上下文路径**: `/api`
- **跨域配置**: 已启用 `@CrossOrigin(origins = "*")`

### 前端配置
- **开发端口**: 3000
- **API代理**: `/api` -> `http://localhost:8080`
- **请求拦截器**: 自动添加Bearer Token
- **响应拦截器**: 处理401未授权跳转登录

## 用户相关接口

### 1. 用户认证

#### 用户注册
- **后端**: `POST /api/users/register`
- **前端**: `userApi.register(userData)`
- **请求参数**:
  ```typescript
  {
    username: string
    email: string
    password: string
    nickname?: string
  }
  ```
- **响应格式**:
  ```typescript
  {
    success: boolean
    message: string
    data: {
      token: string
      user: User
    }
  }
  ```

#### 用户登录
- **后端**: `POST /api/users/login`
- **前端**: `userApi.login(username, password)`
- **请求参数**:
  ```typescript
  {
    username: string
    password: string
  }
  ```
- **响应格式**: 同注册接口

#### 用户退出
- **后端**: `POST /api/users/logout`
- **前端**: `userApi.logout()`

### 2. 用户管理

#### 获取用户列表
- **后端**: `GET /api/users?page=0&size=10&sortBy=id&sortDir=desc`
- **前端**: `userApi.getAllUsers(page, size, sortBy, sortDir)`

#### 获取用户详情
- **后端**: `GET /api/users/{id}`
- **前端**: `userApi.getUserById(id)`

#### 更新用户资料
- **后端**: `PUT /api/users/{id}/profile`
- **前端**: `userApi.updateProfile(id, userData)`

#### 更新用户角色
- **后端**: `PUT /api/users/{id}/role`
- **前端**: `userApi.updateRole(id, role)`

#### 更新用户状态
- **后端**: `PUT /api/users/{id}/status`
- **前端**: `userApi.updateStatus(id, status)`

#### 删除用户
- **后端**: `DELETE /api/users/{id}`
- **前端**: `userApi.deleteUser(id)`

### 3. 用户统计
- **后端**: `GET /api/users/stats`
- **前端**: `userApi.getUserStats()`

## 视频相关接口

### 1. 视频管理

#### 上传视频
- **后端**: `POST /api/videos/upload`
- **前端**: `videoApi.upload(videoData)`
- **请求参数**:
  ```typescript
  {
    title: string
    description?: string
    videoUrl: string
    userId: number
    categoryId?: number
  }
  ```

#### 获取视频列表
- **后端**: `GET /api/videos?page=0&size=10&sortBy=id&sortDir=desc`
- **前端**: `videoApi.getAllVideos(page, size, sortBy, sortDir)`

#### 获取视频详情
- **后端**: `GET /api/videos/{id}`
- **前端**: `videoApi.getVideoById(id)`

#### 更新视频
- **后端**: `PUT /api/videos/{id}`
- **前端**: `videoApi.updateVideo(id, videoData)`

#### 删除视频
- **后端**: `DELETE /api/videos/{id}`
- **前端**: `videoApi.deleteVideo(id)`

### 2. 视频审核

#### 审核通过
- **后端**: `PUT /api/videos/{id}/approve?approvedBy={userId}`
- **前端**: `videoApi.approveVideo(id, approvedBy)`

#### 审核拒绝
- **后端**: `PUT /api/videos/{id}/reject?rejectedBy={userId}`
- **前端**: `videoApi.rejectVideo(id, rejectedBy, reason)`

#### 获取待审核视频
- **后端**: `GET /api/videos/pending?page=0&size=10`
- **前端**: `videoApi.getPendingVideos(page, size)`

### 3. 视频互动

#### 点赞视频
- **后端**: `POST /api/videos/{videoId}/like?userId={userId}`
- **前端**: `videoApi.likeVideo(videoId, userId)`

#### 取消点赞
- **后端**: `DELETE /api/videos/{videoId}/like?userId={userId}`
- **前端**: `videoApi.unlikeVideo(videoId, userId)`

#### 收藏视频
- **后端**: `POST /api/videos/{videoId}/favorite?userId={userId}`
- **前端**: `videoApi.favoriteVideo(videoId, userId)`

#### 取消收藏
- **后端**: `DELETE /api/videos/{videoId}/favorite?userId={userId}`
- **前端**: `videoApi.unfavoriteVideo(videoId, userId)`

### 4. 视频分类

#### 获取热门视频
- **后端**: `GET /api/videos/popular?page=0&size=10`
- **前端**: `videoApi.getPopularVideos(page, size)`

#### 获取最新视频
- **后端**: `GET /api/videos/latest?page=0&size=10`
- **前端**: `videoApi.getLatestVideos(page, size)`

#### 获取推荐视频
- **后端**: `GET /api/videos/recommended?page=0&size=10`
- **前端**: `videoApi.getRecommendedVideos(page, size)`

#### 获取趋势视频
- **后端**: `GET /api/videos/trending?page=0&size=10`
- **前端**: `videoApi.getTrendingVideos(page, size)`

### 5. 视频搜索
- **后端**: `GET /api/videos/search?keyword={keyword}&page=0&size=10`
- **前端**: `videoApi.searchVideos(keyword, page, size)`

### 6. 视频统计
- **后端**: `GET /api/videos/stats`
- **前端**: `videoApi.getVideoStats()`

## 评论相关接口

### 1. 评论管理

#### 添加评论
- **后端**: `POST /api/comments?userId={userId}&videoId={videoId}`
- **前端**: `commentApi.addComment({ content, userId, videoId })`
- **请求体**: `{ content: string }`

#### 获取视频评论
- **后端**: `GET /api/comments/video/{videoId}?page=0&size=10`
- **前端**: `commentApi.getCommentsByVideo(videoId, page, size)`

#### 更新评论
- **后端**: `PUT /api/comments/{id}`
- **前端**: `commentApi.updateComment(id, content)`

#### 删除评论
- **后端**: `DELETE /api/comments/{id}`
- **前端**: `commentApi.deleteComment(id)`

### 2. 评论审核

#### 审核通过
- **后端**: `PUT /api/comments/{id}/approve?approvedBy={userId}`
- **前端**: `commentApi.approveComment(id, approvedBy)`

#### 审核拒绝
- **后端**: `PUT /api/comments/{id}/reject?rejectedBy={userId}`
- **前端**: `commentApi.rejectComment(id, rejectedBy, reason)`

#### 获取待审核评论
- **后端**: `GET /api/comments/pending?page=0&size=10`
- **前端**: `commentApi.getPendingComments(page, size)`

### 3. 评论互动

#### 点赞评论
- **后端**: `POST /api/comments/{commentId}/like?userId={userId}`
- **前端**: `commentApi.likeComment(commentId, userId)`

#### 取消点赞评论
- **后端**: `DELETE /api/comments/{commentId}/like?userId={userId}`
- **前端**: `commentApi.unlikeComment(commentId, userId)`

### 4. 评论统计
- **后端**: `GET /api/comments/stats`
- **前端**: `commentApi.getCommentStats()`

## 分类相关接口

### 1. 分类管理

#### 获取分类列表
- **后端**: `GET /api/categories?page=0&size=10`
- **前端**: `categoryApi.getAllCategories(page, size)`

#### 获取分类详情
- **后端**: `GET /api/categories/{id}`
- **前端**: `categoryApi.getCategoryById(id)`

#### 创建分类
- **后端**: `POST /api/categories`
- **前端**: `categoryApi.createCategory(categoryData)`

#### 更新分类
- **后端**: `PUT /api/categories/{id}`
- **前端**: `categoryApi.updateCategory(id, categoryData)`

#### 删除分类
- **后端**: `DELETE /api/categories/{id}`
- **前端**: `categoryApi.deleteCategory(id)`

### 2. 分类查询

#### 获取活跃分类
- **后端**: `GET /api/categories/active`
- **前端**: `categoryApi.getActiveCategories()`

#### 获取分类树
- **后端**: `GET /api/categories/tree`
- **前端**: `categoryApi.getCategoryTree()`

#### 获取根分类
- **后端**: `GET /api/categories/root`
- **前端**: `categoryApi.getRootCategories()`

#### 获取子分类
- **后端**: `GET /api/categories/{parentId}/subcategories`
- **前端**: `categoryApi.getSubCategories(parentId)`

### 3. 分类统计
- **后端**: `GET /api/categories/stats`
- **前端**: `categoryApi.getCategoryStats()`

## 管理员相关接口

### 1. 仪表板统计
- **后端**: `GET /api/admin/dashboard/stats`
- **前端**: `adminApi.getDashboardStats()`

### 2. 系统信息
- **后端**: `GET /api/admin/system/info`
- **前端**: `adminApi.getSystemInfo()`

## 数据类型定义

### User 用户类型
```typescript
interface User {
  id: number
  username: string
  email: string
  nickname?: string
  avatar?: string
  bio?: string
  role: 'ADMIN' | 'USER'
  status: 'ACTIVE' | 'INACTIVE' | 'BANNED'
  age?: number
  phone?: string
  location?: string
  lastLoginTime?: string
  loginCount: number
  createdTime: string
  updatedTime: string
}
```

### Video 视频类型
```typescript
interface Video {
  id: number
  title: string
  description?: string
  videoUrl: string
  coverUrl?: string
  thumbnailUrl?: string
  duration?: number
  fileSize?: number
  resolution?: string
  format?: string
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'DELETED'
  visibility: 'PUBLIC' | 'PRIVATE' | 'UNLISTED'
  viewCount: number
  likeCount: number
  commentCount: number
  shareCount: number
  favoriteCount: number
  isApproved: boolean
  approvedTime?: string
  approvedBy?: number
  rejectReason?: string
  user: User
  category?: Category
  tags?: Tag[]
  createdTime: string
  updatedTime: string
}
```

### Comment 评论类型
```typescript
interface Comment {
  id: number
  content: string
  status: 'ACTIVE' | 'HIDDEN' | 'DELETED'
  likeCount: number
  replyCount: number
  user: User
  video: Video
  parent?: Comment
  replies?: Comment[]
  createdTime: string
  updatedTime: string
}
```

### Category 分类类型
```typescript
interface Category {
  id: number
  name: string
  description?: string
  isActive?: boolean
  sortOrder?: number
  parentId?: number
  createdTime: string
  updatedTime: string
}
```

## 错误处理

### 统一响应格式
```typescript
interface ApiResponse<T> {
  success: boolean
  message?: string
  data?: T
  timestamp: string
  code: number
}
```

### 分页响应格式
```typescript
interface PageResponse<T> {
  content: T[]
  totalElements: number
  totalPages: number
  size: number
  number: number
  first: boolean
  last: boolean
}
```

## 测试工具

前端提供了API测试工具 `frontend/src/utils/apiTest.ts`，可以自动测试所有接口的连接性：

```typescript
import { apiTester } from '@/utils/apiTest'

// 运行所有API测试
await apiTester.runAllTests()
```

## 注意事项

1. **Token认证**: 前端会自动在请求头中添加Bearer Token
2. **错误处理**: 401错误会自动跳转到登录页面
3. **跨域配置**: 后端已配置允许所有来源的跨域请求
4. **分页参数**: 所有列表接口都支持分页，默认page=0, size=10
5. **时间格式**: 所有时间字段使用ISO 8601格式字符串

## 常见问题

### Q: 接口返回404错误
A: 检查后端服务是否启动，端口是否为8080，上下文路径是否为/api

### Q: 跨域问题
A: 确保后端已配置@CrossOrigin注解，前端代理配置正确

### Q: 认证失败
A: 检查token是否正确设置，用户是否已登录

### Q: 数据类型不匹配
A: 确保前端类型定义与后端实体类字段一致 