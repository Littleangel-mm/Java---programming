# 视频平台项目

这是一个基于Spring Boot + Vue.js的视频分享平台，采用B/S架构。

## 项目结构

### 前台功能
- 首页
- 视频列表
- 视频详情页
- 交互中心
- 个人中心

### 后台功能
- 总览
- 视频管理
- 分类管理
- 标签管理
- 评论管理
- 用户管理
- 运营管理
- 日志管理
- 系统信息

## 数据库设计

### 核心表结构

#### 1. 用户表 (users)
- **功能**: 存储用户基本信息
- **主要字段**:
  - `id`: 主键
  - `username`: 用户名（唯一）
  - `password`: 密码（加密存储）
  - `email`: 邮箱（唯一）
  - `nickname`: 昵称
  - `avatar`: 头像URL
  - `role`: 角色（ADMIN/USER）
  - `status`: 状态（ACTIVE/INACTIVE/BANNED）
  - `last_login_time`: 最后登录时间
  - `login_count`: 登录次数

#### 2. 视频表 (videos)
- **功能**: 存储视频信息
- **主要字段**:
  - `id`: 主键
  - `title`: 视频标题
  - `description`: 视频描述
  - `video_url`: 视频文件URL
  - `cover_url`: 封面图片URL
  - `duration`: 视频时长（秒）
  - `file_size`: 文件大小
  - `status`: 状态（PENDING/APPROVED/REJECTED/DELETED）
  - `visibility`: 可见性（PUBLIC/PRIVATE/UNLISTED）
  - `view_count`: 观看次数
  - `like_count`: 点赞次数
  - `comment_count`: 评论次数
  - `user_id`: 发布者ID
  - `category_id`: 分类ID

#### 3. 分类表 (categories)
- **功能**: 视频分类管理
- **主要字段**:
  - `id`: 主键
  - `name`: 分类名称（唯一）
  - `description`: 分类描述
  - `icon`: 分类图标
  - `color`: 分类颜色
  - `sort_order`: 排序顺序
  - `is_active`: 是否激活

#### 4. 标签表 (tags)
- **功能**: 视频标签管理
- **主要字段**:
  - `id`: 主键
  - `name`: 标签名称（唯一）
  - `description`: 标签描述
  - `color`: 标签颜色
  - `use_count`: 使用次数
  - `is_active`: 是否激活

#### 5. 评论表 (comments)
- **功能**: 视频评论系统（支持多级评论）
- **主要字段**:
  - `id`: 主键
  - `content`: 评论内容
  - `status`: 状态（ACTIVE/HIDDEN/DELETED）
  - `like_count`: 点赞次数
  - `reply_count`: 回复次数
  - `user_id`: 评论者ID
  - `video_id`: 视频ID
  - `parent_id`: 父评论ID（支持多级评论）

### 关联表

#### 1. 视频标签关联表 (video_tags)
- 多对多关系：视频 ↔ 标签

#### 2. 用户点赞视频表 (user_likes)
- 多对多关系：用户 ↔ 视频（点赞）

#### 3. 用户收藏视频表 (user_favorites)
- 多对多关系：用户 ↔ 视频（收藏）

#### 4. 用户关注表 (user_follows)
- 多对多关系：用户 ↔ 用户（关注）

#### 5. 评论点赞表 (comment_likes)
- 多对多关系：评论 ↔ 用户（点赞）

### 管理表

#### 1. 系统日志表 (system_logs)
- **功能**: 记录系统操作日志
- **主要字段**:
  - `level`: 日志级别（INFO/WARN/ERROR/DEBUG）
  - `type`: 操作类型（LOGIN/LOGOUT/CREATE/UPDATE/DELETE等）
  - `user_id`: 操作用户ID
  - `ip_address`: IP地址
  - `message`: 日志消息
  - `request_url`: 请求URL
  - `execution_time`: 执行时间

#### 2. 运营管理表 (operations)
- **功能**: 运营活动管理
- **主要字段**:
  - `type`: 操作类型（PROMOTION/BANNER/NOTIFICATION等）
  - `title`: 活动标题
  - `description`: 活动描述
  - `target_type`: 目标类型（VIDEO/USER/CATEGORY/SYSTEM）
  - `target_id`: 目标ID
  - `status`: 状态（PENDING/ACTIVE/COMPLETED/CANCELLED）
  - `start_time`: 开始时间
  - `end_time`: 结束时间

#### 3. 系统信息表 (system_info)
- **功能**: 系统配置管理
- **主要字段**:
  - `config_key`: 配置键（唯一）
  - `config_value`: 配置值
  - `description`: 配置描述
  - `type`: 配置类型（SYSTEM/FEATURE/LIMIT/NOTIFICATION/SECURITY）
  - `is_active`: 是否激活

## 数据库关系图

```
users (用户)
├── videos (发布的视频)
├── comments (发表的评论)
├── likedVideos (点赞的视频)
├── favoriteVideos (收藏的视频)
├── following (关注的用户)
└── followers (粉丝)

videos (视频)
├── user (发布者)
├── category (分类)
├── tags (标签)
├── comments (评论)
├── likedByUsers (点赞用户)
└── favoritedByUsers (收藏用户)

categories (分类)
└── videos (分类下的视频)

tags (标签)
└── videos (使用该标签的视频)

comments (评论)
├── user (评论者)
├── video (视频)
├── parent (父评论)
└── replies (子评论)
```

## 技术栈

### 后端
- Spring Boot 2.6.13
- Spring Data JPA
- Spring Security
- MySQL 8.0
- JWT认证
- Lombok (简化实体类代码)

### 前端
- Vue.js 3.x
- Element Plus
- Axios
- Vue Router

## 快速开始

### 1. 数据库配置
1. 创建MySQL数据库
2. 执行 `src/main/resources/db/init.sql` 初始化数据库
3. 修改 `application.properties` 中的数据库连接信息

### 2. 启动后端
```bash
mvn spring-boot:run
```

### 3. 默认管理员账户
- 用户名: admin
- 密码: admin123

## 主要特性

1. **用户管理**: 支持用户注册、登录、角色管理
2. **视频管理**: 视频上传、分类、标签、审核
3. **社交功能**: 点赞、收藏、关注、评论
4. **内容审核**: 视频审核机制
5. **运营管理**: 活动管理、系统配置
6. **日志记录**: 完整的操作日志记录
7. **权限控制**: 基于角色的权限管理
8. **代码简化**: 使用Lombok简化实体类代码

## 数据库索引优化

为提高查询性能，在以下字段上创建了索引：
- 用户表: username, email, role, status
- 视频表: title, status, user_id, category_id, created_time, view_count
- 评论表: video_id, user_id, parent_id, created_time
- 系统日志表: level, type, user_id, created_time 