from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox, QFileDialog
from PyQt5.QtGui import QPixmap, QFont, QPalette, QColor, QLinearGradient, QBrush
from PyQt5.QtCore import Qt
import json
import os

class DeletePersonWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__()
        self.parent_window = parent
        self.setWindowTitle("删除人物信息")
        self.resize(600, 500)
        self.person_data = None
        self.original_country = None
        self.init_ui()

    def init_ui(self):
        # 主布局
        self.main_layout = QVBoxLayout()

        # 标题
        title = QLabel('🗑 删除人物信息 🗑')
        title.setFont(QFont('Arial', 20, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: white; margin-bottom: 20px;")
        self.main_layout.addWidget(title)

        # ID 输入与查找
        hl = QHBoxLayout()
        self.id_input = QLineEdit()
        self.id_input.setPlaceholderText("请输入人物 ID")
        self.id_input.setFont(QFont('Arial', 12))
        self.id_input.setFixedHeight(35)
        hl.addWidget(QLabel("ID:"))
        hl.addWidget(self.id_input)
        self.search_button = QPushButton("查找")
        self.search_button.setFont(QFont('Arial', 12))
        self.search_button.setFixedHeight(35)
        self.search_button.clicked.connect(self.search_person)
        hl.addWidget(self.search_button)
        hl.addStretch()
        self.main_layout.addLayout(hl)

        # 信息展示区
        self.info_layout = QVBoxLayout()
        # 图片
        self.photo_label = QLabel()
        self.photo_label.setFixedSize(150, 150)
        self.photo_label.setAlignment(Qt.AlignCenter)
        self.photo_label.setStyleSheet("border:1px solid #ccc; border-radius:5px;")
        self.info_layout.addWidget(self.photo_label, alignment=Qt.AlignCenter)
        # 姓名
        self.name_label = QLabel()
        self.name_label.setFont(QFont('Arial', 12))
        self.info_layout.addWidget(self.name_label, alignment=Qt.AlignCenter)
        # 国籍
        self.country_label = QLabel()
        self.country_label.setFont(QFont('Arial', 12))
        self.info_layout.addWidget(self.country_label, alignment=Qt.AlignCenter)

        self.main_layout.addLayout(self.info_layout)

        # 操作按钮
        btn_layout = QHBoxLayout()
        self.delete_button = QPushButton("删除")
        self.delete_button.setFont(QFont('Arial', 12))
        self.delete_button.setFixedHeight(40)
        self.delete_button.setEnabled(False)
        self.delete_button.clicked.connect(self.delete_person)
        btn_layout.addWidget(self.delete_button)

        self.back_button = QPushButton("返回")
        self.back_button.setFont(QFont('Arial', 12))
        self.back_button.setFixedHeight(40)
        self.back_button.clicked.connect(self.return_to_parent)
        btn_layout.addWidget(self.back_button)
        btn_layout.addStretch()
        self.main_layout.addLayout(btn_layout)

        self.setLayout(self.main_layout)
        self.update_background()

    def update_background(self):
        palette = QPalette()
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0.0, QColor(58, 123, 213))
        gradient.setColorAt(1.0, QColor(58, 213, 180))
        palette.setBrush(QPalette.Window, QBrush(gradient))
        self.setPalette(palette)

    def search_person(self):
        pid = self.id_input.text().strip()
        if not pid:
            QMessageBox.warning(self, "提示", "请输入 ID")
            return
        path = 'static/json/countries.json'
        if not os.path.exists(path):
            QMessageBox.warning(self, "错误", f"找不到 {path}")
            return
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        found = False
        for country, info in data.items():
            for person in info.get("人员", []):
                if person.get("id") == pid:
                    self.person_data = person
                    self.original_country = country
                    found = True
                    break
            if found:
                break
        if found:
            # 显示图片
            rel = self.person_data.get("photo", "")
            img_path = os.path.join('static', rel) if not os.path.isabs(rel) else rel
            if os.path.exists(img_path):
                self.photo_label.setPixmap(QPixmap(img_path).scaled(150, 150, Qt.KeepAspectRatio))
            else:
                self.photo_label.setText("无图片")
            # 显示姓名和国籍
            self.name_label.setText(f"姓名: {self.person_data.get('name', '')}")
            self.country_label.setText(f"国籍: {self.original_country}")
            self.delete_button.setEnabled(True)
        else:
            QMessageBox.warning(self, "提示", "未找到该人物")

    def delete_person(self):
        if not self.person_data or not self.original_country:
            return
        path = 'static/json/countries.json'
        with open(path, 'r+', encoding='utf-8') as f:
            data = json.load(f)
            # 删除条目
            new_list = [p for p in data[self.original_country]["人员"] if p["id"] != self.person_data["id"]]
            data[self.original_country]["人员"] = new_list
            # 写回
            f.seek(0)
            json.dump(data, f, ensure_ascii=False, indent=4)
            f.truncate()
        # 删除图片文件
        rel = self.person_data.get("photo", "")
        img_path = os.path.join('static', rel) if not os.path.isabs(rel) else rel
        if os.path.exists(img_path):
            os.remove(img_path)
        QMessageBox.information(self, "成功", "删除成功！")
        self.clear()

    def clear(self):
        self.id_input.clear()
        self.photo_label.clear()
        self.name_label.clear()
        self.country_label.clear()
        self.delete_button.setEnabled(False)
        self.person_data = None
        self.original_country = None

    def return_to_parent(self):
        if self.parent_window:
            self.parent_window.show()
        self.close()
