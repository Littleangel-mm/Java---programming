import os
import json
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton,
    QScrollArea, QGridLayout, QFrame, QComboBox
)
from PyQt5.QtGui import QFont, QPixmap, QPalette, QColor, QLinearGradient, QBrush
from PyQt5.QtCore import Qt

class QueryPersonWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("查询人物")
        self.resize(600, 700)

        title = QLabel("查询人物", self)
        title.setFont(QFont("Arial", 20, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: white; margin: 20px;")

        self.combo_country = QComboBox()
        self.combo_country.setFont(QFont("Arial", 12))
        self.combo_country.currentIndexChanged.connect(self.load_persons)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)

        container = QWidget()
        self.grid_layout = QGridLayout()
        container.setLayout(self.grid_layout)
        self.scroll_area.setWidget(container)

        btn_back = QPushButton("返回")
        btn_back.setFont(QFont("Arial", 12))
        btn_back.clicked.connect(self.go_back)

        layout = QVBoxLayout()
        layout.addWidget(title)
        layout.addWidget(QLabel("选择国家："))
        layout.addWidget(self.combo_country)
        layout.addWidget(self.scroll_area)
        layout.addWidget(btn_back)

        self.setLayout(layout)
        self.update_background()
        self.load_country_list()

    def update_background(self):
        palette = QPalette()
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0.0, QColor(58, 123, 213))
        gradient.setColorAt(1.0, QColor(58, 213, 180))
        palette.setBrush(QPalette.Window, QBrush(gradient))
        self.setPalette(palette)

    def load_country_list(self):
        json_path = os.path.join("static", "json", "countries.json")
        if os.path.exists(json_path):
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.combo_country.addItems(list(data.keys()))
                self.combo_country.addItem("全部")

    def load_persons(self):
        country_name = self.combo_country.currentText()
        json_path = os.path.join("static", "json", "countries.json")

        if not os.path.exists(json_path) or not country_name:
            return

        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        for i in reversed(range(self.grid_layout.count())):
            widget = self.grid_layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

        row = col = 0

        if country_name == "全部":
            for country_name, country_data in data.items():
                persons = country_data.get("人员", [])
                for person in persons:
                    card = self.create_person_card(person, country_name)
                    self.grid_layout.addWidget(card, row, col)
                    col += 1
                    if col == 3:
                        col = 0
                        row += 1
        else:
            persons = data.get(country_name, {}).get("人员", [])
            for person in persons:
                card = self.create_person_card(person, country_name)
                self.grid_layout.addWidget(card, row, col)
                col += 1
                if col == 3:
                    col = 0
                    row += 1

    def create_person_card(self, person, country_name):
        card = QFrame()
        card.setStyleSheet("""
            QFrame {
                background-color: rgba(255, 255, 255, 0.9);
                border-radius: 10px;
                padding: 10px;
            }
        """)
        card.setFixedSize(180, 280)  # 增加高度以容纳位置标签
        layout = QVBoxLayout(card)
        layout.setSpacing(5)  # 减少间距以优化布局

        # 图片
        img_label = QLabel()
        photo_path = os.path.join("static", person.get("photo", ""))
        if os.path.exists(photo_path):
            pixmap = QPixmap(photo_path).scaled(
                160, 160, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            img_label.setPixmap(pixmap)
            img_label.setAlignment(Qt.AlignCenter)
            img_label.setFixedSize(160, 160)  # 固定图片区域
        else:
            img_label.setText("无照片")
            img_label.setFixedSize(160, 160)
            img_label.setAlignment(Qt.AlignCenter)
            img_label.setStyleSheet("""
                QLabel {
                    color: #666;
                    font-size: 12px;
                    font-weight: bold;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    background-color: rgba(240, 240, 240, 0.8);
                }
            """)

        # 信息标签样式
        info_style = """
            QLabel {
                color: #333;
                font-size: 9px;
                font-weight: bold;
                padding: 3px;
                background-color: rgba(255, 255, 255, 0.7);
                border-radius: 3px;
            }
        """

        # 信息标签
        id_label = QLabel(f"ID: {person.get('id', '未知')}")
        id_label.setStyleSheet(info_style)
        id_label.setAlignment(Qt.AlignLeft)

        country_label = QLabel(f"国籍: {country_name}")
        country_label.setStyleSheet(info_style)
        country_label.setAlignment(Qt.AlignLeft)

        name_label = QLabel(f"姓名: {person.get('name', '未知')}")
        name_label.setStyleSheet(info_style)
        name_label.setAlignment(Qt.AlignLeft)

        position_label = QLabel(f"位置: {person.get('position', '未知')}")
        position_label.setStyleSheet(info_style)
        position_label.setAlignment(Qt.AlignLeft)

        # 布局
        layout.addWidget(img_label)
        layout.addWidget(id_label)
        layout.addWidget(country_label)
        layout.addWidget(name_label)
        layout.addWidget(position_label)
        layout.addStretch()  # 内容靠上

        return card

    def go_back(self):
        self.parent.show()
        self.close()