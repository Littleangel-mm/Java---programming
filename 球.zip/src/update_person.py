from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout, QPushButton, QLineEdit, QMessageBox, QFileDialog
from PyQt5.QtGui import QPixmap, QFont, QPalette, QColor, QLinearGradient, QBrush
from PyQt5.QtCore import Qt
import json
import os
import shutil


class UpdatePersonWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__()
        self.parent_window = parent
        self.setWindowTitle("修改人物信息")
        self.resize(800, 600)
        self.setWindowFlags(Qt.Window)
        self.person_data = None
        self.original_country = None
        self.new_photo_path = None
        self.init_ui()

    def init_ui(self):
        self.main_layout = QVBoxLayout()

        title = QLabel('📝 修改人物信息 📝')
        title.setFont(QFont('Arial', 20, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: white; margin-bottom: 30px;")
        self.main_layout.addWidget(title)

        # ID 输入和查找
        id_layout = QHBoxLayout()
        self.id_input = QLineEdit()
        self.id_input.setPlaceholderText("请输入人物 ID")
        self.id_input.setFont(QFont('Arial', 12))
        self.id_input.setFixedHeight(40)
        id_layout.addWidget(QLabel("ID:"))
        id_layout.addWidget(self.id_input)
        
        self.search_button = QPushButton("查找")
        self.search_button.setFixedHeight(40)
        self.search_button.setFont(QFont('Arial', 12))
        self.search_button.setStyleSheet(self.button_style())
        self.search_button.clicked.connect(self.search_person)
        id_layout.addWidget(self.search_button)
        id_layout.addStretch()
        self.main_layout.addLayout(id_layout)

        # 信息展示区
        self.info_layout = QVBoxLayout()

        # 头像
        self.photo_label = QLabel()
        self.photo_label.setFixedSize(150, 150)
        self.photo_label.setAlignment(Qt.AlignCenter)
        self.photo_label.setStyleSheet("border:1px solid #ccc; border-radius:5px;")
        self.info_layout.addWidget(self.photo_label)

        # 更改图片
        self.change_photo_button = QPushButton("更改图片")
        self.change_photo_button.setFixedHeight(40)
        self.change_photo_button.setFont(QFont('Arial', 12))
        self.change_photo_button.setStyleSheet(self.button_style())
        self.change_photo_button.clicked.connect(self.change_photo)
        self.change_photo_button.setEnabled(False)
        self.info_layout.addWidget(self.change_photo_button)

        # 姓名
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("姓名")
        self.name_input.setFont(QFont('Arial', 12))
        self.name_input.setFixedHeight(40)
        self.name_input.setEnabled(False)
        self.info_layout.addWidget(QLabel("姓名:"))
        self.info_layout.addWidget(self.name_input)

        # 国籍
        self.country_input = QLineEdit()
        self.country_input.setPlaceholderText("国籍")
        self.country_input.setFont(QFont('Arial', 12))
        self.country_input.setFixedHeight(40)
        self.country_input.setEnabled(False)
        self.info_layout.addWidget(QLabel("国籍:"))
        self.info_layout.addWidget(self.country_input)

        self.main_layout.addLayout(self.info_layout)
        self.main_layout.addStretch(1)

        # 操作按钮
        button_layout = QHBoxLayout()
        self.save_button = QPushButton("保存修改")
        self.save_button.setFixedHeight(50)
        self.save_button.setFont(QFont('Arial', 14))
        self.save_button.setStyleSheet(self.button_style())
        self.save_button.clicked.connect(self.save_person)
        self.save_button.setEnabled(False)
        button_layout.addWidget(self.save_button)

        self.return_button = QPushButton("返回人员管理")
        self.return_button.setFixedHeight(50)
        self.return_button.setFont(QFont('Arial', 14))
        self.return_button.setStyleSheet(self.button_style())
        self.return_button.clicked.connect(self.return_to_parent)
        button_layout.addWidget(self.return_button)

        self.main_layout.addSpacing(40)
        self.main_layout.addLayout(button_layout)
        self.main_layout.addStretch(2)

        self.setLayout(self.main_layout)
        self.update_background()

    def button_style(self):
        return '''
            QPushButton {
                background-color: rgba(255,255,255,200);
                border:none;
                border-radius:10px;
                color:#333;
            }
            QPushButton:hover {
                background-color: rgba(255,255,255,255);
                color:#1E90FF;
            }
        '''

    def resizeEvent(self, event):
        self.update_background()
        super().resizeEvent(event)

    def update_background(self):
        palette = QPalette()
        gradient = QLinearGradient(0,0,0,self.height())
        gradient.setColorAt(0.0, QColor(58,123,213))
        gradient.setColorAt(1.0, QColor(58,213,180))
        palette.setBrush(QPalette.Window, QBrush(gradient))
        self.setPalette(palette)

    def search_person(self):
        json_path = 'static/json/countries.json'
        if not os.path.exists(json_path):
            QMessageBox.warning(self, "错误", f"找不到文件 {json_path}")
            return
        try:
            with open(json_path,'r',encoding='utf-8') as f:
                data = json.load(f)
            search_id = self.id_input.text().strip()
            if not search_id:
                QMessageBox.warning(self, "错误", "请输入 ID")
                return
            self.person_data = None
            for country, info in data.items():
                for person in info.get("人员",[]):
                    if person.get("id")==search_id:
                        self.person_data = person
                        self.original_country = country
                        break
                if self.person_data:
                    break
            if self.person_data:
                # 加载图片
                rel = self.person_data.get("photo","")
                abs_path = os.path.join("static",rel) if not os.path.isabs(rel) else rel
                if os.path.exists(abs_path):
                    self.photo_label.setPixmap(QPixmap(abs_path).scaled(150,150,Qt.KeepAspectRatio))
                else:
                    self.photo_label.setText("无图片")
                self.new_photo_path=abs_path
                # 填充信息并启用
                self.name_input.setText(self.person_data.get("name",""))
                self.country_input.setText(self.original_country)
                for w in [self.name_input,self.country_input,self.change_photo_button,self.save_button]:
                    w.setEnabled(True)
            else:
                QMessageBox.warning(self, "错误", f"ID {search_id} 未找到")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"读取失败: {e}")

    def change_photo(self):
        path,_=QFileDialog.getOpenFileName(self,"选择图片","","Images (*.png *.jpg *.jpeg)")
        if path and os.path.exists(path):
            self.photo_label.setPixmap(QPixmap(path).scaled(150,150,Qt.KeepAspectRatio))
            self.new_photo_path=path

    def save_person(self):
        if not self.person_data or not self.original_country:
            QMessageBox.warning(self, "错误", "请先查找人物")
            return
        new_id=self.id_input.text().strip()
        new_name=self.name_input.text().strip()
        new_country=self.country_input.text().strip()
        if not new_id or not new_name or not new_country:
            QMessageBox.warning(self, "错误", "ID/姓名/国籍不能为空")
            return
        json_path='static/json/countries.json'
        try:
            with open(json_path,'r',encoding='utf-8') as f:
                data=json.load(f)
            # 删除原国家
            people=data[self.original_country]["人员"]
            data[self.original_country]["人员"]=[p for p in people if p["id"]!=self.person_data["id"]]
            # 准备新图片
            ext=os.path.splitext(self.new_photo_path)[-1]
            fn=f"{new_country}_{new_id}{ext}"
            dest=os.path.join("static/images/person",fn)
            os.makedirs(os.path.dirname(dest),exist_ok=True)
            if os.path.exists(self.new_photo_path): shutil.copy(self.new_photo_path,dest)
            rel_photo=f"images/person/{fn}"
            # 添加到新国家
            new_p={"id":new_id,"name":new_name,"photo":rel_photo}
            if new_country not in data:
                data[new_country]={"name":new_country,"flag":"","人员":[]}
            data[new_country]["人员"].append(new_p)
            with open(json_path,'w',encoding='utf-8') as f:
                json.dump(data,f,ensure_ascii=False,indent=4)
            QMessageBox.information(self,"成功","保存成功！")
            self.clear_inputs()
        except Exception as e:
            QMessageBox.warning(self,"错误",f"保存失败: {e}")

    def clear_inputs(self):
        for w in [self.id_input,self.name_input,self.country_input]: w.clear()
        self.photo_label.clear()
        for w in [self.name_input,self.country_input,self.change_photo_button,self.save_button]: w.setEnabled(False)
        self.person_data=None
        self.original_country=None
        self.new_photo_path=None

    def return_to_parent(self):
        if self.parent_window: self.parent_window.show()
        self.close()
