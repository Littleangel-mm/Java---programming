import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QLabel
from PyQt5.QtGui import QFont, QPixmap, QPalette, QColor, QBrush
from PyQt5.QtCore import Qt
from preson import PersonWindow
from draw import DrawWindow
from help import HelpWindow
from country import CountryWindow

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle('足球运动员管理系统')
        self.resize(500, 600)

        # 添加背景图片
        self.background_label = QLabel(self)
        pixmap = QPixmap('cnn.jpg')  # 替换为实际图片路径
        if pixmap.isNull():
            print("警告：无法加载背景图片，请检查路径 'static/images/background.jpg'")
            # 如果图片加载失败，设置默认背景色
            palette = QPalette()
            palette.setColor(QPalette.Window, QColor(58, 123, 213))
            self.setPalette(palette)
        else:
            self.background_label.setPixmap(pixmap.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation))
            self.background_label.setAlignment(Qt.AlignCenter)
            self.background_label.lower()  # 确保背景在最底层

        # 标题
        self.title = QLabel('足球运动员管理系统', self)
        self.title.setFont(QFont('Arial', 24, QFont.Bold))
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet('''
            QLabel {
                color: white;
                background-color: rgba(0, 0, 0, 150);
                padding: 10px;
                border-radius: 10px;
                margin-bottom: 30px;
            }
        ''')

        # 按钮
        self.btn_start = QPushButton('开始抽取')
        self.btn_country = QPushButton('国家管理')
        self.btn_manage = QPushButton('人员管理')
        self.btn_help = QPushButton('使用说明')

        for btn in [self.btn_start, self.btn_country, self.btn_manage, self.btn_help]:
            btn.setFixedHeight(50)
            btn.setFont(QFont('Arial', 14, QFont.Bold))
            btn.setStyleSheet('''
                QPushButton {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #4A90E2, stop:1 #50E3C2);
                    color: white;
                    border: none;
                    border-radius: 15px;
                    padding: 10px;
                    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
                }
                QPushButton:hover {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #50E3C2, stop:1 #4A90E2);
                    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.5);
                    transform: scale(1.05);
                }
                QPushButton:pressed {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #3A70B2, stop:1 #40B3A2);
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
                }
            ''')

        # 布局
        layout = QVBoxLayout()
        layout.addWidget(self.title)
        layout.addStretch(1)
        layout.addWidget(self.btn_start)
        layout.addSpacing(20)
        layout.addWidget(self.btn_country)
        layout.addSpacing(20)
        layout.addWidget(self.btn_manage)
        layout.addSpacing(20)
        layout.addWidget(self.btn_help)
        layout.addStretch(2)

        self.setLayout(layout)

        self.btn_start.clicked.connect(self.open_draw_window)
        self.btn_country.clicked.connect(self.open_country_window)
        self.btn_manage.clicked.connect(self.open_person_window)
        self.btn_help.clicked.connect(self.open_help_window)

    def resizeEvent(self, event):
        # 调整背景图片大小以适应窗口
        if not self.background_label.pixmap().isNull():
            self.background_label.setPixmap(self.background_label.pixmap().scaled(
                self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation))
        self.background_label.resize(self.size())
        super().resizeEvent(event)

    def open_draw_window(self):
        print("Opening DrawWindow from MainWindow")
        self.draw_window = DrawWindow(self)
        self.draw_window.show()
        self.hide()

    def open_person_window(self):
        print("Opening PersonWindow from MainWindow")
        self.person_window = PersonWindow(self)
        self.person_window.show()
        self.hide()

    def open_country_window(self):
        print("Opening CountryWindow from MainWindow")
        self.country_window = CountryWindow(self)
        self.country_window.show()
        self.hide()

    def open_help_window(self):
        print("Opening HelpWindow from MainWindow")
        self.help_window = HelpWindow(self)
        self.help_window.show()
        self.hide()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())