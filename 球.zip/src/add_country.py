import os
import json
import shutil
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QFileDialog, QMessageBox
from PyQt5.QtGui import QFont, QPixmap, QPalette, QColor, QLinearGradient, QBrush
from PyQt5.QtCore import Qt

class AddCountryWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__()
        self.parent = parent
        self.image_path = ""
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("添加国家")
        self.resize(400, 500)

        self.label_title = QLabel("添加国家", self)
        self.label_title.setFont(QFont("Arial", 20, QFont.Bold))
        self.label_title.setAlignment(Qt.AlignCenter)
        self.label_title.setStyleSheet("color: white; margin-bottom: 20px;")

        self.input_name = QLineEdit()
        self.input_name.setPlaceholderText("请输入国家名称")
        self.input_name.setFixedHeight(40)
        self.input_name.setFont(QFont("Arial", 12))

        self.btn_select_image = QPushButton("上传旗帜图片")
        self.btn_select_image.clicked.connect(self.select_image)

        self.label_image_preview = QLabel("图片预览")
        self.label_image_preview.setAlignment(Qt.AlignCenter)
        self.label_image_preview.setStyleSheet("border: 1px solid #ccc;")
        self.label_image_preview.setFixedSize(200, 120)

        self.btn_save = QPushButton("保存国家信息")
        self.btn_save.clicked.connect(self.save_country)

        self.btn_back = QPushButton("返回")
        self.btn_back.clicked.connect(self.go_back)

        for btn in [self.btn_select_image, self.btn_save, self.btn_back]:
            btn.setFixedHeight(40)
            btn.setFont(QFont("Arial", 12))

        layout = QVBoxLayout()
        layout.addWidget(self.label_title)
        layout.addWidget(self.input_name)
        layout.addWidget(self.btn_select_image)
        layout.addWidget(self.label_image_preview)
        layout.addWidget(self.btn_save)
        layout.addWidget(self.btn_back)
        layout.addStretch()

        self.setLayout(layout)
        self.update_background()

    def update_background(self):
        palette = QPalette()
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0.0, QColor(58, 123, 213))
        gradient.setColorAt(1.0, QColor(58, 213, 180))
        palette.setBrush(QPalette.Window, QBrush(gradient))
        self.setPalette(palette)

    def select_image(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "选择旗帜图片", "", "Images (*.png *.jpg *.jpeg *.bmp)")
        if file_path:
            self.image_path = file_path
            pixmap = QPixmap(file_path).scaled(200, 120, Qt.KeepAspectRatio)
            self.label_image_preview.setPixmap(pixmap)

    def save_country(self):
        name = self.input_name.text().strip()
        if not name:
            QMessageBox.warning(self, "提示", "请输入国家名称")
            return
        if not self.image_path:
            QMessageBox.warning(self, "提示", "请上传旗帜图片")
            return

        # 保存图片
        image_dir = "static/images/country"
        os.makedirs(image_dir, exist_ok=True)
        image_filename = os.path.basename(self.image_path)
        saved_image_path = os.path.join(image_dir, image_filename)
        shutil.copy(self.image_path, saved_image_path)

        # 统一保存到 countries.json
        json_path = os.path.join("static", "json", "countries.json")
        if os.path.exists(json_path):
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        else:
            data = {}

        # 添加或更新国家信息
        data[name] = {
            "name": name,
            "flag": f"images/country/{image_filename}"
        }

        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

        QMessageBox.information(self, "成功", f"{name} 已保存成功")
        self.input_name.clear()
        self.label_image_preview.clear()
        self.image_path = ""

    def go_back(self):
        self.parent.show()
        self.close()
