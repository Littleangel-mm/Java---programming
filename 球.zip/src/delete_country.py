import os
import json
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QComboBox, QMessageBox
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

class DeleteCountry(QWidget):
    def __init__(self, parent=None):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("删除国家")
        self.resize(400, 300)

        self.label_title = QLabel("删除国家", self)
        self.label_title.setFont(QFont("Arial", 20, QFont.Bold))
        self.label_title.setAlignment(Qt.AlignCenter)
        self.label_title.setStyleSheet("color: white; margin-bottom: 20px;")

        self.label_select = QLabel("选择国家", self)
        self.label_select.setFont(QFont("Arial", 12))

        self.combo_country = QComboBox(self)
        self.combo_country.setFont(QFont("Arial", 12))

        self.load_country_list()

        self.btn_delete = QPushButton("删除")
        self.btn_delete.setFont(QFont("Arial", 12))
        self.btn_delete.clicked.connect(self.delete_country)

        self.btn_back = QPushButton("返回")
        self.btn_back.setFont(QFont("Arial", 12))
        self.btn_back.clicked.connect(self.go_back)

        layout = QVBoxLayout()
        layout.addWidget(self.label_title)
        layout.addWidget(self.label_select)
        layout.addWidget(self.combo_country)
        layout.addWidget(self.btn_delete)
        layout.addWidget(self.btn_back)
        layout.addStretch()

        self.setLayout(layout)
        self.update_background()

    def update_background(self):
        from PyQt5.QtGui import QPalette, QColor, QLinearGradient, QBrush
        palette = QPalette()
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0.0, QColor(58, 123, 213))
        gradient.setColorAt(1.0, QColor(58, 213, 180))
        palette.setBrush(QPalette.Window, QBrush(gradient))
        self.setPalette(palette)

    def load_country_list(self):
        json_path = os.path.join("static", "json", "countries.json")
        if os.path.exists(json_path):
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.combo_country.clear()
                self.combo_country.addItems(list(data.keys()))

    def delete_country(self):
        country_name = self.combo_country.currentText().strip()
        if not country_name:
            QMessageBox.warning(self, "提示", "请选择一个国家")
            return

        # 二次确认
        reply = QMessageBox.question(
            self, "确认删除",
            f"确定要删除【{country_name}】及其所有人物和图片吗？",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return

        json_path = os.path.join("static", "json", "countries.json")
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if country_name in data:
            # 删除国旗
            flag_path = data[country_name].get("flag", "")
            flag_full_path = os.path.join("static", flag_path)
            if os.path.exists(flag_full_path):
                os.remove(flag_full_path)

            # 删除人物照片
            persons = data[country_name].get("人员", [])
            for person in persons:
                photo_path = person.get("photo", "")
                photo_full_path = os.path.join("static", photo_path)
                if os.path.exists(photo_full_path):
                    os.remove(photo_full_path)

            # 删除国家数据
            del data[country_name]

            # 保存更新后的 JSON
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=4)

            QMessageBox.information(self, "成功", f"{country_name} 及其人物已成功删除")
            self.load_country_list()
        else:
            QMessageBox.warning(self, "提示", "该国家不存在")

    def go_back(self):
        self.parent.show()
        self.close()
