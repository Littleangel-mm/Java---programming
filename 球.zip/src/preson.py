from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton
from PyQt5.QtGui import QFont, QPalette, QColor, QLinearGradient, QBrush
from PyQt5.QtCore import Qt
from add_person import AddPersonWindow  # ✅ 引入添加人物页面
from query_person import QueryPersonWindow  # ✅ 引入查询人物页面
from update_person import UpdatePersonWindow  # ✅ 引入修改人物页面
from delete_person import DeletePersonWindow  # ✅ 引入删除人物页面




class PersonWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("人员管理")
        self.resize(500, 600)

        self.title = QLabel("人员管理", self)
        self.title.setFont(QFont("Arial", 20, QFont.Bold))
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet("color: white; margin-bottom: 30px;")

        self.btn_add = self.create_button("添加人物")
        self.btn_add.clicked.connect(self.open_add_person_window)

        self.btn_delete = self.create_button("删除人物")
        self.btn_delete.clicked.connect(self.open_delete_person_window)
        self.btn_update = self.create_button("修改人物")
        # self.btn_update = self.create_button("修改人物")
        self.btn_update.clicked.connect(self.open_update_person_window)  # 改为跳转函数


        self.btn_search = self.create_button("查询人物")
        self.btn_search.clicked.connect(self.open_query_person_window)  # ✅ 添加查询逻辑

        self.btn_back = self.create_button("返回主界面")
        self.btn_back.clicked.connect(self.back_to_main)

        layout = QVBoxLayout()
        layout.addWidget(self.title)
        layout.addStretch(1)
        for btn in [self.btn_add, self.btn_delete, self.btn_update, self.btn_search]:
            layout.addWidget(btn)
            layout.addSpacing(20)
        layout.addWidget(self.btn_back)
        layout.addStretch(2)

        self.setLayout(layout)
        self.update_background()

    def create_button(self, text):
        btn = QPushButton(text)
        btn.setFixedHeight(50)
        btn.setFont(QFont('Arial', 14))
        btn.setStyleSheet('''
            QPushButton {
                background-color: rgba(255, 255, 255, 200);
                border: none;
                border-radius: 10px;
                color: #333;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 255);
                color: #1E90FF;
            }
        ''')
        return btn

    def resizeEvent(self, event):
        self.update_background()
        super().resizeEvent(event)

    def update_background(self):
        palette = QPalette()
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0.0, QColor(58, 123, 213))
        gradient.setColorAt(1.0, QColor(58, 213, 180))
        palette.setBrush(QPalette.Window, QBrush(gradient))
        self.setPalette(palette)

    def open_add_person_window(self):  # ✅ 打开添加人物页面
        self.add_window = AddPersonWindow(self)
        self.add_window.show()
        self.hide()

    def open_query_person_window(self):  # ✅ 打开查询人物页面
        self.query_window = QueryPersonWindow(self)
        self.query_window.show()
        self.hide()

    def open_update_person_window(self):  # ✅ 打开修改人物页面
        self.update_window = UpdatePersonWindow(self)
        self.update_window.show()
        self.hide()

    def open_delete_person_window(self):  # ✅ 打开删除人物页面
        self.delete_window = DeletePersonWindow(self)
        self.delete_window.show()
        self.hide()



    def back_to_main(self):
        self.parent.show()
        self.close()
