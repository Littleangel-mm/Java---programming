import os
import json
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QScrollArea, QGridLayout, QFrame
from PyQt5.QtGui import QFont, QPixmap
from PyQt5.QtCore import Qt

class SearchCountry(QWidget):
    def __init__(self, parent=None):
        super().__init__()
        self.parent = parent
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("查询国家")
        self.resize(600, 600)

        # 标题
        title = QLabel("查询国家", self)
        title.setFont(QFont("Arial", 20, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: white; margin: 20px;")

        # 卡片容器使用滚动区域
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)

        container = QWidget()
        self.grid_layout = QGridLayout()
        container.setLayout(self.grid_layout)
        self.scroll_area.setWidget(container)

        # 返回按钮
        btn_back = QPushButton("返回")
        btn_back.setFont(QFont("Arial", 12))
        btn_back.clicked.connect(self.go_back)

        layout = QVBoxLayout()
        layout.addWidget(title)
        layout.addWidget(self.scroll_area)
        layout.addWidget(btn_back)

        self.setLayout(layout)
        self.update_background()
        self.load_countries()

    def update_background(self):
        from PyQt5.QtGui import QPalette, QColor, QLinearGradient, QBrush
        palette = QPalette()
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0.0, QColor(58, 123, 213))
        gradient.setColorAt(1.0, QColor(58, 213, 180))
        palette.setBrush(QPalette.Window, QBrush(gradient))
        self.setPalette(palette)

    def load_countries(self):
        json_path = os.path.join("static", "json", "countries.json")
        if not os.path.exists(json_path):
            return

        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # 清空原来的内容
        for i in reversed(range(self.grid_layout.count())):
            widget = self.grid_layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

        # 生成卡片
        row = 0
        col = 0
        for name, info in data.items():
            card = QFrame()
            card.setStyleSheet("""
                QFrame {
                    background-color: white;
                    border-radius: 10px;
                    padding: 10px;
                }
            """)
            card.setFixedSize(180, 200)
            card_layout = QVBoxLayout(card)

            img_label = QLabel()
            img_path = os.path.join("static", info["flag"])
            if os.path.exists(img_path):
                pixmap = QPixmap(img_path).scaled(150, 100, Qt.KeepAspectRatio)
                img_label.setPixmap(pixmap)
            else:
                img_label.setText("图片缺失")
                img_label.setAlignment(Qt.AlignCenter)

            name_label = QLabel(name)
            name_label.setFont(QFont("Arial", 12, QFont.Bold))
            name_label.setAlignment(Qt.AlignCenter)

            card_layout.addWidget(img_label)
            card_layout.addSpacing(10)
            card_layout.addWidget(name_label)
            self.grid_layout.addWidget(card, row, col)

            col += 1
            if col == 3:
                col = 0
                row += 1

    def go_back(self):
        self.parent.show()
        self.close()
