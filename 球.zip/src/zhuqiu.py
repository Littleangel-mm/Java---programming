import sys
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QApplication, QPushButton, QHBoxLayout
from PyQt5.QtGui import QPainter, QPen, QColor, QLinearGradient, QBrush, QFont, QPainterPath, QImage
from PyQt5.QtCore import Qt, QRectF, QPointF, QPropertyAnimation
from draw2 import Draw2Window

class FieldWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(400, 600)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        margin = 20
        field_width = self.width() - 2 * margin
        field_height = self.height() - 2 * margin
        field_rect = QRectF(margin, margin, field_width, field_height)

        # Grass texture simulation with gradient
        grass_gradient = QLinearGradient(field_rect.topLeft(), field_rect.bottomLeft())
        grass_gradient.setColorAt(0, QColor(34, 139, 34))  # Darker green
        grass_gradient.setColorAt(0.5, QColor(50, 205, 50))  # Lighter green
        grass_gradient.setColorAt(1, QColor(34, 139, 34))
        painter.setBrush(grass_gradient)
        painter.setPen(QPen(QColor(255, 255, 255, 200), 2))
        painter.drawRect(field_rect)

        # Center line
        painter.drawLine(QPointF(field_rect.left(), field_rect.center().y()),
                         QPointF(field_rect.right(), field_rect.center().y()))

        # Center circle
        center_circle_diameter = field_width * 0.17
        center_circle = QRectF(
            field_rect.center().x() - center_circle_diameter / 2,
            field_rect.center().y() - center_circle_diameter / 2,
            center_circle_diameter,
            center_circle_diameter
        )
        painter.drawEllipse(center_circle)

        # Penalty boxes
        box_width = field_width * 0.4
        box_height = field_height * 0.16
        top_box = QRectF(field_rect.center().x() - box_width / 2,
                         field_rect.top(), box_width, box_height)
        bottom_box = QRectF(field_rect.center().x() - box_width / 2,
                            field_rect.bottom() - box_height, box_width, box_height)
        painter.drawRect(top_box)
        painter.drawRect(bottom_box)

        # Goal boxes
        small_box_width = field_width * 0.2
        small_box_height = field_height * 0.08
        top_small_box = QRectF(field_rect.center().x() - small_box_width / 2,
                               field_rect.top(), small_box_width, small_box_height)
        bottom_small_box = QRectF(field_rect.center().x() - small_box_width / 2,
                                  field_rect.bottom() - small_box_height, small_box_width, small_box_height)
        painter.drawRect(top_small_box)
        painter.drawRect(bottom_small_box)

        # Goals
        goal_width = field_width * 0.12
        goal_depth = field_width * 0.03
        painter.setPen(QPen(QColor(255, 255, 255, 200), 3))
        painter.drawLine(QPointF(field_rect.center().x() - goal_width / 2, field_rect.top()),
                         QPointF(field_rect.center().x() - goal_width / 2, field_rect.top() - goal_depth))
        painter.drawLine(QPointF(field_rect.center().x() + goal_width / 2, field_rect.top()),
                         QPointF(field_rect.center().x() + goal_width / 2, field_rect.top() - goal_depth))
        painter.drawLine(QPointF(field_rect.center().x() - goal_width / 2, field_rect.top() - goal_depth),
                         QPointF(field_rect.center().x() + goal_width / 2, field_rect.top() - goal_depth))

        painter.drawLine(QPointF(field_rect.center().x() - goal_width / 2, field_rect.bottom()),
                         QPointF(field_rect.center().x() - goal_width / 2, field_rect.bottom() + goal_depth))
        painter.drawLine(QPointF(field_rect.center().x() + goal_width / 2, field_rect.bottom()),
                         QPointF(field_rect.center().x() + goal_width / 2, field_rect.bottom() + goal_depth))
        painter.drawLine(QPointF(field_rect.center().x() - goal_width / 2, field_rect.bottom() + goal_depth),
                         QPointF(field_rect.center().x() + goal_width / 2, field_rect.bottom() + goal_depth))

        # Penalty spots
        penalty_spot_radius = 4
        painter.setBrush(QColor(255, 255, 255))
        painter.drawEllipse(QPointF(field_rect.center().x(), field_rect.top() + box_height * 0.6),
                            penalty_spot_radius, penalty_spot_radius)
        painter.drawEllipse(QPointF(field_rect.center().x(), field_rect.bottom() - box_height * 0.6),
                            penalty_spot_radius, penalty_spot_radius)
        painter.drawEllipse(field_rect.center(), penalty_spot_radius, penalty_spot_radius)

        # Penalty arcs
        arc_radius = box_width * 0.15
        arc_diameter = arc_radius * 2
        arc_rect_top = QRectF(field_rect.center().x() - arc_radius,
                              field_rect.top() + box_height - arc_radius,
                              arc_diameter, arc_diameter)
        arc_rect_bottom = QRectF(field_rect.center().x() - arc_radius,
                                 field_rect.bottom() - box_height - arc_radius,
                                 arc_diameter, arc_diameter)
        painter.setPen(QPen(QColor(255, 255, 255, 200), 2))
        painter.drawArc(arc_rect_top, 180 * 16, 180 * 16)
        painter.drawArc(arc_rect_bottom, 0 * 16, 180 * 16)

class SoccerFieldWidget(QWidget):
    def __init__(self, parent=None, country=None):
        super().__init__(parent)
        self.parent = parent
        self.country = country
        self.setWindowTitle(f"{self.country if self.country else '未知国家'} 足球场")
        self.resize(500, 800)
        self.selected_players = {}  # Store player names for each position

        # Back button with modern styling
        self.btn_back = QPushButton("返回", self)
        self.btn_back.setFont(QFont('Arial', 12, QFont.Bold))
        self.btn_back.setFixedSize(100, 40)
        self.btn_back.setStyleSheet('''
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #4A90E2, stop:1 #50E3C2);
                color: white;
                border: none;
                border-radius: 15px;
                padding: 10px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #50E3C2, stop:1 #4A90E2);
                box-shadow: 0 6px 20px rgba(0, 0, 0, 0.5);
                transform: scale(1.05);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #3A70B2, stop:1 #40B3A2);
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            }
        ''')
        self.btn_back.clicked.connect(self.go_back)

        # Title with shadow and emoji
        self.title = QLabel(f"{self.country if self.country else '未知国家'} 阵容选择", self)
        self.title.setFont(QFont('Arial', 18, QFont.Bold))
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet('''
            color: white;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        ''')

        # Top layout
        top_layout = QHBoxLayout()
        top_layout.addWidget(self.btn_back, alignment=Qt.AlignLeft)
        top_layout.addStretch()
        top_layout.addWidget(self.title)
        top_layout.addStretch()

        # Field widget
        self.field_widget = FieldWidget(self)
        self.field_widget.setGeometry(0, 80, self.width(), self.height() - 80)

        # Main layout
        layout = QVBoxLayout()
        layout.addLayout(top_layout)
        layout.addStretch(1)
        self.setLayout(layout)

        self.update_background()
        self.positions = {}
        self.update_position_buttons()

    def go_back(self):
        if self.parent is not None:
            self.parent.show()
        self.hide()

    def resizeEvent(self, event):
        self.update_background()
        self.field_widget.setGeometry(0, 80, self.width(), self.height() - 80)
        self.update_position_buttons()
        super().resizeEvent(event)

    def update_background(self):
        palette = self.palette()
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, QColor(0, 102, 204))  # Stadium sky blue
        gradient.setColorAt(0.5, QColor(0, 153, 153))  # Vibrant teal
        gradient.setColorAt(1, QColor(0, 204, 102))  # Green field tone
        palette.setBrush(self.backgroundRole(), QBrush(gradient))
        self.setPalette(palette)

    def add_position_button(self, position, x, y, width=60, height=40):
        if position in self.positions:
            self.positions[position].deleteLater()
        button = QPushButton(self.selected_players.get(position, position), self.field_widget)
        button.setFont(QFont("Arial", 10 if len(self.selected_players.get(position, position)) > 10 else 12, QFont.Bold))
        button.setStyleSheet('''
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #74ebd5, stop:1 #acb6e5);
                border-radius: 8px;
                color: #1a1a1a;
                padding: 5px;
                border: 1px solid rgba(255, 255, 255, 0.3);
                box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #9bf1e6, stop:1 #c3cfe2);
                transform: scale(1.05);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #5cd6c2, stop:1 #8e9bcb);
            }
        ''')
        button.setGeometry(int(x - width / 2), int(y - height / 2), width, height)
        button.clicked.connect(lambda: self.open_draw2_window(position))
        
        # Add subtle animation
        anim = QPropertyAnimation(button, b"geometry")
        anim.setDuration(200)
        anim.setStartValue(button.geometry())
        anim.setEndValue(button.geometry().adjusted(-2, -2, 2, 2))
        anim.setLoopCount(1)
        button.enterEvent = lambda event: anim.start()
        button.leaveEvent = lambda event: anim.setDirection(QPropertyAnimation.Backward) or anim.start()

        self.positions[position] = button

    def update_position_buttons(self):
        margin = 20
        field_width = self.field_widget.width() - 2 * margin
        field_height = self.field_widget.height() - 2 * margin
        field_rect = QRectF(margin, margin, field_width, field_height)
        box_height = field_height * 0.16

        positions = {
            "GK": (field_rect.center().x(), field_rect.bottom() - 10),
            "CB": (field_rect.center().x(), field_rect.bottom() - (box_height + 10)),
            "LB": (field_rect.left() + 100, field_rect.bottom() - box_height + 40),
            "RB": (field_rect.right() - 100, field_rect.bottom() - box_height + 44),
            "CDM": (field_rect.center().x(), field_rect.center().y() + box_height),
            "CM": (field_rect.center().x(), field_rect.center().y() + 5),
            "CAM": (field_rect.center().x(), field_rect.center().y() - box_height),
            "LM": (field_rect.left() + 50, field_rect.center().y() + 5),
            "RM": (field_rect.right() - 60, field_rect.center().y() + 5),
            "LW": (field_rect.left() + 90, field_rect.top() + box_height + 10),
            "RW": (field_rect.right() - 80, field_rect.top() + box_height + 10),
            "ST": (field_rect.center().x(), field_rect.top() + box_height + 20)
        }

        for position, (x, y) in positions.items():
            self.add_position_button(position, x, y)

    def open_draw2_window(self, position):
        self.draw2_window = Draw2Window(parent=self.parent, country=self.country, position=position, draw_window=self)
        self.draw2_window.player_selected.connect(lambda player_name: self.update_selected_player(position, player_name))
        self.draw2_window.show()
        self.hide()

    def update_selected_player(self, position, player_name):
        if player_name:
            self.selected_players[position] = player_name
            self.update_position_buttons()