import os
import json
import shutil
from PyQt5.QtWidgets import (
    QWidget, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QFileDialog, QComboBox, QMessageBox
)
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtCore import Qt

class AddPersonWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__()
        self.parent = parent
        self.image_path = None
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("添加人物")
        self.resize(400, 500)

        self.label_title = QLabel("添加人物", self)
        self.label_title.setFont(QFont("Arial", 20, QFont.Bold))
        self.label_title.setAlignment(Qt.AlignCenter)
        self.label_title.setStyleSheet("color: white; margin-bottom: 20px;")

        # 国家下拉框
        self.combo_country = QComboBox(self)
        self.load_countries()

        # 位置下拉框
        self.combo_position = QComboBox(self)
        self.combo_position.addItems(["GK", "CDM", "LB", "ST", "RW", "CB", "CAM", "LM", "RB", "LW", "CM", "RM"])

        # 输入ID和姓名
        self.input_id = QLineEdit()
        self.input_id.setPlaceholderText("请输入人物ID")

        self.input_name = QLineEdit()
        self.input_name.setPlaceholderText("请输入人物姓名")

        # 上传图片
        self.btn_upload = QPushButton("上传照片")
        self.btn_upload.clicked.connect(self.upload_image)

        self.label_preview = QLabel("照片预览", self)
        self.label_preview.setFixedSize(200, 200)
        self.label_preview.setStyleSheet("border: 1px solid gray;")
        self.label_preview.setAlignment(Qt.AlignCenter)

        # 保存按钮
        self.btn_save = QPushButton("保存")
        self.btn_save.clicked.connect(self.save_person)

        self.btn_back = QPushButton("返回")
        self.btn_back.clicked.connect(self.go_back)

        # 布局
        layout = QVBoxLayout()
        layout.addWidget(self.label_title)
        layout.addWidget(QLabel("选择国家"))
        layout.addWidget(self.combo_country)
        layout.addWidget(QLabel("选择位置"))
        layout.addWidget(self.combo_position)  # 新增位置下拉框
        layout.addWidget(QLabel("人物ID"))
        layout.addWidget(self.input_id)
        layout.addWidget(QLabel("人物姓名"))
        layout.addWidget(self.input_name)
        layout.addWidget(self.btn_upload)
        layout.addWidget(self.label_preview)
        layout.addWidget(self.btn_save)
        layout.addWidget(self.btn_back)
        layout.addStretch()
        self.setLayout(layout)
        self.update_background()

    def load_countries(self):
        json_path = os.path.join("static", "json", "countries.json")
        if os.path.exists(json_path):
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.combo_country.addItems(data.keys())

    def upload_image(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "选择人物照片", "", "Images (*.png *.jpg *.jpeg)")
        if file_path:
            self.image_path = file_path
            pixmap = QPixmap(file_path).scaled(200, 200, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.label_preview.setPixmap(pixmap)

    def save_person(self):
        country = self.combo_country.currentText()
        position = self.combo_position.currentText()  # 获取选择的职位
        person_id = self.input_id.text().strip()
        person_name = self.input_name.text().strip()

        if not all([country, person_id, person_name, self.image_path, position]):
            QMessageBox.warning(self, "提示", "请完整填写所有信息并上传照片")
            return

        # 保存图片
        image_filename = f"{country}_{person_id}.png"
        save_dir = os.path.join("static", "images", "person")
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(save_dir, image_filename)
        shutil.copy(self.image_path, save_path)

        # 保存信息到 JSON
        json_path = os.path.join("static", "json", "countries.json")
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if "人员" not in data[country]:
            data[country]["人员"] = []

        data[country]["人员"].append({
            "id": person_id,
            "name": person_name,
            "position": position,  # 添加职位信息
            "photo": f"images/person/{image_filename}"
        })

        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

        QMessageBox.information(self, "成功", "人物添加成功")
        self.input_id.clear()
        self.input_name.clear()
        self.label_preview.clear()
        self.image_path = None

    def go_back(self):
        self.parent.show()
        self.close()

    def update_background(self):
        from PyQt5.QtGui import QPalette, QColor, QLinearGradient, QBrush
        palette = QPalette()
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0.0, QColor(58, 123, 213))
        gradient.setColorAt(1.0, QColor(58, 213, 180))
        palette.setBrush(QPalette.Window, QBrush(gradient))
        self.setPalette(palette)
