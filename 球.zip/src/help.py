from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QTextEdit
from PyQt5.QtGui import QFont, QPixmap, QPalette, QBrush
from PyQt5.QtCore import Qt
import os

class HelpWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.setWindowTitle("使用说明")
        self.resize(600, 700)
        self.setWindowFlags(Qt.Window)
        self.init_ui()

    def init_ui(self):
        # 设置背景图片
        self.background_label = QLabel(self)
        pixmap = QPixmap('cnn.jpg')
        if not pixmap.isNull():
            self.background_label.setPixmap(pixmap.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation))
            self.background_label.lower()

        # 布局
        layout = QVBoxLayout()

        # 标题
        title = QLabel("使用说明")
        title.setFont(QFont("Arial", 24, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: white; background-color: rgba(0, 0, 0, 120); padding: 10px; border-radius: 10px;")

        # 使用说明内容
        help_text = QTextEdit()
        help_text.setReadOnly(True)
        help_text.setFont(QFont("Arial", 14))
        help_text.setStyleSheet("background-color: rgba(255, 255, 255, 200); border-radius: 10px; padding: 15px;")
        help_text.setText(
            "欢迎使用足球抽人系统！\n\n"
            "本系统包括以下功能模块：\n"
            "1. 国家管理：添加、修改、删除国家及其国旗。\n"
            "2. 人员管理：管理各国球员的姓名、ID 和照片。\n"
            "3. 开始抽取：点击盲盒抽取某国球员，进入球场页面。\n"
            "4. 球场页面：点击球员位置按钮，进入单抽/三连抽/五连抽页面。\n\n"
            "抽卡页面可选择球员分配到相应位置，也可返回重新抽取或返回国家页面。\n\n"
            "⚠️ 请确保图片路径正确，JSON 文件结构符合要求。\n"
        )

        # 返回按钮
        back_btn = QPushButton("返回主页面")
        back_btn.setFont(QFont("Arial", 14))
        back_btn.setFixedHeight(50)
        back_btn.setStyleSheet('''
            QPushButton {
                background-color: #4A90E2;
                color: white;
                border-radius: 15px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #50E3C2;
            }
        ''')
        back_btn.clicked.connect(self.back_to_main)

        layout.addWidget(title)
        layout.addSpacing(20)
        layout.addWidget(help_text)
        layout.addSpacing(20)
        layout.addWidget(back_btn, alignment=Qt.AlignCenter)

        self.setLayout(layout)

    def resizeEvent(self, event):
        if not self.background_label.pixmap().isNull():
            self.background_label.setPixmap(self.background_label.pixmap().scaled(
                self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation))
        self.background_label.resize(self.size())
        super().resizeEvent(event)

    def back_to_main(self):
        if self.parent:
            self.parent.show()
        self.close()
