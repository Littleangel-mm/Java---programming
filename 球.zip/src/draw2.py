from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout, QTextEdit, QComboBox,
    QMessageBox
)
from PyQt5.QtGui import QFont, QPalette, QColor, QLinearGradient, QBrush, QPixmap
from PyQt5.QtCore import Qt, QPropertyAnimation, pyqtSignal
import json
import random
import os

# 按钮样式常量
BUTTON_STYLE = '''
QPushButton {
    background-color: rgba(255, 255, 255, 220);
    border: 2px solid #1E90FF;
    border-radius: 10px;
    padding: 8px 16px;
    color: #1E90FF;
    font-weight: bold;
}
QPushButton:hover {
    background-color: #1E90FF;
    color: white;
}
'''

# 下拉框样式常量
COMBOBOX_STYLE = '''
QComboBox {
    background-color: rgba(255, 255, 255, 200);
    border-radius: 5px;
    padding: 5px;
    font-size: 14px;
    min-width: 200px;
}
'''

# 控制台样式常量
CONSOLE_STYLE = '''
QTextEdit {
    background-color: rgba(255, 255, 255, 200);
    border-radius: 5px;
    color: black;
    font-size: 14px;
}
'''

class Draw2Window(QWidget):
    player_selected = pyqtSignal(str)  # Signal to emit selected player name

    def __init__(self, parent=None, country=None, position=None, draw_window=None):
        super().__init__(parent)
        self.parent = parent  # 上一个窗口
        self.draw_window = draw_window  # 足球场窗口
        self.country = country  # 当前国家
        self.position = position  # 当前球场位置
        self.setWindowTitle(f"{self.country} - {self.position} 运动员页面")  # 设置窗口标题
        self.resize(1000, 800)
        self.setWindowFlags(Qt.Window)

        # 数据相关
        self.people_list = []  # 当前国家的球员列表（已过滤位置）
        self.drawn_ids = set()  # 已抽取球员ID集合
        self.all_countries = {}  # 所有国家数据
        self.selected_player = None  # 当前选中的球员
        self.bg_pixmap = None  # 背景图片缓存
        self.draw_history_file = "draw_history.json"  # 抽取历史文件
        self.last_drawn_players = []  # 存储最近抽取的球员

        self.init_ui()  # 初始化界面
        self.load_countries()  # 加载国家数据
        self.load_draw_history()  # 加载抽取历史

    def init_ui(self):
        """初始化界面布局和控件"""
        self.layout = QVBoxLayout()
        self.setup_country_selector()  # 国家选择下拉框
        self.setup_title()             # 标题
        self.setup_result_area()       # 抽取结果区域
        self.setup_console()           # 控制台
        self.setup_buttons()           # 抽取和返回按钮
        self.setLayout(self.layout)
        self.update_background()       # 设置背景
        self.country_selector.currentTextChanged.connect(self.on_country_changed)

    def setup_country_selector(self):
        """设置国家选择下拉框（如果有传入国家则只显示该国家并禁用）"""
        country_container = QHBoxLayout()
        country_container.addStretch()

        self.country_selector = QComboBox(self)
        self.country_selector.setFont(QFont('Arial', 14))
        self.country_selector.setStyleSheet(COMBOBOX_STYLE)

        if self.country:
            self.country_selector.addItem(self.country)
            self.country_selector.setCurrentText(self.country)
            self.country_selector.setEnabled(False)

        country_container.addWidget(self.country_selector)
        country_container.addStretch()
        self.layout.addLayout(country_container)

    def setup_title(self):
        """设置页面标题"""
        title_text = f"{self.country or '请选择国家'} - {self.position or '未知位置'}"
        self.title = QLabel(title_text, self)
        self.title.setFont(QFont('Arial', 20, QFont.Bold))
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setStyleSheet("""
            QLabel {
                color: white;
                margin: 20px 0;
                text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            }
        """)
        self.layout.addWidget(self.title)

    def setup_result_area(self):
        """设置球员卡片显示区域"""
        self.result_area = QHBoxLayout()
        self.result_area.setSpacing(20)
        self.result_area.setAlignment(Qt.AlignCenter)
        self.layout.addStretch(1)
        self.layout.addLayout(self.result_area)
        self.layout.addStretch(1)

    def setup_console(self):
        """设置底部信息输出区域"""
        self.console = QTextEdit(self)
        self.console.setReadOnly(True)
        self.console.setFixedHeight(100)
        self.console.setFont(QFont('Arial', 12))
        self.console.setStyleSheet(CONSOLE_STYLE)
        self.layout.addWidget(self.console)

    def setup_buttons(self):
        """设置抽取按钮、返回按钮和重置记录按钮"""
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        # 连抽按钮
        for count in [1, 3, 5]:
            btn = QPushButton(f"{count}连抽", self)
            btn.setFixedHeight(50)
            btn.setFixedWidth(120)
            btn.setFont(QFont('Arial', 14))
            btn.setStyleSheet(BUTTON_STYLE)
            btn.clicked.connect(lambda _, c=count: self.draw_people(c))
            button_layout.addWidget(btn)
            button_layout.addSpacing(20)
        
        # 重置记录按钮
        reset_btn = QPushButton("重置记录", self)
        reset_btn.setFixedHeight(50)
        reset_btn.setFixedWidth(120)
        reset_btn.setFont(QFont('Arial', 14))
        reset_btn.setStyleSheet(BUTTON_STYLE)
        reset_btn.clicked.connect(self.reset_draw_history)
        button_layout.addWidget(reset_btn)
        
        button_layout.addStretch()
        self.layout.addLayout(button_layout)

        # 底部返回按钮
        bottom_btn_layout = QHBoxLayout()
        bottom_btn_layout.setSpacing(40)
        bottom_btn_layout.setAlignment(Qt.AlignCenter)

        return_btn = QPushButton("返回球场", self)
        return_btn.setFixedHeight(50)
        return_btn.setFixedWidth(150)
        return_btn.setFont(QFont('Arial', 14))
        return_btn.setStyleSheet(BUTTON_STYLE)
        return_btn.clicked.connect(self.return_to_field)
        bottom_btn_layout.addWidget(return_btn)

        return_country_btn = QPushButton("返回国家", self)
        return_country_btn.setFixedHeight(50)
        return_country_btn.setFixedWidth(150)
        return_country_btn.setFont(QFont('Arial', 14))
        return_country_btn.setStyleSheet(BUTTON_STYLE)
        return_country_btn.clicked.connect(self.return_to_country)
        bottom_btn_layout.addWidget(return_country_btn)

        self.layout.addLayout(bottom_btn_layout)
        self.layout.addSpacing(20)

    def load_countries(self):
        """加载所有国家数据，并初始化下拉框"""
        json_path = "static/json/countries.json"
        try:
            if os.path.exists(json_path):
                with open(json_path, 'r', encoding='utf-8') as f:
                    self.all_countries = json.load(f)
                    if not self.country:  # 只有没传入country时才填充所有国家
                        self.country_selector.clear()  # 先清空
                        self.country_selector.addItems(self.all_countries.keys())
                        self.country = self.country_selector.currentText()
                    # 无论如何都手动触发一次
                    self.on_country_changed(self.country)
            else:
                self.console.setText("未找到 countries.json 文件")
                QMessageBox.warning(self, "错误", "未找到国家数据文件")
        except Exception as e:
            self.console.setText(f"加载数据失败：{e}")
            QMessageBox.warning(self, "错误", f"加载数据失败：{e}")

    def load_draw_history(self):
        """加载抽取历史"""
        try:
            if os.path.exists(self.draw_history_file):
                with open(self.draw_history_file, 'r', encoding='utf-8') as f:
                    history = json.load(f)
                    if self.country in history:
                        self.drawn_ids = set(history[self.country])
                        self.console.append(f"已加载 {self.country} 的 {len(self.drawn_ids)} 条抽取历史记录")
            else:
                self.console.append("未找到抽取历史文件，将创建新文件")
        except Exception as e:
            self.console.append(f"加载抽取历史失败：{e}")
            QMessageBox.warning(self, "错误", f"加载抽取历史失败：{e}")

    def save_draw_history(self):
        """保存抽取历史"""
        try:
            history = {}
            if os.path.exists(self.draw_history_file):
                with open(self.draw_history_file, 'r', encoding='utf-8') as f:
                    history = json.load(f)
            
            history[self.country] = list(self.drawn_ids)
            
            with open(self.draw_history_file, 'w', encoding='utf-8') as f:
                json.dump(history, f, ensure_ascii=False, indent=4)
            self.console.append("抽取历史已保存")
        except Exception as e:
            self.console.append(f"保存抽取历史失败：{e}")
            QMessageBox.warning(self, "错误", f"保存抽取历史失败：{e}")

    def reset_draw_history(self):
        """重置所有抽取历史"""
        try:
            if os.path.exists(self.draw_history_file):
                os.remove(self.draw_history_file)
                self.console.append("所有抽取历史已重置")
            else:
                self.console.append("无抽取历史可重置")
            self.drawn_ids.clear()
            self.clear_results()
            QMessageBox.information(self, "提示", "所有抽取历史已重置")
        except Exception as e:
            self.console.append(f"重置抽取历史失败：{e}")
            QMessageBox.warning(self, "错误", f"重置抽取历史失败：{e}")

    def on_country_changed(self, text):
        """切换国家时，刷新球员列表和标题"""
        if not text:
            return
            
        self.country = text
        self.drawn_ids.clear()
        self.load_draw_history()  # 重新加载对应国家的抽取历史
        self.clear_results()
        
        country_info = self.all_countries.get(text)
        if country_info:
            self.populate_people(country_info)
            self.title.setText(f"{self.country} - {self.position or '未知位置'}")
            self.console.setText(f"已加载 {self.country} - {self.position} 的 {len(self.people_list)} 名球员")
        else:
            self.console.setText(f"未找到国家 {text} 的信息")
            QMessageBox.warning(self, "错误", f"未找到国家 {text} 的信息")

    def populate_people(self, country_info):
        """根据国家信息和位置加载球员列表"""
        self.people_list = []
        raw_list = country_info.get('人员', [])
        seen = set()
        
        for p in raw_list:
            pid = p.get("id")
            position = p.get("position")
            # 仅添加匹配指定位置的球员
            if pid and pid not in seen and position == self.position:
                seen.add(pid)
                p["nationality"] = self.country
                self.people_list.append(p)
        
        if not self.people_list:
            self.console.setText(f"国家 {self.country} - 位置 {self.position} 没有可用的球员数据")
            QMessageBox.warning(self, "提示", f"国家 {self.country} - 位置 {self.position} 没有可用的球员数据")

    def draw_people(self, count):
        """抽取指定数量的球员（仅限指定位置）"""
        self.clear_results()
        self.last_drawn_players = []  # 清空上次抽取记录
        if not self.people_list:
            self.console.setText(f"国家 {self.country} - 位置 {self.position} 没有可抽取的球员")
            QMessageBox.warning(self, "提示", f"国家 {self.country} - 位置 {self.position} 没有可抽取的球员")
            return

        available_people = [p for p in self.people_list if p["id"] not in self.drawn_ids]
        if not available_people:
            self.console.setText(f"国家 {self.country} - 位置 {self.position} 的所有球员已被抽取！点击返回足球场重新选择位置")
            QMessageBox.information(self, "提示", f"国家 {self.country} - 位置 {self.position} 的所有球员已被抽取！请返回足球场重新选择位置")
            return

        count = min(count, len(available_people))
        selected = random.sample(available_people, count)

        for person in selected:
            self.drawn_ids.add(person["id"])
            self.last_drawn_players.append(person)  # 存储抽取的球员
        
        self.save_draw_history()  # 保存抽取历史
        self.console.setText(f"在 {self.country} - {self.position} 抽中了：{', '.join([p['name'] for p in selected])}")
        for person in selected:
            self.display_person(person)

    def display_person(self, person):
        """显示单个球员卡片，并支持点击选择"""
        card = QWidget()
        card.setStyleSheet("""
            QWidget {
                background-color: rgba(255, 255, 255, 0.9);
                border-radius: 10px;
                padding: 10px;
            }
            QWidget:hover {
                background-color: rgba(200, 220, 255, 0.9);
            }
        """)
        card.setFixedSize(180, 250)
        card.setCursor(Qt.PointingHandCursor)
        card.mousePressEvent = lambda event: self.select_player(person["name"])
        
        layout = QVBoxLayout(card)
        layout.setSpacing(10)
        
        # 照片
        photo = QLabel()
        path = os.path.join("static", person.get('photo', ''))
        if os.path.exists(path):
            pixmap = QPixmap(path).scaled(150, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            photo.setPixmap(pixmap)
            animation = QPropertyAnimation(photo, b"windowOpacity")
            animation.setDuration(500)
            animation.setStartValue(0.0)
            animation.setEndValue(1.0)
            animation.start()
        else:
            photo.setText("无图片")
            photo.setFixedSize(150, 150)
            photo.setAlignment(Qt.AlignCenter)
            photo.setStyleSheet("""
                QLabel {
                    color: #666;
                    font-size: 14px;
                    font-weight: bold;
                    border: 1px solid #ddd;
                    border-radius: 5px;
                }
            """)
        
        # 信息标签
        info_style = """
            QLabel {
                color: #333;
                font-size: 14px;
                font-weight: bold;
                padding: 5px;
                background-color: rgba(255, 255, 255, 0.7);
                border-radius: 5px;
            }
        """
        
        pid = QLabel(f"ID: {person.get('id', '未知')}")
        name = QLabel(f"姓名: {person.get('name', '未知')}")
        country = QLabel(f"国籍: {person.get('nationality', self.country)}")
        
        for label in (pid, country, name):
            label.setStyleSheet(info_style)
            label.setAlignment(Qt.AlignCenter)
        
        layout.addWidget(photo, alignment=Qt.AlignCenter)
        layout.addWidget(pid)
        layout.addWidget(country)
        layout.addWidget(name)
        
        self.result_area.addWidget(card)

    def select_player(self, player_name):
        """点击球员卡片直接选择球员"""
        self.player_selected.emit(player_name)
        self.console.setText(f"已选择球员：{player_name}")
        self.return_to_field()

    def clear_results(self):
        """清空球员卡片区域"""
        while self.result_area.count():
            item = self.result_area.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def return_to_field(self):
        """返回足球场页面"""
        if self.draw_window:
            self.draw_window.show()
        self.close()

    def return_to_country(self):
        """返回国家选择页面"""
        if self.parent:
            self.parent.show()
        self.close()

    def resizeEvent(self, event):
        """窗口大小变化时，更新背景"""
        self.update_background()
        super().resizeEvent(event)

    def update_background(self):
        """设置或更新窗口背景"""
        palette = QPalette()
        if not self.bg_pixmap:
            bg_path = "球场.jpg"
            if os.path.exists(bg_path):
                self.bg_pixmap = QPixmap(bg_path)
        if self.bg_pixmap:
            scaled_pixmap = self.bg_pixmap.scaled(self.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
            palette.setBrush(QPalette.Window, QBrush(scaled_pixmap))
        else:
            gradient = QLinearGradient(0, 0, 0, self.height())
            gradient.setColorAt(0.0, QColor(58, 123, 213))
            gradient.setColorAt(1.0, QColor(58, 213, 180))
            palette.setBrush(QPalette.Window, QBrush(gradient))
        self.setAutoFillBackground(True)
        self.setPalette(palette)