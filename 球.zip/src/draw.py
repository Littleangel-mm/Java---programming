import os
import json
import random
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QMessageBox, QGridLayout, QSizePolicy
)
from PyQt5.QtGui import QFont, QPixmap, QPalette, QIcon
from PyQt5.QtCore import Qt, QSize
from zhuqiu import SoccerFieldWidget


class DrawWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__()
        self.parent = parent
        self.setWindowTitle("国家抽取")
        self.resize(800, 600)

        self.drawn_countries = set()
        self.country_data = self.load_country_data()
        self.country_names = list(self.country_data.keys())

        self.init_ui()

    def init_ui(self):
        self.bg_label = QLabel(self)
        self.bg_label.setPixmap(QPixmap("static/images/bg_draw.jpg").scaled(self.size(), Qt.KeepAspectRatioByExpanding))
        self.bg_label.setGeometry(0, 0, self.width(), self.height())

        self.label_title = QLabel("", self)
        self.label_title.setFont(QFont("Arial", 22, QFont.Bold))
        self.label_title.setAlignment(Qt.AlignCenter)
        self.label_title.setStyleSheet("color: white; margin: 20px;")

        self.grid_layout = QGridLayout()
        self.buttons = []

        for i, name in enumerate(self.country_names):
            btn = QPushButton("⚽")
            btn.setFont(QFont("Arial", 14))
            btn.setFixedSize(100, 100)
            btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            btn.setStyleSheet('''
                QPushButton {
                    background-color: rgba(255, 255, 255, 230);
                    border-radius: 15px;
                    border: 2px solid #1E90FF;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #87CEFA;
                    font-size: 16px;
                }
            ''')
            btn.clicked.connect(lambda _, b=btn: self.draw_country(b))
            self.grid_layout.addWidget(btn, i // 4, i % 4)
            self.buttons.append(btn)

        self.btn_back = self.create_control_button("返回主界面", self.go_back)
        self.btn_reset = self.create_control_button("重置抽取", self.reset_draw)

        layout = QVBoxLayout()
        layout.addWidget(self.label_title)
        layout.addLayout(self.grid_layout)
        layout.addWidget(self.btn_reset)
        layout.addWidget(self.btn_back)
        layout.addStretch()

        self.setLayout(layout)

    def resizeEvent(self, event):
        self.bg_label.setPixmap(QPixmap("cnn.jpg").scaled(
            self.size(), Qt.KeepAspectRatioByExpanding))
        self.bg_label.setGeometry(0, 0, self.width(), self.height())
        super().resizeEvent(event)

    def create_control_button(self, text, slot_func):
        btn = QPushButton(text)
        btn.setFont(QFont("Arial", 12))
        btn.setFixedHeight(45)
        btn.setStyleSheet('''
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #4A90E2, stop:1 #50E3C2);
                color: white;
                border: none;
                border-radius: 15px;
                padding: 10px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #50E3C2, stop:1 #4A90E2);
                box-shadow: 0 6px 20px rgba(0, 0, 0, 0.5);
                transform: scale(1.05);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #3A70B2, stop:1 #40B3A2);
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            }
        ''')
        btn.clicked.connect(slot_func)
        return btn

    def load_country_data(self):
        json_path = os.path.join("static", "json", "countries.json")
        try:
            if os.path.exists(json_path):
                with open(json_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            else:
                QMessageBox.warning(self, "错误", "未找到国家数据文件！")
                return {}
        except Exception as e:
            QMessageBox.warning(self, "错误", f"加载国家数据失败: {e}")
            return {}

    def draw_country(self, button):
        available = list(set(self.country_names) - self.drawn_countries)
        if not available:
            QMessageBox.information(self, "提示", "所有国家都已抽取完！")
            return

        country = random.choice(available)
        self.drawn_countries.add(country)
        button.setProperty("country_name", country)

        flag_path = os.path.join("static", self.country_data[country]["flag"])
        if os.path.exists(flag_path):
            pixmap = QPixmap(flag_path).scaled(80, 80, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            button.setIcon(QIcon(pixmap))
            button.setIconSize(QSize(80, 80))
            button.setText("")
        else:
            button.setText(country)

        button.setEnabled(True)
        button.clicked.disconnect()
        button.clicked.connect(lambda _, c=country: self.open_soccer_field(c))

    def open_soccer_field(self, country):
        self.soccer_field = SoccerFieldWidget(country=country)
        self.soccer_field.setWindowTitle(f"{country} 足球场")
        self.soccer_field.show()
        self.reset_draw()  # 自动重置

    def reset_draw(self):
        self.drawn_countries.clear()
        for btn in self.buttons:
            btn.setEnabled(True)
            btn.setText("⚽")
            btn.setIcon(QIcon())
            btn.clicked.disconnect()
            btn.clicked.connect(lambda _, b=btn: self.draw_country(b))

    def go_back(self):
        if self.parent:
            self.parent.show()
        self.close()
