
// ######################################################################################################
// pages/index/index.js
let timer; // 使用let代替var，避免变量提升问题

Page({
  data: {
    srcs: [
      '/images/shitou.png',
      '/images/jiandao.png',
      '/images/bu.png'
    ],
    imgAi: '',       // 电脑显示的图片
    imgUser: '/images/wenghao.png', // 用户图片（注意修正拼写错误）
    notice: '',      // 比赛结果
    winNum: 0,       // 胜利次数（添加默认值）
    btnpunches: false // 出拳状态
  },

  onLoad: function() {
    // 初始化胜利次数（兼容首次加载无缓存的情况）
    this.setData({
      winNum: wx.getStorageSync('winNum') || 0
    });
    this.timerGo();
  },

  // 电脑随机切换图片
  timerGo() {
    timer = setInterval(() => {
      this.setData({
        imgAi: this.data.srcs[Math.floor(Math.random() * 3)]
      });
    }, 200);
  },

  // 用户点击出拳
  btnclick(e) {
    if (this.data.btnpunches) return;

    const userChoice = parseInt(e.currentTarget.dataset.choose); // 改用currentTarget
    const aiChoice = this.data.srcs.indexOf(this.data.imgAi);
    let result = '';
    
    // 先设置用户选择图片
    this.setData({
      btnpunches: true,
      imgUser: this.data.srcs[userChoice]
    });

    clearInterval(timer); // 停止电脑动画

    // 胜负判断逻辑
    if (userChoice === aiChoice) {
      result = '平局';
    } else if ((userChoice === 0 && aiChoice === 1) || 
               (userChoice === 1 && aiChoice === 2) || 
               (userChoice === 2 && aiChoice === 0)) {
      result = '你赢了';
      this.updateWinNum();
    } else {
      result = '你输了';
    }

    this.setData({ notice: result });
  },

  // 更新胜利次数
  updateWinNum() {
    const newNum = this.data.winNum + 1;
    wx.setStorageSync('winNum', newNum);
    this.setData({ winNum: newNum });
  },

  // 再来一局
  again() {
    if (!this.data.btnpunches) return;
    
    this.timerGo();
    this.setData({
      btnpunches: false,
      imgUser: '/images/wenghao.png',
      notice: ''
    });
  }
});

