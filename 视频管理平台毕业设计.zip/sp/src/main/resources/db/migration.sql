-- 数据库迁移脚本：将 video_url 字段更新为 file_path
-- 执行此脚本前请备份数据库

USE video_platform;

-- 1. 添加新的 file_path 字段
ALTER TABLE videos ADD COLUMN file_path VARCHAR(500) AFTER description;

-- 2. 将现有的 video_url 数据迁移到 file_path（如果有数据的话）
-- UPDATE videos SET file_path = video_url WHERE video_url IS NOT NULL;

-- 3. 删除旧的 video_url 字段
ALTER TABLE videos DROP COLUMN video_url;

-- 4. 验证表结构
DESCRIBE videos; 