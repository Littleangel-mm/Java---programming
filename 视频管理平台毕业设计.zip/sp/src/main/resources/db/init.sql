-- 创建数据库
CREATE DATABASE IF NOT EXISTS video_platform DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE video_platform;

-- 创建用户表
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(120) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    nickname VARCHAR(50),
    avatar VARCHAR(200),
    bio VARCHAR(500),
    role ENUM('ADMIN', 'USER') DEFAULT 'USER',
    status ENUM('ACTIVE', 'INACTIVE', 'BANNED') DEFAULT 'ACTIVE',
    age INT,
    phone VARCHAR(20),
    location VARCHAR(100),
    last_login_time DATETIME,
    login_count INT DEFAULT 0,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 创建分类表
CREATE TABLE IF NOT EXISTS categories (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(500),
    icon VARCHAR(200),
    color VARCHAR(50),
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 创建标签表
CREATE TABLE IF NOT EXISTS tags (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(200),
    color VARCHAR(50),
    use_count INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 创建视频表
CREATE TABLE IF NOT EXISTS videos (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description VARCHAR(1000),
    file_path VARCHAR(500),
    cover_url VARCHAR(500),
    thumbnail_url VARCHAR(500),
    duration BIGINT,
    file_size BIGINT,
    resolution VARCHAR(50),
    format VARCHAR(20),
    status ENUM('PENDING', 'APPROVED', 'REJECTED', 'DELETED') DEFAULT 'PENDING',
    visibility ENUM('PUBLIC', 'PRIVATE', 'UNLISTED') DEFAULT 'PUBLIC',
    view_count BIGINT DEFAULT 0,
    like_count BIGINT DEFAULT 0,
    comment_count BIGINT DEFAULT 0,
    share_count BIGINT DEFAULT 0,
    favorite_count BIGINT DEFAULT 0,
    is_approved BOOLEAN DEFAULT FALSE,
    approved_time DATETIME,
    approved_by BIGINT,
    reject_reason VARCHAR(500),
    user_id BIGINT,
    category_id BIGINT,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- 创建评论表
CREATE TABLE IF NOT EXISTS comments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    content VARCHAR(1000) NOT NULL,
    status ENUM('ACTIVE', 'HIDDEN', 'DELETED') DEFAULT 'ACTIVE',
    like_count INT DEFAULT 0,
    reply_count INT DEFAULT 0,
    user_id BIGINT,
    video_id BIGINT,
    parent_id BIGINT,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES comments(id) ON DELETE CASCADE
);

-- 创建视频标签关联表
CREATE TABLE IF NOT EXISTS video_tags (
    video_id BIGINT,
    tag_id BIGINT,
    PRIMARY KEY (video_id, tag_id),
    FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
);

-- 创建用户点赞视频关联表
CREATE TABLE IF NOT EXISTS user_likes (
    user_id BIGINT,
    video_id BIGINT,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, video_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE
);

-- 创建用户收藏视频关联表
CREATE TABLE IF NOT EXISTS user_favorites (
    user_id BIGINT,
    video_id BIGINT,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, video_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE
);

-- 创建用户关注关联表
CREATE TABLE IF NOT EXISTS user_follows (
    follower_id BIGINT,
    following_id BIGINT,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (follower_id, following_id),
    FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 创建评论点赞关联表
CREATE TABLE IF NOT EXISTS comment_likes (
    comment_id BIGINT,
    user_id BIGINT,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (comment_id, user_id),
    FOREIGN KEY (comment_id) REFERENCES comments(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 创建系统日志表
CREATE TABLE IF NOT EXISTS system_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    level ENUM('INFO', 'WARN', 'ERROR', 'DEBUG'),
    type ENUM('LOGIN', 'LOGOUT', 'CREATE', 'UPDATE', 'DELETE', 'VIEW', 'UPLOAD', 'DOWNLOAD', 'SYSTEM'),
    user_id BIGINT,
    user_username VARCHAR(50),
    ip_address VARCHAR(45),
    user_agent VARCHAR(500),
    message VARCHAR(500),
    details TEXT,
    request_url VARCHAR(500),
    request_method VARCHAR(10),
    response_status INT,
    execution_time BIGINT,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 创建运营管理表
CREATE TABLE IF NOT EXISTS operations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('PROMOTION', 'BANNER', 'NOTIFICATION', 'MAINTENANCE', 'FEATURE_UPDATE'),
    title VARCHAR(200),
    description TEXT,
    target_type ENUM('VIDEO', 'USER', 'CATEGORY', 'SYSTEM'),
    target_id BIGINT,
    operator_id BIGINT,
    operator_name VARCHAR(50),
    status ENUM('PENDING', 'ACTIVE', 'COMPLETED', 'CANCELLED') DEFAULT 'PENDING',
    start_time DATETIME,
    end_time DATETIME,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 创建系统信息表
CREATE TABLE IF NOT EXISTS system_info (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(100) NOT NULL UNIQUE,
    config_value TEXT,
    description VARCHAR(500),
    type ENUM('SYSTEM', 'FEATURE', 'LIMIT', 'NOTIFICATION', 'SECURITY'),
    is_active BOOLEAN DEFAULT TRUE,
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 插入默认管理员用户 (密码: admin123)
INSERT INTO users (username, password, email, nickname, role, status) VALUES 
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVEFDa', 'admin@example.com', '系统管理员', 'ADMIN', 'ACTIVE');

-- 插入默认分类
INSERT INTO categories (name, description, icon, color, sort_order) VALUES 
('娱乐', '娱乐视频分类', '🎬', '#FF6B6B', 1),
('教育', '教育视频分类', '📚', '#4ECDC4', 2),
('科技', '科技视频分类', '💻', '#45B7D1', 3),
('音乐', '音乐视频分类', '🎵', '#96CEB4', 4),
('游戏', '游戏视频分类', '🎮', '#FFEAA7', 5),
('生活', '生活视频分类', '🏠', '#DDA0DD', 6);

-- 插入默认标签
INSERT INTO tags (name, description, color) VALUES 
('热门', '热门标签', '#FF6B6B'),
('推荐', '推荐标签', '#4ECDC4'),
('新发布', '新发布标签', '#45B7D1'),
('精选', '精选标签', '#96CEB4'),
('搞笑', '搞笑标签', '#FFEAA7'),
('教程', '教程标签', '#DDA0DD');

-- 插入系统配置
INSERT INTO system_info (config_key, config_value, description, type) VALUES 
('max_video_size', '100', '最大视频文件大小(MB)', 'LIMIT'),
('max_video_duration', '3600', '最大视频时长(秒)', 'LIMIT'),
('allow_comment', 'true', '是否允许评论', 'FEATURE'),
('require_approval', 'true', '视频是否需要审核', 'FEATURE'),
('max_upload_per_day', '10', '每日最大上传数量', 'LIMIT'),
('site_name', '视频平台', '网站名称', 'SYSTEM'),
('site_description', '一个现代化的视频分享平台', '网站描述', 'SYSTEM');

-- 创建索引
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_status ON users(status);

CREATE INDEX idx_videos_title ON videos(title);
CREATE INDEX idx_videos_status ON videos(status);
CREATE INDEX idx_videos_user_id ON videos(user_id);
CREATE INDEX idx_videos_category_id ON videos(category_id);
CREATE INDEX idx_videos_created_time ON videos(created_time);
CREATE INDEX idx_videos_view_count ON videos(view_count);

CREATE INDEX idx_comments_video_id ON comments(video_id);
CREATE INDEX idx_comments_user_id ON comments(user_id);
CREATE INDEX idx_comments_parent_id ON comments(parent_id);
CREATE INDEX idx_comments_created_time ON comments(created_time);

CREATE INDEX idx_system_logs_level ON system_logs(level);
CREATE INDEX idx_system_logs_type ON system_logs(type);
CREATE INDEX idx_system_logs_user_id ON system_logs(user_id);
CREATE INDEX idx_system_logs_created_time ON system_logs(created_time); 