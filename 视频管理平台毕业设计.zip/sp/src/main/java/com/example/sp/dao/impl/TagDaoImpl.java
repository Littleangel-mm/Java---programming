package com.example.sp.dao.impl;

import com.example.sp.Entity.Tag;
import com.example.sp.Repository.TagRepository;
import com.example.sp.dao.TagDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * 标签数据访问对象实现类
 */
@Repository
public class TagDaoImpl implements TagDao {

    @Autowired
    private TagRepository tagRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Optional<Tag> findByName(String name) {
        return tagRepository.findByName(name);
    }

    @Override
    public List<Tag> findByNames(List<String> names) {
        return tagRepository.findByNameIn(names);
    }

    @Override
    public List<Tag> findByColor(String color) {
        // TagRepository没有findByColor，返回空列表
        return new java.util.ArrayList<>();
    }

    @Override
    public Page<Tag> findTagsWithPagination(Pageable pageable) {
        return tagRepository.findAll(pageable);
    }

    @Override
    public Page<Tag> searchTags(String keyword, String color, Pageable pageable) {
        if (keyword != null && !keyword.trim().isEmpty()) {
            return tagRepository.searchTags(keyword, pageable);
        } else {
            return tagRepository.findAll(pageable);
        }
    }

    @Override
    public List<TagWithVideoCount> getPopularTags(int limit) {
        String sql = "SELECT t.id, t.name, t.color, COUNT(vt.video_id) as videoCount " +
            "FROM tags t " +
            "LEFT JOIN video_tags vt ON t.id = vt.tag_id " +
            "GROUP BY t.id, t.name, t.color " +
            "ORDER BY videoCount DESC " +
            "LIMIT :limit";

        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("limit", limit);
        List<Object[]> results = query.getResultList();

        return results.stream()
            .map(row -> new TagDao.TagWithVideoCount(
                ((Number) row[0]).longValue(),
                (String) row[1],
                (String) row[2],
                ((Number) row[3]).longValue()
            ))
            .collect(java.util.stream.Collectors.toList());
    }

    @Override
    public TagStatistics getTagStatistics() {
        String sql = "SELECT " +
            "COUNT(*) as totalTags, " +
            "SUM(CASE WHEN video_count > 0 THEN 1 ELSE 0 END) as usedTags, " +
            "SUM(CASE WHEN video_count = 0 THEN 1 ELSE 0 END) as unusedTags, " +
            "SUM(video_count) as totalVideoCount " +
            "FROM (SELECT t.id, COUNT(vt.video_id) as video_count " +
            "FROM tags t LEFT JOIN video_tags vt ON t.id = vt.tag_id " +
            "GROUP BY t.id) as tag_stats";

        Query query = entityManager.createNativeQuery(sql);
        Object[] result = (Object[]) query.getSingleResult();

        return new TagDao.TagStatistics(
            ((Number) result[0]).longValue(),
            ((Number) result[1]).longValue(),
            ((Number) result[2]).longValue(),
            ((Number) result[3]).longValue()
        );
    }

    @Override
    public long getVideoCountByTag(Long tagId) {
        String sql = "SELECT COUNT(*) FROM video_tags WHERE tag_id = :tagId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("tagId", tagId);
        return ((Number) query.getSingleResult()).longValue();
    }

    @Override
    public List<Tag> findByVideoId(Long videoId) {
        String sql = "SELECT t.* FROM tags t " +
            "INNER JOIN video_tags vt ON t.id = vt.tag_id " +
            "WHERE vt.video_id = :videoId";

        Query query = entityManager.createNativeQuery(sql, Tag.class);
        query.setParameter("videoId", videoId);
        return query.getResultList();
    }

    @Override
    public boolean existsByName(String name) {
        return tagRepository.existsByName(name);
    }

    @Override
    public List<Tag> getTagSuggestions(String prefix, int limit) {
        // TagRepository没有findByNameStartingWith，返回空列表
        return new java.util.ArrayList<>();
    }

    @Override
    public List<Tag> getRelatedTags(Long tagId, int limit) {
        // 基于共同视频的标签推荐
        String sql = "SELECT DISTINCT t.* FROM tags t " +
            "INNER JOIN video_tags vt1 ON t.id = vt1.tag_id " +
            "INNER JOIN video_tags vt2 ON vt1.video_id = vt2.video_id " +
            "WHERE vt2.tag_id = :tagId AND t.id != :tagId " +
            "ORDER BY COUNT(vt1.video_id) DESC " +
            "LIMIT :limit";

        Query query = entityManager.createNativeQuery(sql, Tag.class);
        query.setParameter("tagId", tagId);
        query.setParameter("limit", limit);
        return query.getResultList();
    }
}