package com.example.sp.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "system_logs")
@EntityListeners(AuditingEntityListener.class)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SystemLog {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Enumerated(EnumType.STRING)
    private LogLevel level;
    
    @Enumerated(EnumType.STRING)
    private LogType type;
    
    @Column(name = "user_id")
    private Long userId;
    
    @Column(name = "user_username")
    private String userUsername;
    
    @Column(name = "ip_address")
    private String ipAddress;
    
    @Column(name = "user_agent")
    private String userAgent;
    
    private String message;
    
    private String details;
    
    @Column(name = "request_url")
    private String requestUrl;
    
    @Column(name = "request_method")
    private String requestMethod;
    
    @Column(name = "response_status")
    private Integer responseStatus;
    
    @Column(name = "execution_time")
    private Long executionTime; // 执行时间（毫秒）
    
    @CreatedDate
    @Column(name = "created_time", updatable = false)
    private LocalDateTime createdTime;
    
    public enum LogLevel {
        INFO, WARN, ERROR, DEBUG
    }
    
    public enum LogType {
        LOGIN, LOGOUT, CREATE, UPDATE, DELETE, VIEW, UPLOAD, DOWNLOAD, SYSTEM
    }
    
    // 自定义构造函数
    public SystemLog(LogLevel level, LogType type, String message) {
        this.level = level;
        this.type = type;
        this.message = message;
    }
} 