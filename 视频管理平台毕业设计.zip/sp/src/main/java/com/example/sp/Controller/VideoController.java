package com.example.sp.Controller;

import com.example.sp.Entity.Video;
import com.example.sp.Entity.User;
import com.example.sp.Entity.Category;
import com.example.sp.Service.VideoService;
import com.example.sp.Service.UserService;
import com.example.sp.Service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import org.springframework.http.HttpRange;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/videos")
@CrossOrigin(origins = "*")
public class VideoController {
    
    @Autowired
    private VideoService videoService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private CategoryService categoryService;
    
    // 调试接口 - 检查请求格式
    @PostMapping("/debug-upload")
    public ResponseEntity<?> debugUpload(HttpServletRequest request) {
        try {
            Map<String, Object> debugInfo = new HashMap<>();
            debugInfo.put("contentType", request.getContentType());
            debugInfo.put("method", request.getMethod());
            debugInfo.put("contentLength", request.getContentLength());
            debugInfo.put("isMultipart", request.getContentType() != null && request.getContentType().startsWith("multipart/"));
            
            // 获取所有请求头
            Map<String, String> headers = new HashMap<>();
            java.util.Enumeration<String> headerNames = request.getHeaderNames();
            while (headerNames.hasMoreElements()) {
                String headerName = headerNames.nextElement();
                headers.put(headerName, request.getHeader(headerName));
            }
            debugInfo.put("headers", headers);
            
            // 获取所有参数
            Map<String, String[]> parameters = request.getParameterMap();
            debugInfo.put("parameters", parameters);
            
            return ResponseEntity.ok(debugInfo);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "调试失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 测试视频上传接口
    @PostMapping("/test-upload")
    public ResponseEntity<?> testUpload(@RequestParam("file") MultipartFile file) {
        try {
            Map<String, Object> response = new HashMap<>();
            response.put("message", "文件上传成功");
            response.put("filename", file.getOriginalFilename());
            response.put("size", file.getSize());
            response.put("contentType", file.getContentType());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "测试上传失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 上传视频文件
    @PostMapping("/upload")
    public ResponseEntity<?> uploadVideo(@RequestParam("file") MultipartFile videoFile,
                                        @RequestParam("title") String title,
                                        @RequestParam("description") String description,
                                        @RequestParam("userId") Long userId,
                                        @RequestParam(value = "categoryId", required = false) Long categoryId,
                                        @RequestParam(value = "thumbnailUrl", required = false) String thumbnailUrl) {
        try {
            System.out.println("开始处理视频上传请求");
            System.out.println("视频文件: " + videoFile.getOriginalFilename() + ", 大小: " + videoFile.getSize());
            System.out.println("标题: " + title + ", 描述: " + description + ", 用户ID: " + userId);
            
            // 检查视频文件
            if (videoFile.isEmpty()) {
                System.err.println("视频文件为空");
                return ResponseEntity.badRequest().body(Map.of("error", "视频文件不能为空"));
            }
            
            String contentType = videoFile.getContentType();
            System.out.println("文件类型: " + contentType);
            if (contentType == null || !contentType.startsWith("video/")) {
                System.err.println("文件类型不正确: " + contentType);
                return ResponseEntity.badRequest().body(Map.of("error", "只能上传视频文件"));
            }
            
            // 检查文件大小（100MB）
            if (videoFile.getSize() > 104857600) {
                System.err.println("文件大小超限: " + videoFile.getSize());
                return ResponseEntity.badRequest().body(Map.of("error", "视频文件大小不能超过100MB"));
            }
            
            User user = userService.findUserById(userId)
                    .orElseThrow(() -> new RuntimeException("用户不存在"));
            System.out.println("找到用户: " + user.getUsername());

            // 保存视频文件
            String datePath = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy/MM/dd"));
            String videoUploadPath = "uploads/videos/" + datePath;
            java.nio.file.Path uploadDir = java.nio.file.Paths.get(videoUploadPath);
            System.out.println("创建目录: " + uploadDir.toAbsolutePath());
            
            if (!java.nio.file.Files.exists(uploadDir)) {
                java.nio.file.Files.createDirectories(uploadDir);
            }
            
            String originalFilename = videoFile.getOriginalFilename();
            String extension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }
            String videoFilename = java.util.UUID.randomUUID().toString() + extension;
            java.nio.file.Path videoFilePath = uploadDir.resolve(videoFilename);
            System.out.println("保存文件到: " + videoFilePath.toAbsolutePath());
            
            java.nio.file.Files.copy(videoFile.getInputStream(), videoFilePath);

            // 创建视频记录
            Video video = new Video();
            video.setTitle(title);
            video.setDescription(description);
            video.setUser(user);
            video.setFilePath("videos/" + datePath + "/" + videoFilename);
            video.setThumbnailUrl(thumbnailUrl);
            video.setStatus(Video.VideoStatus.PENDING);
            video.setIsApproved(false);
            video.setFileSize(videoFile.getSize());
            video.setFormat(extension.replace(".", ""));
            video.setCreatedTime(java.time.LocalDateTime.now());
            
            // 设置默认时长（后续可以通过FFmpeg提取真实时长）
            video.setDuration(0L); // 暂时设为0，后续可以改进
            
            if (categoryId != null) {
                Category category = categoryService.findCategoryById(categoryId)
                        .orElse(null);
                video.setCategory(category);
                System.out.println("设置分类: " + (category != null ? category.getName() : "null"));
            }
            
            Video uploadedVideo = videoService.uploadVideo(video, user);
            System.out.println("视频上传成功，ID: " + uploadedVideo.getId());
            return ResponseEntity.status(HttpStatus.CREATED).body(uploadedVideo);
            
        } catch (Exception e) {
            System.err.println("视频上传失败: " + e.getMessage());
            e.printStackTrace();
            Map<String, String> error = new HashMap<>();
            error.put("error", "视频上传失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取所有已审核通过的视频（分页）
    @GetMapping
    public ResponseEntity<Page<Video>> getAllVideos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdTime") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDir) {
        
        try {
            System.out.println("获取已审核视频列表 - 参数: page=" + page + ", size=" + size + ", sortBy=" + sortBy + ", sortDir=" + sortDir);
            
            Sort sort = sortDir.equalsIgnoreCase("desc") ? 
                Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
            Pageable pageable = PageRequest.of(page, size, sort);
            
            Page<Video> videos = videoService.findApprovedVideos(pageable);
            System.out.println("获取到 " + videos.getTotalElements() + " 个已审核视频");
            return ResponseEntity.ok(videos);
        } catch (Exception e) {
            System.err.println("获取视频列表失败: " + e.getMessage());
            e.printStackTrace();
            
            try {
                // 如果排序失败，使用默认排序
                Pageable pageable = PageRequest.of(page, size, Sort.by("createdTime").descending());
                Page<Video> videos = videoService.findApprovedVideos(pageable);
                return ResponseEntity.ok(videos);
            } catch (Exception e2) {
                System.err.println("使用默认排序也失败: " + e2.getMessage());
                e2.printStackTrace();
                return ResponseEntity.badRequest().build();
            }
        }
    }
    
    // 根据ID获取视频
    @GetMapping("/{id}")
    public ResponseEntity<?> getVideoById(@PathVariable Long id) {
        return videoService.findVideoById(id)
                .map(video -> {
                    // 增加观看次数
                    videoService.incrementViewCount(id);
                    return ResponseEntity.ok(video);
                })
                .orElse(ResponseEntity.notFound().build());
    }
    
    // 更新视频信息
    @PutMapping("/{id}")
    public ResponseEntity<?> updateVideo(@PathVariable Long id, @RequestBody Video videoDetails) {
        try {
            Video updatedVideo = videoService.updateVideo(id, videoDetails);
            return ResponseEntity.ok(updatedVideo);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 删除视频
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteVideo(@PathVariable Long id) {
        try {
            videoService.deleteVideoById(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "视频删除成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 视频审核 - 通过
    @PutMapping("/{id}/approve")
    public ResponseEntity<?> approveVideo(@PathVariable Long id, @RequestParam Long approvedBy) {
        try {
            Video approvedVideo = videoService.approveVideo(id, approvedBy);
            return ResponseEntity.ok(approvedVideo);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 视频审核 - 拒绝
    @PutMapping("/{id}/reject")
    public ResponseEntity<?> rejectVideo(
            @PathVariable Long id, 
            @RequestParam Long rejectedBy,
            @RequestBody Map<String, String> request) {
        
        String reason = request.get("reason");
        try {
            Video rejectedVideo = videoService.rejectVideo(id, rejectedBy, reason);
            return ResponseEntity.ok(rejectedVideo);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 搜索视频
    @GetMapping("/search")
    public ResponseEntity<Page<Video>> searchVideos(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Video> videos = videoService.searchVideos(keyword, pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 根据用户获取视频
    @GetMapping("/user/{userId}")
    public ResponseEntity<Page<Video>> getVideosByUser(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        try {
            User user = userService.findUserById(userId)
                    .orElseThrow(() -> new RuntimeException("用户不存在"));
            
            Pageable pageable = PageRequest.of(page, size);
            Page<Video> videos = videoService.findVideosByUser(user, pageable);
            return ResponseEntity.ok(videos);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    // 分页获取某分类下的视频
    @GetMapping("/category/{categoryId}")
    public ResponseEntity<Page<Video>> getVideosByCategory(
            @PathVariable Long categoryId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "12") int size) {
        Category category = categoryService.findCategoryById(categoryId)
                .orElseThrow(() -> new RuntimeException("分类不存在"));
        Pageable pageable = PageRequest.of(page, size);
        Page<Video> videos = videoService.findVideosByCategory(category, pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 根据状态获取视频
    @GetMapping("/status/{status}")
    public ResponseEntity<Page<Video>> getVideosByStatus(
            @PathVariable String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        try {
            Video.VideoStatus videoStatus = Video.VideoStatus.valueOf(status.toUpperCase());
            Pageable pageable = PageRequest.of(page, size);
            Page<Video> videos = videoService.findVideosByStatus(videoStatus, pageable);
            return ResponseEntity.ok(videos);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    // 获取热门视频
    @GetMapping("/popular")
    public ResponseEntity<List<Video>> getPopularVideos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Video> videos = videoService.findPopularVideos(pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 获取最新视频
    @GetMapping("/latest")
    public ResponseEntity<List<Video>> getLatestVideos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Video> videos = videoService.findLatestVideos(pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 获取推荐视频
    @GetMapping("/recommended")
    public ResponseEntity<List<Video>> getRecommendedVideos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Video> videos = videoService.findRecommendedVideos(pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 获取趋势视频
    @GetMapping("/trending")
    public ResponseEntity<List<Video>> getTrendingVideos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Video> videos = videoService.findTrendingVideos(pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 用户点赞视频
    @PostMapping("/{videoId}/like")
    public ResponseEntity<?> likeVideo(@PathVariable Long videoId, @RequestParam Long userId) {
        try {
            videoService.likeVideo(userId, videoId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "点赞成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 用户取消点赞视频
    @DeleteMapping("/{videoId}/like")
    public ResponseEntity<?> unlikeVideo(@PathVariable Long videoId, @RequestParam Long userId) {
        try {
            videoService.unlikeVideo(userId, videoId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "取消点赞成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 检查用户是否点赞视频
    @GetMapping("/{videoId}/liked")
    public ResponseEntity<?> isLikedByUser(@PathVariable Long videoId, @RequestParam Long userId) {
        try {
            boolean isLiked = videoService.isLikedByUser(userId, videoId);
            Map<String, Boolean> response = new HashMap<>();
            response.put("isLiked", isLiked);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 用户收藏视频
    @PostMapping("/{videoId}/favorite")
    public ResponseEntity<?> favoriteVideo(@PathVariable Long videoId, @RequestParam Long userId) {
        videoService.favoriteVideo(userId, videoId);
        return ResponseEntity.ok().build();
    }

    // 用户取消收藏视频
    @DeleteMapping("/{videoId}/favorite")
    public ResponseEntity<?> unfavoriteVideo(@PathVariable Long videoId, @RequestParam Long userId) {
        videoService.unfavoriteVideo(userId, videoId);
        return ResponseEntity.ok().build();
    }
    
    // 检查用户是否收藏视频
    @GetMapping("/{videoId}/favorited")
    public ResponseEntity<?> isFavoritedByUser(@PathVariable Long videoId, @RequestParam Long userId) {
        try {
            boolean isFavorited = videoService.isFavoritedByUser(userId, videoId);
            Map<String, Boolean> response = new HashMap<>();
            response.put("isFavorited", isFavorited);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取用户点赞的视频
    @GetMapping("/user/{userId}/liked")
    public ResponseEntity<Page<Video>> getLikedVideosByUser(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Video> videos = videoService.findLikedVideosByUser(userId, pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 获取用户收藏的视频
    @GetMapping("/user/{userId}/favorites")
    public ResponseEntity<Page<Video>> getFavoriteVideosByUser(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Video> videos = videoService.findFavoriteVideosByUser(userId, pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 分享视频
    @PostMapping("/{videoId}/share")
    public ResponseEntity<?> shareVideo(@PathVariable Long videoId) {
        try {
            videoService.incrementShareCount(videoId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "分享成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取待审核视频
    @GetMapping("/pending")
    public ResponseEntity<Page<Video>> getPendingVideos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Video> videos = videoService.findPendingVideos(pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 获取被拒绝视频
    @GetMapping("/rejected")
    public ResponseEntity<Page<Video>> getRejectedVideos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Video> videos = videoService.findRejectedVideos(pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 获取已审核视频
    @GetMapping("/approved")
    public ResponseEntity<Page<Video>> getApprovedVideos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Video> videos = videoService.findApprovedVideos(pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 批量审核视频
    @PutMapping("/batch/approve")
    public ResponseEntity<?> batchApproveVideos(
            @RequestBody Map<String, Object> request) {
        
        @SuppressWarnings("unchecked")
        List<Long> videoIds = (List<Long>) request.get("videoIds");
        Long approvedBy = Long.valueOf(request.get("approvedBy").toString());
        
        try {
            videoService.batchApproveVideos(videoIds, approvedBy);
            Map<String, String> response = new HashMap<>();
            response.put("message", "批量审核成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 批量拒绝视频
    @PutMapping("/batch/reject")
    public ResponseEntity<?> batchRejectVideos(
            @RequestBody Map<String, Object> request) {
        
        @SuppressWarnings("unchecked")
        List<Long> videoIds = (List<Long>) request.get("videoIds");
        Long rejectedBy = Long.valueOf(request.get("rejectedBy").toString());
        String reason = (String) request.get("reason");
        
        try {
            videoService.batchRejectVideos(videoIds, rejectedBy, reason);
            Map<String, String> response = new HashMap<>();
            response.put("message", "批量拒绝成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 批量删除视频
    @DeleteMapping("/batch")
    public ResponseEntity<?> batchDeleteVideos(@RequestBody List<Long> videoIds) {
        try {
            videoService.batchDeleteVideos(videoIds);
            Map<String, String> response = new HashMap<>();
            response.put("message", "批量删除成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取个性化推荐视频
    @GetMapping("/personalized/{userId}")
    public ResponseEntity<List<Video>> getPersonalizedRecommendations(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Video> videos = videoService.getPersonalizedRecommendations(userId, pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 获取相似视频
    @GetMapping("/{videoId}/similar")
    public ResponseEntity<List<Video>> getSimilarVideos(
            @PathVariable Long videoId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Video> videos = videoService.getSimilarVideos(videoId, pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 根据标签获取视频
    @GetMapping("/tag/{tagName}")
    public ResponseEntity<List<Video>> getVideosByTag(
            @PathVariable String tagName,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Video> videos = videoService.findVideosByTag(tagName, pageable);
        return ResponseEntity.ok(videos);
    }
    
    // 获取视频统计信息
    @GetMapping("/stats")
    public ResponseEntity<?> getVideoStats() {
        Map<String, Object> stats = new HashMap<>();
        
        stats.put("totalVideos", videoService.countVideosByStatus(Video.VideoStatus.APPROVED));
        stats.put("pendingVideos", videoService.countVideosByStatus(Video.VideoStatus.PENDING));
        stats.put("rejectedVideos", videoService.countVideosByStatus(Video.VideoStatus.REJECTED));
        stats.put("approvedVideos", videoService.countVideosByIsApproved(true));
        
        return ResponseEntity.ok(stats);
    }
    
    // 刷新视频统计
    @PutMapping("/{videoId}/refresh-stats")
    public ResponseEntity<?> refreshVideoStatistics(@PathVariable Long videoId) {
        try {
            videoService.refreshVideoStatistics(videoId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "统计刷新成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    // 视频播放接口 - 支持范围请求和断点续传
    @GetMapping("/stream-play/{id}")
    public ResponseEntity<Resource> playVideo(@PathVariable Long id, 
                                            @RequestHeader(value = "Range", required = false) String rangeHeader,
                                            HttpServletRequest request) {
        try {
            System.out.println("=== 视频播放请求开始 ===");
            System.out.println("视频ID: " + id);
            System.out.println("Range头: " + rangeHeader);
            
            // 获取视频信息
            Video video = videoService.findVideoById(id)
                    .orElseThrow(() -> new RuntimeException("视频不存在"));
            
            System.out.println("视频信息: ID=" + video.getId() + ", 标题=" + video.getTitle());
            System.out.println("视频状态: " + video.getStatus());
            System.out.println("是否已审核: " + video.getIsApproved());
            
            // 检查视频状态
            if (video.getStatus() != Video.VideoStatus.APPROVED) {
                System.err.println("视频状态不正确: " + video.getStatus() + ", 需要: " + Video.VideoStatus.APPROVED);
                throw new RuntimeException("视频未通过审核，无法播放。当前状态: " + video.getStatus());
            }
            
            // 构建视频文件路径
            String filePath = video.getFilePath();
            if (filePath == null || filePath.isEmpty()) {
                System.err.println("视频文件路径为空");
                throw new RuntimeException("视频文件路径不存在");
            }
            
            System.out.println("视频播放 - 原始 filePath: " + filePath);
            
            // 处理文件路径 - 避免重复的 videos 目录
            if (filePath.startsWith("videos/")) {
                // 如果已经是 videos/ 开头，直接拼接 uploads/
                filePath = "uploads/" + filePath;
            } else if (!filePath.startsWith("uploads/")) {
                // 如果既不是 videos/ 也不是 uploads/ 开头，添加 uploads/videos/
                filePath = "uploads/videos/" + filePath;
            }
            // 如果已经是 uploads/ 开头，直接使用
            
            System.out.println("视频播放 - 处理后的 filePath: " + filePath);
            Path videoPath = Paths.get(filePath);
            System.out.println("视频播放 - 绝对路径: " + videoPath.toAbsolutePath());
            
            Resource videoResource = new FileSystemResource(videoPath.toFile());
            
            if (!videoResource.exists()) {
                System.err.println("视频文件不存在: " + videoPath.toAbsolutePath());
                throw new RuntimeException("视频文件不存在: " + videoPath.toAbsolutePath());
            }
            
            System.out.println("视频文件存在，大小: " + videoResource.contentLength() + " 字节");
            
            // 设置响应头
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.parseMediaType("video/mp4"));
            headers.set("Accept-Ranges", "bytes");
            
            // 获取文件大小
            long contentLength = videoResource.contentLength();
            headers.setContentLength(contentLength);
            
            // 处理范围请求（断点续传）
            if (rangeHeader != null && rangeHeader.startsWith("bytes=")) {
                try {
                    List<HttpRange> ranges = HttpRange.parseRanges(rangeHeader);
                    if (!ranges.isEmpty()) {
                        HttpRange range = ranges.get(0);
                        long start = range.getRangeStart(contentLength);
                        long end = range.getRangeEnd(contentLength);
                        long rangeLength = end - start + 1;
                        
                        headers.set("Content-Range", "bytes " + start + "-" + end + "/" + contentLength);
                        headers.setContentLength(rangeLength);
                        
                        // 增加观看次数（只在完整请求时）
                        if (start == 0 && end == contentLength - 1) {
                            videoService.incrementViewCount(id);
                        }
                        
                        System.out.println("返回范围请求响应: 206");
                        return ResponseEntity.status(206)
                                .headers(headers)
                                .body(videoResource);
                    }
                } catch (Exception e) {
                    System.err.println("处理范围请求失败: " + e.getMessage());
                }
            }
            
            // 完整文件请求
            videoService.incrementViewCount(id);
            
            System.out.println("返回完整文件响应: 200");
            System.out.println("=== 视频播放请求完成 ===");
            
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(videoResource);
                    
        } catch (Exception e) {
            System.err.println("视频播放失败: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(500).build();
        }
    }
    
    // 获取视频流信息（用于前端预加载）
    @GetMapping("/stream/{id}")
    public ResponseEntity<?> getVideoStreamInfo(@PathVariable Long id) {
        try {
            System.out.println("=== 视频流信息请求开始 ===");
            System.out.println("视频ID: " + id);
            
            Video video = videoService.findVideoById(id)
                    .orElseThrow(() -> new RuntimeException("视频不存在"));
            
            System.out.println("视频信息: ID=" + video.getId() + ", 标题=" + video.getTitle());
            System.out.println("视频状态: " + video.getStatus());
            System.out.println("是否已审核: " + video.getIsApproved());
            
            if (video.getStatus() != Video.VideoStatus.APPROVED) {
                System.err.println("视频状态不正确: " + video.getStatus() + ", 需要: " + Video.VideoStatus.APPROVED);
                throw new RuntimeException("视频未通过审核。当前状态: " + video.getStatus());
            }
            
            String filePath = video.getFilePath();
            if (filePath == null || filePath.isEmpty()) {
                System.err.println("视频文件路径为空");
                throw new RuntimeException("视频文件路径不存在");
            }
            
            System.out.println("视频流信息 - 原始 filePath: " + filePath);
            
            // 处理文件路径 - 避免重复的 videos 目录
            if (filePath.startsWith("videos/")) {
                // 如果已经是 videos/ 开头，直接拼接 uploads/
                filePath = "uploads/" + filePath;
            } else if (!filePath.startsWith("uploads/")) {
                // 如果既不是 videos/ 也不是 uploads/ 开头，添加 uploads/videos/
                filePath = "uploads/videos/" + filePath;
            }
            // 如果已经是 uploads/ 开头，直接使用
            
            System.out.println("视频流信息 - 处理后的 filePath: " + filePath);
            Path videoPath = Paths.get(filePath);
            System.out.println("视频流信息 - 绝对路径: " + videoPath.toAbsolutePath());
            
            Resource videoResource = new FileSystemResource(videoPath.toFile());
            
            if (!videoResource.exists()) {
                System.err.println("视频文件不存在: " + videoPath.toAbsolutePath());
                throw new RuntimeException("视频文件不存在: " + videoPath.toAbsolutePath());
            }
            
            System.out.println("视频文件存在，大小: " + videoResource.contentLength() + " 字节");
            
            Map<String, Object> streamInfo = new HashMap<>();
            streamInfo.put("videoId", video.getId());
            streamInfo.put("title", video.getTitle());
            streamInfo.put("duration", video.getDuration());
            streamInfo.put("fileSize", videoResource.contentLength());
            streamInfo.put("contentType", "video/mp4");
            streamInfo.put("playUrl", "/api/videos/stream-play/" + id);
            streamInfo.put("thumbnailUrl", video.getThumbnailUrl());
            streamInfo.put("description", video.getDescription());
            
            System.out.println("=== 视频流信息请求完成 ===");
            return ResponseEntity.ok(streamInfo);
            
        } catch (Exception e) {
            System.err.println("获取视频流信息失败: " + e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
} 