package com.example.sp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommentPieDTO {
    private String videoTitle;
    private Long commentCount;
} 