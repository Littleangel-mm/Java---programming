package com.example.sp.Repository;

import com.example.sp.Entity.SystemInfo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SystemInfoRepository extends JpaRepository<SystemInfo, Long> {
    
    // 基本查询方法
    Optional<SystemInfo> findByConfigKey(String configKey);
    
    boolean existsByConfigKey(String configKey);
    
    // 根据激活状态查询
    List<SystemInfo> findByIsActive(Boolean isActive);
    
    Page<SystemInfo> findByIsActive(Boolean isActive, Pageable pageable);
    
    // 根据配置类型查询
    List<SystemInfo> findByType(SystemInfo.ConfigType type);
    
    Page<SystemInfo> findByType(SystemInfo.ConfigType type, Pageable pageable);
    
    // 根据激活状态和类型查询
    List<SystemInfo> findByIsActiveAndType(Boolean isActive, SystemInfo.ConfigType type);
    
    Page<SystemInfo> findByIsActiveAndType(Boolean isActive, SystemInfo.ConfigType type, Pageable pageable);
    
    // 模糊查询
    List<SystemInfo> findByConfigKeyContainingOrDescriptionContaining(String configKey, String description);
    
    Page<SystemInfo> findByConfigKeyContainingOrDescriptionContaining(String configKey, String description, Pageable pageable);
    
    // 根据配置键列表查询
    List<SystemInfo> findByConfigKeyIn(List<String> configKeys);
    
    // 根据配置值查询
    List<SystemInfo> findByConfigValue(String configValue);
    
    List<SystemInfo> findByConfigValueContaining(String configValue);
    
    // 统计查询
    @Query("SELECT COUNT(s) FROM SystemInfo s WHERE s.isActive = :isActive")
    long countByIsActive(@Param("isActive") Boolean isActive);
    
    @Query("SELECT COUNT(s) FROM SystemInfo s WHERE s.type = :type")
    long countByType(@Param("type") SystemInfo.ConfigType type);
    
    @Query("SELECT COUNT(s) FROM SystemInfo s WHERE s.isActive = :isActive AND s.type = :type")
    long countByIsActiveAndType(@Param("isActive") Boolean isActive, @Param("type") SystemInfo.ConfigType type);
    
    // 复杂查询
    @Query("SELECT s FROM SystemInfo s WHERE s.configKey LIKE %:keyword% OR s.configValue LIKE %:keyword% OR s.description LIKE %:keyword%")
    Page<SystemInfo> searchSystemInfo(@Param("keyword") String keyword, Pageable pageable);
    
    @Query("SELECT s FROM SystemInfo s WHERE s.type = :type AND (s.configKey LIKE %:keyword% OR s.configValue LIKE %:keyword% OR s.description LIKE %:keyword%)")
    Page<SystemInfo> searchSystemInfoByType(@Param("keyword") String keyword, @Param("type") SystemInfo.ConfigType type, Pageable pageable);
    
    // 获取所有激活的系统配置
    @Query("SELECT s FROM SystemInfo s WHERE s.isActive = true ORDER BY s.type ASC, s.configKey ASC")
    List<SystemInfo> findAllActiveOrderByTypeAndKey();
    
    // 获取特定类型的激活配置
    @Query("SELECT s FROM SystemInfo s WHERE s.isActive = true AND s.type = :type ORDER BY s.configKey ASC")
    List<SystemInfo> findActiveByType(@Param("type") SystemInfo.ConfigType type);
    
    // 获取系统配置
    @Query("SELECT s FROM SystemInfo s WHERE s.isActive = true AND s.type = 'SYSTEM' ORDER BY s.configKey ASC")
    List<SystemInfo> findSystemConfigs();
    
    // 获取功能配置
    @Query("SELECT s FROM SystemInfo s WHERE s.isActive = true AND s.type = 'FEATURE' ORDER BY s.configKey ASC")
    List<SystemInfo> findFeatureConfigs();
    
    // 获取限制配置
    @Query("SELECT s FROM SystemInfo s WHERE s.isActive = true AND s.type = 'LIMIT' ORDER BY s.configKey ASC")
    List<SystemInfo> findLimitConfigs();
    
    // 获取通知配置
    @Query("SELECT s FROM SystemInfo s WHERE s.isActive = true AND s.type = 'NOTIFICATION' ORDER BY s.configKey ASC")
    List<SystemInfo> findNotificationConfigs();
    
    // 获取安全配置
    @Query("SELECT s FROM SystemInfo s WHERE s.isActive = true AND s.type = 'SECURITY' ORDER BY s.configKey ASC")
    List<SystemInfo> findSecurityConfigs();
    
    // 获取配置键值对（用于缓存）
    @Query("SELECT s.configKey, s.configValue FROM SystemInfo s WHERE s.isActive = true")
    List<Object[]> findConfigKeyValuePairs();
    
    // 获取特定类型的配置键值对
    @Query("SELECT s.configKey, s.configValue FROM SystemInfo s WHERE s.isActive = true AND s.type = :type")
    List<Object[]> findConfigKeyValuePairsByType(@Param("type") SystemInfo.ConfigType type);
    
    // 统计各类型配置数量
    @Query("SELECT s.type, COUNT(s) FROM SystemInfo s GROUP BY s.type ORDER BY COUNT(s) DESC")
    List<Object[]> countSystemInfoByType();
    
    // 统计激活和非激活配置数量
    @Query("SELECT s.isActive, COUNT(s) FROM SystemInfo s GROUP BY s.isActive ORDER BY s.isActive DESC")
    List<Object[]> countSystemInfoByActiveStatus();
    
    // 获取最近更新的配置
    @Query("SELECT s FROM SystemInfo s ORDER BY s.updatedTime DESC")
    List<SystemInfo> findRecentlyUpdatedConfigs(Pageable pageable);
    
    // 获取特定时间范围内更新的配置
    @Query("SELECT s FROM SystemInfo s WHERE s.updatedTime >= :startTime AND s.updatedTime <= :endTime ORDER BY s.updatedTime DESC")
    List<SystemInfo> findConfigsByUpdateTimeRange(@Param("startTime") java.time.LocalDateTime startTime, @Param("endTime") java.time.LocalDateTime endTime);
} 