package com.example.sp.Repository;

import com.example.sp.Entity.Video;
import com.example.sp.Entity.User;
import com.example.sp.Entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface VideoRepository extends JpaRepository<Video, Long> {
    
    // 基本查询方法
    List<Video> findByUser(User user);
    
    Page<Video> findByUser(User user, Pageable pageable);
    
    List<Video> findByCategory(Category category);
    
    Page<Video> findByCategory(Category category, Pageable pageable);
    
    // 根据状态查询
    List<Video> findByStatus(Video.VideoStatus status);
    
    Page<Video> findByStatus(Video.VideoStatus status, Pageable pageable);
    
    // 根据可见性查询
    List<Video> findByVisibility(Video.VideoVisibility visibility);
    
    Page<Video> findByVisibility(Video.VideoVisibility visibility, Pageable pageable);
    
    // 根据审核状态查询
    List<Video> findByIsApproved(Boolean isApproved);
    
    Page<Video> findByIsApproved(Boolean isApproved, Pageable pageable);
    
    // 根据用户和状态查询
    List<Video> findByUserAndStatus(User user, Video.VideoStatus status);
    
    Page<Video> findByUserAndStatus(User user, Video.VideoStatus status, Pageable pageable);
    
    // 根据分类和状态查询
    List<Video> findByCategoryAndStatus(Category category, Video.VideoStatus status);
    
    Page<Video> findByCategoryAndStatus(Category category, Video.VideoStatus status, Pageable pageable);
    
    // 模糊查询
    List<Video> findByTitleContainingOrDescriptionContaining(String title, String description);
    
    Page<Video> findByTitleContainingOrDescriptionContaining(String title, String description, Pageable pageable);
    
    // 根据创建时间查询
    List<Video> findByCreatedTimeBetween(LocalDateTime startTime, LocalDateTime endTime);
    
    List<Video> findByCreatedTimeAfter(LocalDateTime startTime);
    
    // 根据观看次数排序
    List<Video> findByStatusOrderByViewCountDesc(Video.VideoStatus status);
    
    Page<Video> findByStatusOrderByViewCountDesc(Video.VideoStatus status, Pageable pageable);
    
    // 根据点赞次数排序
    List<Video> findByStatusOrderByLikeCountDesc(Video.VideoStatus status);
    
    Page<Video> findByStatusOrderByLikeCountDesc(Video.VideoStatus status, Pageable pageable);
    
    // 根据评论次数排序
    List<Video> findByStatusOrderByCommentCountDesc(Video.VideoStatus status);
    
    Page<Video> findByStatusOrderByCommentCountDesc(Video.VideoStatus status, Pageable pageable);
    
    // 根据创建时间排序
    List<Video> findByStatusOrderByCreatedTimeDesc(Video.VideoStatus status);
    
    Page<Video> findByStatusOrderByCreatedTimeDesc(Video.VideoStatus status, Pageable pageable);
    
    // 根据时长查询
    List<Video> findByDurationBetween(Long minDuration, Long maxDuration);
    
    List<Video> findByDurationLessThan(Long maxDuration);
    
    List<Video> findByDurationGreaterThan(Long minDuration);
    
    // 根据文件大小查询
    List<Video> findByFileSizeBetween(Long minSize, Long maxSize);
    
    List<Video> findByFileSizeLessThan(Long maxSize);
    
    // 统计查询
    @Query("SELECT COUNT(v) FROM Video v WHERE v.status = :status")
    long countByStatus(@Param("status") Video.VideoStatus status);
    
    @Query("SELECT COUNT(v) FROM Video v WHERE v.user = :user")
    long countByUser(@Param("user") User user);
    
    @Query("SELECT COUNT(v) FROM Video v WHERE v.category = :category")
    long countByCategory(@Param("category") Category category);
    
    @Query("SELECT COUNT(v) FROM Video v WHERE v.isApproved = :isApproved")
    long countByIsApproved(@Param("isApproved") Boolean isApproved);
    
    @Query("SELECT COUNT(v) FROM Video v WHERE v.createdTime >= :startTime")
    long countByCreatedTimeAfter(@Param("startTime") LocalDateTime startTime);
    
    // 统计各分类下视频数量
    @Query("SELECT v.category.name, COUNT(v) FROM Video v GROUP BY v.category.name")
    List<Object[]> countVideosByCategory();

    // 统计某天上传视频数量
    long countByCreatedTimeBetween(LocalDateTime start, LocalDateTime end);
    
    // 复杂查询
    @Query("SELECT v FROM Video v WHERE v.title LIKE %:keyword% OR v.description LIKE %:keyword%")
    Page<Video> searchVideos(@Param("keyword") String keyword, Pageable pageable);
    
    @Query("SELECT v FROM Video v WHERE v.status = :status AND (v.title LIKE %:keyword% OR v.description LIKE %:keyword%)")
    Page<Video> searchVideosByStatus(@Param("keyword") String keyword, @Param("status") Video.VideoStatus status, Pageable pageable);
    
    // 获取热门视频
    @Query("SELECT v FROM Video v WHERE v.status = 'APPROVED' ORDER BY v.viewCount DESC")
    List<Video> findPopularVideos(Pageable pageable);
    
    // 获取最新视频
    @Query("SELECT v FROM Video v WHERE v.status = 'APPROVED' ORDER BY v.createdTime DESC")
    List<Video> findLatestVideos(Pageable pageable);
    
    // 获取推荐视频（基于点赞和观看）
    @Query("SELECT v FROM Video v WHERE v.status = 'APPROVED' ORDER BY (v.likeCount + v.viewCount * 0.1) DESC")
    List<Video> findRecommendedVideos(Pageable pageable);
    
    // 根据标签查询视频
    @Query("SELECT DISTINCT v FROM Video v JOIN v.tags t WHERE t.name = :tagName AND v.status = 'APPROVED'")
    Page<Video> findVideosByTag(@Param("tagName") String tagName, Pageable pageable);
    
    // 获取用户点赞的视频
    @Query("SELECT v FROM Video v JOIN v.likedByUsers u WHERE u.id = :userId")
    Page<Video> findLikedVideosByUser(@Param("userId") Long userId, Pageable pageable);
    
    // 获取用户收藏的视频
    @Query("SELECT v FROM Video v JOIN v.favoritedByUsers u WHERE u.id = :userId")
    Page<Video> findFavoriteVideosByUser(@Param("userId") Long userId, Pageable pageable);
    
    // 获取待审核的视频
    @Query("SELECT v FROM Video v WHERE v.status = 'PENDING' ORDER BY v.createdTime ASC")
    Page<Video> findPendingVideos(Pageable pageable);
    
    // 获取被拒绝的视频
    @Query("SELECT v FROM Video v WHERE v.status = 'REJECTED' ORDER BY v.updatedTime DESC")
    Page<Video> findRejectedVideos(Pageable pageable);
    
    // 获取特定时间范围内的视频
    @Query("SELECT v FROM Video v WHERE v.createdTime >= :startDate AND v.createdTime <= :endDate ORDER BY v.createdTime DESC")
    List<Video> findVideosByDateRange(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    // 管理员统计方法
    @Query("SELECT COALESCE(SUM(v.viewCount), 0) FROM Video v")
    long getTotalViews();
    
    @Query("SELECT COALESCE(SUM(v.viewCount), 0) FROM Video v WHERE v.createdTime >= :today")
    long getTodayViews(@Param("today") LocalDateTime today);
} 