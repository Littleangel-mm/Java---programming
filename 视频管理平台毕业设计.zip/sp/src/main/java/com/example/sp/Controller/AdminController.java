package com.example.sp.Controller;

import com.example.sp.Entity.Video;
import com.example.sp.Entity.User;
import com.example.sp.Service.VideoService;
import com.example.sp.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.hardware.GlobalMemory;
import oshi.software.os.OperatingSystem;
import oshi.software.os.OSFileStore;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    private VideoService videoService;
    
    @Autowired
    private UserService userService;

    /**
     * 作者：Littleangel-mm
     * 获取仪表板统计数据
     */
    @GetMapping("/dashboard/stats")
    public ResponseEntity<Map<String, Object>> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        
        // 使用真实数据
        stats.put("totalUsers", userService.countAllUsers());
        stats.put("totalVideos", videoService.countAllVideos());
        stats.put("totalViews", videoService.getTotalViews());
        stats.put("totalComments", 0L); // 暂时设为0
        stats.put("todayNewUsers", userService.countTodayNewUsers());
        stats.put("todayNewVideos", videoService.countTodayNewVideos());
        stats.put("todayViews", videoService.getTodayViews());
        stats.put("todayComments", 0L); // 暂时设为0
        stats.put("pendingVideos", videoService.countPendingVideos());
        stats.put("pendingComments", 0L); // 暂时设为0
        stats.put("reportedContent", videoService.countReportedContent());
        
        return ResponseEntity.ok(stats);
    }

    /**
     * 获取系统信息（真实数据）
     */
    @GetMapping("/system/info")
    public ResponseEntity<Map<String, Object>> getSystemInfo() {
        Map<String, Object> systemInfo = new HashMap<>();
        SystemInfo si = new SystemInfo();

        // 运行时间
        OperatingSystem os = si.getOperatingSystem();
        long uptimeSec = os.getSystemUptime();
        long days = uptimeSec / (24 * 3600);
        long hours = (uptimeSec % (24 * 3600)) / 3600;
        long minutes = (uptimeSec % 3600) / 60;
        systemInfo.put("uptime", days + "天 " + hours + "小时 " + minutes + "分钟");

        // CPU使用率（修正版）
        CentralProcessor processor = si.getHardware().getProcessor();
        long[] prevTicks = processor.getSystemCpuLoadTicks();
        try { Thread.sleep(100); } catch (InterruptedException e) { }
        double cpuLoad = processor.getSystemCpuLoadBetweenTicks(prevTicks) * 100;
        systemInfo.put("cpuUsage", (int) cpuLoad);

        // 内存使用率
        GlobalMemory memory = si.getHardware().getMemory();
        long totalMem = memory.getTotal();
        long usedMem = totalMem - memory.getAvailable();
        int memUsage = (int) (usedMem * 100 / totalMem);
        systemInfo.put("memoryUsage", memUsage);

        // 磁盘使用率
        long totalDisk = 0, usedDisk = 0;
        for (OSFileStore fs : os.getFileSystem().getFileStores()) {
            totalDisk += fs.getTotalSpace();
            usedDisk += (fs.getTotalSpace() - fs.getUsableSpace());
        }
        int diskUsage = totalDisk > 0 ? (int) (usedDisk * 100 / totalDisk) : 0;
        systemInfo.put("diskUsage", diskUsage);

        // 在线用户（如有业务实现可替换）
        systemInfo.put("onlineUsers", userService.countOnlineUsers());

        return ResponseEntity.ok(systemInfo);
    }

    /**
     * 获取待审核视频列表
     */
    @GetMapping("/audit/videos/pending")
    public ResponseEntity<Map<String, Object>> getPendingVideos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<Video> videos = videoService.findPendingVideos(pageable);
            
            Map<String, Object> response = new HashMap<>();
            response.put("content", videos.getContent());
            response.put("totalElements", videos.getTotalElements());
            response.put("totalPages", videos.getTotalPages());
            response.put("currentPage", page);
            response.put("size", size);
            response.put("success", true);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "获取待审核视频失败: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * 审核通过视频
     */
    @PostMapping("/audit/videos/{id}/approve")
    public ResponseEntity<Map<String, Object>> approveVideo(
            @PathVariable Long id, 
            @RequestParam Long adminId) {
        try {
            // 验证管理员
            User admin = userService.findUserById(adminId)
                    .orElseThrow(() -> new RuntimeException("管理员不存在"));
            
            if (!"ADMIN".equals(admin.getRole().toString())) {
                throw new RuntimeException("权限不足，只有管理员可以审核视频");
            }
            
            Video approvedVideo = videoService.approveVideo(id, adminId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "视频审核通过成功");
            response.put("data", approvedVideo);
            
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "审核失败: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * 审核拒绝视频
     */
    @PostMapping("/audit/videos/{id}/reject")
    public ResponseEntity<Map<String, Object>> rejectVideo(
            @PathVariable Long id, 
            @RequestParam Long adminId,
            @RequestBody Map<String, String> request) {
        try {
            // 验证管理员
            User admin = userService.findUserById(adminId)
                    .orElseThrow(() -> new RuntimeException("管理员不存在"));
            
            if (!"ADMIN".equals(admin.getRole().toString())) {
                throw new RuntimeException("权限不足，只有管理员可以审核视频");
            }
            
            String reason = request.get("reason");
            if (reason == null || reason.trim().isEmpty()) {
                reason = "内容不符合平台规范";
            }
            
            Video rejectedVideo = videoService.rejectVideo(id, adminId, reason);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "视频审核拒绝成功");
            response.put("data", rejectedVideo);
            
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "审核失败: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * 批量审核通过视频
     */
    @PostMapping("/audit/videos/batch/approve")
    public ResponseEntity<Map<String, Object>> batchApproveVideos(
            @RequestBody Map<String, Object> request) {
        try {
            @SuppressWarnings("unchecked")
            java.util.List<Long> videoIds = (java.util.List<Long>) request.get("videoIds");
            Long adminId = Long.valueOf(request.get("adminId").toString());
            
            if (videoIds == null || videoIds.isEmpty()) {
                throw new RuntimeException("请选择要审核的视频");
            }
            
            // 验证管理员
            User admin = userService.findUserById(adminId)
                    .orElseThrow(() -> new RuntimeException("管理员不存在"));
            
            if (!"ADMIN".equals(admin.getRole().toString())) {
                throw new RuntimeException("权限不足，只有管理员可以审核视频");
            }
            
            videoService.batchApproveVideos(videoIds, adminId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "批量审核通过成功，共处理 " + videoIds.size() + " 个视频");
            
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "批量审核失败: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * 批量审核拒绝视频
     */
    @PostMapping("/audit/videos/batch/reject")
    public ResponseEntity<Map<String, Object>> batchRejectVideos(
            @RequestBody Map<String, Object> request) {
        try {
            @SuppressWarnings("unchecked")
            java.util.List<Long> videoIds = (java.util.List<Long>) request.get("videoIds");
            Long adminId = Long.valueOf(request.get("adminId").toString());
            String reason = (String) request.get("reason");
            
            if (videoIds == null || videoIds.isEmpty()) {
                throw new RuntimeException("请选择要审核的视频");
            }
            
            if (reason == null || reason.trim().isEmpty()) {
                reason = "内容不符合平台规范";
            }
            
            // 验证管理员
            User admin = userService.findUserById(adminId)
                    .orElseThrow(() -> new RuntimeException("管理员不存在"));
            
            if (!"ADMIN".equals(admin.getRole().toString())) {
                throw new RuntimeException("权限不足，只有管理员可以审核视频");
            }
            
            videoService.batchRejectVideos(videoIds, adminId, reason);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "批量审核拒绝成功，共处理 " + videoIds.size() + " 个视频");
            
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "批量审核失败: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * 获取视频审核统计
     */
    @GetMapping("/audit/videos/stats")
    public ResponseEntity<Map<String, Object>> getVideoAuditStats() {
        try {
            Map<String, Object> stats = new HashMap<>();
            stats.put("pendingCount", videoService.countPendingVideos());
            stats.put("approvedCount", videoService.countVideosByIsApproved(true));
            stats.put("rejectedCount", videoService.countVideosByStatus(Video.VideoStatus.REJECTED));
            stats.put("totalCount", videoService.countAllVideos());
            stats.put("success", true);
            
            return ResponseEntity.ok(stats);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "获取审核统计失败: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

//    /**
//     * 视频分类分布统计
//     */
//    @GetMapping("/dashboard/video-category-stats")
//    public ResponseEntity<List<Map<String, Object>>> getVideoCategoryStats() {
//        return ResponseEntity.ok(videoService.getVideoCategoryStats());
//    }
//
//    /**
//     * 视频上传趋势统计
//     */
//    @GetMapping("/dashboard/video-upload-trend")
//    public ResponseEntity<List<Map<String, Object>>> getVideoUploadTrend() {
//        return ResponseEntity.ok(videoService.getVideoUploadTrend());
}