package com.example.sp.dao;

import com.example.sp.Entity.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/**
 * 标签数据访问对象接口
 * 提供标签相关的高级数据访问操作
 */
public interface TagDao {
    
    /**
     * 根据名称查找标签
     */
    Optional<Tag> findByName(String name);
    
    /**
     * 根据名称列表查找标签
     */
    List<Tag> findByNames(List<String> names);
    
    /**
     * 根据颜色查找标签
     */
    List<Tag> findByColor(String color);
    
    /**
     * 分页查询标签
     */
    Page<Tag> findTagsWithPagination(Pageable pageable);
    
    /**
     * 搜索标签
     */
    Page<Tag> searchTags(String keyword, String color, Pageable pageable);
    
    /**
     * 获取热门标签
     */
    List<TagWithVideoCount> getPopularTags(int limit);
    
    /**
     * 获取标签统计信息
     */
    TagStatistics getTagStatistics();
    
    /**
     * 获取标签下的视频数量
     */
    long getVideoCountByTag(Long tagId);
    
    /**
     * 根据视频ID获取标签
     */
    List<Tag> findByVideoId(Long videoId);
    
    /**
     * 检查标签名称是否存在
     */
    boolean existsByName(String name);
    
    /**
     * 获取标签建议（基于名称前缀）
     */
    List<Tag> getTagSuggestions(String prefix, int limit);
    
    /**
     * 获取相关标签
     */
    List<Tag> getRelatedTags(Long tagId, int limit);
    
    /**
     * 标签统计信息内部类
     */
    class TagStatistics {
        private long totalTags;
        private long usedTags;
        private long unusedTags;
        private long totalVideoCount;
        
        public TagStatistics(long totalTags, long usedTags, long unusedTags, long totalVideoCount) {
            this.totalTags = totalTags;
            this.usedTags = usedTags;
            this.unusedTags = unusedTags;
            this.totalVideoCount = totalVideoCount;
        }
        
        // Getters
        public long getTotalTags() { return totalTags; }
        public long getUsedTags() { return usedTags; }
        public long getUnusedTags() { return unusedTags; }
        public long getTotalVideoCount() { return totalVideoCount; }
    }
    
    /**
     * 带视频数量的标签内部类
     */
    class TagWithVideoCount {
        private Long tagId;
        private String tagName;
        private String tagColor;
        private long videoCount;
        
        public TagWithVideoCount(Long tagId, String tagName, String tagColor, long videoCount) {
            this.tagId = tagId;
            this.tagName = tagName;
            this.tagColor = tagColor;
            this.videoCount = videoCount;
        }
        
        // Getters
        public Long getTagId() { return tagId; }
        public String getTagName() { return tagName; }
        public String getTagColor() { return tagColor; }
        public long getVideoCount() { return videoCount; }
    }
} 