package com.example.sp.Service.impl;

import com.example.sp.Entity.Comment;
import com.example.sp.Entity.User;
import com.example.sp.Entity.Video;
import com.example.sp.Repository.CommentRepository;
import com.example.sp.Service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class CommentServiceImpl implements CommentService {
    
    @Autowired
    private CommentRepository commentRepository;
    
    // 基本CRUD操作
    @Override
    public Comment saveComment(Comment comment) {
        return commentRepository.save(comment);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Optional<Comment> findCommentById(Long id) {
        return commentRepository.findById(id);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findAllComments() {
        return commentRepository.findAll();
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Comment> findAllComments(Pageable pageable) {
        return commentRepository.findAll(pageable);
    }
    
    @Override
    public void deleteCommentById(Long id) {
        commentRepository.deleteById(id);
    }
    
    // 评论管理
    @Override
    public Comment addComment(Comment comment, User user, Video video) {
        comment.setUser(user);
        comment.setVideo(video);
        comment.setStatus(Comment.CommentStatus.ACTIVE);
        comment.setCreatedTime(LocalDateTime.now());
        comment.setUpdatedTime(LocalDateTime.now());
        return commentRepository.save(comment);
    }
    
    @Override
    public Comment updateComment(Long commentId, Comment commentDetails) {
        Comment comment = findCommentById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));
        
        if (commentDetails.getContent() != null) {
            comment.setContent(commentDetails.getContent());
        }
        comment.setUpdatedTime(LocalDateTime.now());
        
        return commentRepository.save(comment);
    }
    
    @Override
    public Comment approveComment(Long commentId, Long approvedBy) {
        Comment comment = findCommentById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));
        comment.setStatus(Comment.CommentStatus.ACTIVE);
        comment.setUpdatedTime(LocalDateTime.now());
        return commentRepository.save(comment);
    }
    
    @Override
    public Comment rejectComment(Long commentId, Long rejectedBy, String reason) {
        Comment comment = findCommentById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));
        comment.setStatus(Comment.CommentStatus.HIDDEN);
        comment.setUpdatedTime(LocalDateTime.now());
        return commentRepository.save(comment);
    }
    
    // 评论查询
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentsByVideo(Video video) {
        return commentRepository.findByVideo(video);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Comment> findCommentsByVideo(Video video, Pageable pageable) {
        return commentRepository.findByVideo(video, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentsByUser(User user) {
        return commentRepository.findByUser(user);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Comment> findCommentsByUser(User user, Pageable pageable) {
        return commentRepository.findByUser(user, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentsByStatus(Comment.CommentStatus status) {
        return commentRepository.findByStatus(status);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Comment> findCommentsByStatus(Comment.CommentStatus status, Pageable pageable) {
        return commentRepository.findByStatus(status, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentsByParentComment(Comment parentComment) {
        return commentRepository.findByParent(parentComment);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Comment> findCommentsByParentComment(Comment parentComment, Pageable pageable) {
        // 简化实现，返回空分页
        return Page.empty(pageable);
    }
    
    // 用户互动
    @Override
    public void likeComment(Long userId, Long commentId) {
        // 简化实现，实际应该检查用户是否已经点赞
        incrementLikeCount(commentId);
    }
    
    @Override
    public void unlikeComment(Long userId, Long commentId) {
        // 简化实现，实际应该检查用户是否已经点赞
        decrementLikeCount(commentId);
    }
    
    @Override
    @Transactional(readOnly = true)
    public boolean isLikedByUser(Long userId, Long commentId) {
        // 简化实现，返回false
        return false;
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findLikedCommentsByUser(Long userId, Pageable pageable) {
        // 简化实现，返回空列表
        return new java.util.ArrayList<>();
    }
    
    // 评论统计
    @Override
    public void incrementLikeCount(Long commentId) {
        Comment comment = findCommentById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));
        comment.setLikeCount(comment.getLikeCount() + 1);
        commentRepository.save(comment);
    }
    
    @Override
    public void decrementLikeCount(Long commentId) {
        Comment comment = findCommentById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));
        if (comment.getLikeCount() > 0) {
            comment.setLikeCount(comment.getLikeCount() - 1);
            commentRepository.save(comment);
        }
    }
    
    @Override
    public void incrementReplyCount(Long commentId) {
        Comment comment = findCommentById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));
        comment.setReplyCount(comment.getReplyCount() + 1);
        commentRepository.save(comment);
    }
    
    @Override
    public void decrementReplyCount(Long commentId) {
        Comment comment = findCommentById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));
        if (comment.getReplyCount() > 0) {
            comment.setReplyCount(comment.getReplyCount() - 1);
            commentRepository.save(comment);
        }
    }
    
    // 审核管理
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findPendingComments(Pageable pageable) {
        // 简化实现，返回空列表
        return new java.util.ArrayList<>();
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findRejectedComments(Pageable pageable) {
        return commentRepository.findHiddenComments(pageable).getContent();
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findApprovedComments(Pageable pageable) {
        return commentRepository.findByStatus(Comment.CommentStatus.ACTIVE, pageable).getContent();
    }
    
    // 时间范围查询
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentsByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return commentRepository.findByCreatedTimeBetween(startDate, endDate);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentsByCreatedTimeAfter(LocalDateTime startTime) {
        return commentRepository.findByCreatedTimeAfter(startTime);
    }
    
    // 排序查询
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentsByStatusOrderByLikeCountDesc(Comment.CommentStatus status) {
        return commentRepository.findByStatusOrderByLikeCountDesc(status);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentsByStatusOrderByCreatedTimeDesc(Comment.CommentStatus status) {
        return commentRepository.findByStatusOrderByCreatedTimeDesc(status);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentsByVideoOrderByCreatedTimeDesc(Video video) {
        return commentRepository.findByVideoAndParentIsNullOrderByCreatedTimeDesc(video);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentsByVideoOrderByLikeCountDesc(Video video) {
        // 简化实现，返回按创建时间排序的评论
        return commentRepository.findByVideoAndParentIsNullOrderByCreatedTimeDesc(video);
    }
    
    // 统计查询
    @Override
    @Transactional(readOnly = true)
    public long countCommentsByStatus(Comment.CommentStatus status) {
        return commentRepository.countByStatus(status);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countCommentsByUser(User user) {
        return commentRepository.countByUser(user);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countCommentsByVideo(Video video) {
        return commentRepository.countByVideo(video);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countCommentsByIsApproved(Boolean isApproved) {
        // 简化实现，返回0
        return 0;
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countCommentsByCreatedTimeAfter(LocalDateTime startTime) {
        return commentRepository.countByCreatedTimeAfter(startTime);
    }
    
    // 批量操作
    @Override
    public void batchApproveComments(List<Long> commentIds, Long approvedBy) {
        for (Long commentId : commentIds) {
            approveComment(commentId, approvedBy);
        }
    }
    
    @Override
    public void batchRejectComments(List<Long> commentIds, Long rejectedBy, String reason) {
        for (Long commentId : commentIds) {
            rejectComment(commentId, rejectedBy, reason);
        }
    }
    
    @Override
    public void batchDeleteComments(List<Long> commentIds) {
        commentRepository.deleteAllById(commentIds);
    }
    
    @Override
    public void batchUpdateCommentStatus(List<Long> commentIds, Comment.CommentStatus status) {
        for (Long commentId : commentIds) {
            Comment comment = findCommentById(commentId)
                    .orElseThrow(() -> new RuntimeException("评论不存在"));
            comment.setStatus(status);
            comment.setUpdatedTime(LocalDateTime.now());
            commentRepository.save(comment);
        }
    }
    
    // 评论树结构
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentTreeByVideo(Video video) {
        // 简化实现，返回所有评论
        return commentRepository.findByVideo(video);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findCommentReplies(Comment parentComment) {
        return commentRepository.findByParent(parentComment);
    }
    
    @Override
    @Transactional(readOnly = true)
    public int getCommentDepth(Comment comment) {
        // 简化实现，所有评论深度都是1
        return 1;
    }
    
    // 热门评论
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findHotCommentsByVideo(Video video, Pageable pageable) {
        return commentRepository.findByVideoAndParentIsNullOrderByCreatedTimeDesc(video);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findHotComments(Pageable pageable) {
        return commentRepository.findByStatusOrderByLikeCountDesc(Comment.CommentStatus.ACTIVE);
    }
    
    // 搜索功能
    @Override
    @Transactional(readOnly = true)
    public List<Comment> searchComments(String keyword) {
        // 简化实现，返回空列表
        return new java.util.ArrayList<>();
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Comment> searchComments(String keyword, Pageable pageable) {
        return commentRepository.searchComments(keyword, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Comment> findCommentsByVideoId(Long videoId, Pageable pageable) {
        return commentRepository.findByVideo_Id(videoId, pageable);
    }
    
    // 评论通知
    @Override
    public void notifyCommentReply(Comment comment, Comment parentComment) {
        // 简化实现，实际应该发送通知
    }
    
    @Override
    public void notifyCommentLike(Comment comment, User liker) {
        // 简化实现，实际应该发送通知
    }
    
    // 内容审核
    @Override
    @Transactional(readOnly = true)
    public boolean isCommentContentAppropriate(String content) {
        // 简化实现，总是返回true
        return true;
    }
    
    @Override
    public void flagCommentAsInappropriate(Long commentId, Long flaggedBy, String reason) {
        Comment comment = findCommentById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));
        
        comment.setStatus(Comment.CommentStatus.HIDDEN);
        comment.setUpdatedTime(LocalDateTime.now());
        
        commentRepository.save(comment);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Comment> findFlaggedComments(Pageable pageable) {
        // 简化实现，返回空列表
        return new java.util.ArrayList<>();
    }
    
    // 管理员统计方法
    @Override
    @Transactional(readOnly = true)
    public long countAllComments() {
        return commentRepository.count();
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countTodayComments() {
        LocalDateTime today = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0).withNano(0);
        return commentRepository.countByCreatedTimeAfter(today);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countPendingComments() {
        // 简化实现，返回0
        return 0;
    }
} 