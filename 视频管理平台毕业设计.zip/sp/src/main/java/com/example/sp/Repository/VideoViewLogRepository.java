package com.example.sp.Repository;

import com.example.sp.Entity.VideoViewLog;
import com.example.sp.dto.VideoViewPieDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface VideoViewLogRepository extends JpaRepository<VideoViewLog, Long> {
    @Query("SELECT new com.example.sp.dto.VideoViewPieDTO(v.title, COUNT(l)) " +
            "FROM VideoViewLog l JOIN l.video v " +
            "WHERE l.viewTime >= :startTime " +
            "GROUP BY v.id, v.title")
    List<VideoViewPieDTO> findVideoViewPieLast7Days(@Param("startTime") LocalDateTime startTime);
} 