package com.example.sp.dao;

import com.example.sp.Entity.Comment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/**
 * 评论数据访问对象接口
 * 提供评论相关的高级数据访问操作
 */
public interface CommentDao {
    
    /**
     * 根据视频ID查找评论
     */
    List<Comment> findByVideoId(Long videoId);
    
    /**
     * 根据用户ID查找评论
     */
    List<Comment> findByUserId(Long userId);
    
    /**
     * 根据父评论ID查找子评论
     */
    List<Comment> findByParentId(Long parentId);
    
    /**
     * 根据评论状态查找评论
     */
    List<Comment> findByStatus(Comment.CommentStatus status);
    
    /**
     * 分页查询评论
     */
    Page<Comment> findCommentsWithPagination(Pageable pageable);
    
    /**
     * 根据视频ID分页查询评论
     */
    Page<Comment> findCommentsByVideoId(Long videoId, Pageable pageable);
    
    /**
     * 根据用户ID分页查询评论
     */
    Page<Comment> findCommentsByUserId(Long userId, Pageable pageable);
    
    /**
     * 搜索评论
     */
    Page<Comment> searchComments(String keyword, Long videoId, Long userId, 
                               Comment.CommentStatus status, Pageable pageable);
    
    /**
     * 获取热门评论
     */
    List<Comment> getPopularComments(int limit);
    
    /**
     * 获取最新评论
     */
    List<Comment> getLatestComments(int limit);
    
    /**
     * 获取评论统计信息
     */
    CommentStatistics getCommentStatistics();
    
    /**
     * 获取视频评论数量
     */
    long getCommentCountByVideo(Long videoId);
    
    /**
     * 获取用户评论数量
     */
    long getCommentCountByUser(Long userId);
    
    /**
     * 获取评论点赞数
     */
    long getLikeCount(Long commentId);
    
    /**
     * 检查用户是否点赞评论
     */
    boolean isLikedByUser(Long commentId, Long userId);
    
    /**
     * 获取评论树结构
     */
    List<CommentTree> getCommentTree(Long videoId);
    
    /**
     * 评论统计信息内部类
     */
    class CommentStatistics {
        private long totalComments;
        private long approvedComments;
        private long pendingComments;
        private long rejectedComments;
        private long totalLikes;
        private long totalReplies;
        
        public CommentStatistics(long totalComments, long approvedComments, long pendingComments, 
                               long rejectedComments, long totalLikes, long totalReplies) {
            this.totalComments = totalComments;
            this.approvedComments = approvedComments;
            this.pendingComments = pendingComments;
            this.rejectedComments = rejectedComments;
            this.totalLikes = totalLikes;
            this.totalReplies = totalReplies;
        }
        
        // Getters
        public long getTotalComments() { return totalComments; }
        public long getApprovedComments() { return approvedComments; }
        public long getPendingComments() { return pendingComments; }
        public long getRejectedComments() { return rejectedComments; }
        public long getTotalLikes() { return totalLikes; }
        public long getTotalReplies() { return totalReplies; }
    }
    
    /**
     * 评论树结构内部类
     */
    class CommentTree {
        private Comment comment;
        private List<CommentTree> children;
        private long likeCount;
        private long replyCount;
        
        public CommentTree(Comment comment) {
            this.comment = comment;
            this.children = new java.util.ArrayList<>();
        }
        
        // Getters and Setters
        public Comment getComment() { return comment; }
        public List<CommentTree> getChildren() { return children; }
        public void setChildren(List<CommentTree> children) { this.children = children; }
        public long getLikeCount() { return likeCount; }
        public void setLikeCount(long likeCount) { this.likeCount = likeCount; }
        public long getReplyCount() { return replyCount; }
        public void setReplyCount(long replyCount) { this.replyCount = replyCount; }
    }
} 