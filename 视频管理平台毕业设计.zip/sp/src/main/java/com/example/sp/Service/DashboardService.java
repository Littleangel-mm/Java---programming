package com.example.sp.Service;

import com.example.sp.dto.VideoTypeBarDTO;
import com.example.sp.dto.CommentPieDTO;
import java.util.List;

public interface DashboardService {
    List<CommentPieDTO> getCommentPieLast7Days();
    List<VideoTypeBarDTO> getVideoTypeBarLast7Days();
} 