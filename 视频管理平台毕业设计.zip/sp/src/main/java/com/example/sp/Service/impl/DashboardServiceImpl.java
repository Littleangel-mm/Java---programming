package com.example.sp.Service.impl;

import com.example.sp.Repository.CommentRepository;
import com.example.sp.Repository.VideoRepository;
import com.example.sp.Service.DashboardService;
import com.example.sp.dto.VideoTypeBarDTO;
import com.example.sp.dto.CommentPieDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DashboardServiceImpl implements DashboardService {
    @Autowired
    private CommentRepository commentRepository;
    @Autowired
    private VideoRepository videoRepository;

    @Override
    public List<CommentPieDTO> getCommentPieLast7Days() {
        LocalDateTime sevenDaysAgo = LocalDateTime.now().minusDays(7);
        return commentRepository.findCommentPieLast7Days(sevenDaysAgo);
    }

    @Override
    public List<VideoTypeBarDTO> getVideoTypeBarLast7Days() {
        LocalDateTime sevenDaysAgo = LocalDateTime.now().minusDays(7);
        return videoRepository.findAll().stream()
                .filter(v -> v.getCreatedTime() != null && v.getCreatedTime().isAfter(sevenDaysAgo))
                .collect(Collectors.groupingBy(
                        v -> v.getCategory() != null ? v.getCategory().getName() : "未分类",
                        Collectors.counting()
                ))
                .entrySet().stream()
                .map(e -> new VideoTypeBarDTO(e.getKey(), e.getValue()))
                .collect(Collectors.toList());
    }
} 