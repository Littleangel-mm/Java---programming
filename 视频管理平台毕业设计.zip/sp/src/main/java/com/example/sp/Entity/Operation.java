package com.example.sp.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "operations")
@EntityListeners(AuditingEntityListener.class)
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Operation {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Enumerated(EnumType.STRING)
    private OperationType type;
    
    private String title;
    
    private String description;
    
    @Column(name = "target_type")
    @Enumerated(EnumType.STRING)
    private TargetType targetType;
    
    @Column(name = "target_id")
    private Long targetId;
    
    @Column(name = "operator_id")
    private Long operatorId;
    
    @Column(name = "operator_name")
    private String operatorName;
    
    @Enumerated(EnumType.STRING)
    private OperationStatus status = OperationStatus.PENDING;
    
    @Column(name = "start_time")
    private LocalDateTime startTime;
    
    @Column(name = "end_time")
    private LocalDateTime endTime;
    
    @Column(name = "created_time", updatable = false)
    @CreatedDate
    private LocalDateTime createdTime;
    
    @Column(name = "updated_time")
    @LastModifiedDate
    private LocalDateTime updatedTime;
    
    public enum OperationType {
        PROMOTION, BANNER, NOTIFICATION, MAINTENANCE, FEATURE_UPDATE
    }
    
    public enum TargetType {
        VIDEO, USER, CATEGORY, SYSTEM
    }
    
    public enum OperationStatus {
        PENDING, ACTIVE, COMPLETED, CANCELLED
    }
    
    // 自定义构造函数
    public Operation(OperationType type, String title, String description) {
        this.type = type;
        this.title = title;
        this.description = description;
    }
} 