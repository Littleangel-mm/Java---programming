package com.example.sp.Repository;

import com.example.sp.Entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {
    
    // 基本查询方法
    Optional<Category> findByName(String name);
    
    boolean existsByName(String name);
    
    // 根据激活状态查询
    List<Category> findByIsActive(Boolean isActive);
    
    Page<Category> findByIsActive(Boolean isActive, Pageable pageable);
    
    // 根据排序顺序查询
    List<Category> findByIsActiveOrderBySortOrderAsc(Boolean isActive);
    
    // 模糊查询
    List<Category> findByNameContainingOrDescriptionContaining(String name, String description);
    
    Page<Category> findByNameContainingOrDescriptionContaining(String name, String description, Pageable pageable);
    
    // 根据排序顺序范围查询
    List<Category> findBySortOrderBetween(Integer minOrder, Integer maxOrder);
    
    List<Category> findBySortOrderGreaterThan(Integer minOrder);
    
    List<Category> findBySortOrderLessThan(Integer maxOrder);
    
    // 统计查询
    @Query("SELECT COUNT(c) FROM Category c WHERE c.isActive = :isActive")
    long countByIsActive(@Param("isActive") Boolean isActive);
    
    // 复杂查询
    @Query("SELECT c FROM Category c WHERE c.name LIKE %:keyword% OR c.description LIKE %:keyword%")
    Page<Category> searchCategories(@Param("keyword") String keyword, Pageable pageable);
    
    // 获取所有激活的分类（按排序顺序）
    @Query("SELECT c FROM Category c WHERE c.isActive = true ORDER BY c.sortOrder ASC")
    List<Category> findAllActiveOrderBySortOrder();
    
    // 获取分类及其视频数量
    @Query("SELECT c, COUNT(v) as videoCount FROM Category c LEFT JOIN c.videos v WHERE c.isActive = true GROUP BY c ORDER BY c.sortOrder ASC")
    List<Object[]> findCategoriesWithVideoCount();
    
    // 获取有视频的分类
    @Query("SELECT DISTINCT c FROM Category c JOIN c.videos v WHERE c.isActive = true ORDER BY c.sortOrder ASC")
    List<Category> findCategoriesWithVideos();
    
    // 获取空分类（没有视频的分类）
    @Query("SELECT c FROM Category c WHERE c.isActive = true AND SIZE(c.videos) = 0 ORDER BY c.sortOrder ASC")
    List<Category> findEmptyCategories();
} 