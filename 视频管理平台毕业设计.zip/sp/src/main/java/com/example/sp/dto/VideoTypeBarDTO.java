package com.example.sp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VideoTypeBarDTO {
    private String type;
    private Long uploadCount;
} 