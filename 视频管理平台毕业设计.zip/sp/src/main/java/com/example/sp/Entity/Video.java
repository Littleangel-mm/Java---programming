package com.example.sp.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "videos")
@EntityListeners(AuditingEntityListener.class)
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"user", "category", "tags", "comments", "likedByUsers", "favoritedByUsers"})
public class Video {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank
    @Size(max = 200)
    private String title;
    
    @Size(max = 1000)
    private String description;
    
    @NotBlank
    @Size(max = 500)
    @Column(name = "file_path")
    private String filePath; // 本地文件路径
    
    @Size(max = 500)
    private String coverUrl;
    
    @Size(max = 500)
    private String thumbnailUrl;
    
    private Long duration; // 视频时长（秒）
    
    private Long fileSize; // 文件大小（字节）
    
    @Size(max = 50)
    private String resolution; // 分辨率
    
    @Size(max = 20)
    private String format; // 视频格式
    
    @Enumerated(EnumType.STRING)
    private VideoStatus status = VideoStatus.PENDING;
    
    @Enumerated(EnumType.STRING)
    private VideoVisibility visibility = VideoVisibility.PUBLIC;
    
    // 统计信息
    @Column(name = "view_count")
    private Long viewCount = 0L;
    
    @Column(name = "like_count")
    private Long likeCount = 0L;
    
    @Column(name = "comment_count")
    private Long commentCount = 0L;
    
    @Column(name = "share_count")
    private Long shareCount = 0L;
    
    @Column(name = "favorite_count")
    private Long favoriteCount = 0L;
    
    // 审核信息
    @Column(name = "is_approved")
    private Boolean isApproved = false;
    
    @Column(name = "approved_time")
    private LocalDateTime approvedTime;
    
    @Column(name = "approved_by")
    private Long approvedBy;
    
    @Size(max = 500)
    @Column(name = "reject_reason")
    private String rejectReason;
    
    @CreatedDate
    @Column(name = "created_time", updatable = false)
    private LocalDateTime createdTime;
    
    @LastModifiedDate
    @Column(name = "updated_time")
    private LocalDateTime updatedTime;
    
    // 关联关系
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private User user;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
    private Category category;
    
    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
        name = "video_tags",
        joinColumns = @JoinColumn(name = "video_id"),
        inverseJoinColumns = @JoinColumn(name = "tag_id")
    )
    private Set<Tag> tags = new HashSet<>();
    
    @OneToMany(mappedBy = "video", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<Comment> comments = new HashSet<>();
    
    @ManyToMany(mappedBy = "likedVideos", fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<User> likedByUsers = new HashSet<>();
    
    @ManyToMany(mappedBy = "favoriteVideos", fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<User> favoritedByUsers = new HashSet<>();
    
    public enum VideoStatus {
        PENDING, APPROVED, REJECTED, DELETED
    }
    
    public enum VideoVisibility {
        PUBLIC, PRIVATE, UNLISTED
    }
    
    // 自定义构造函数
    public Video(String title, String description, String filePath, User user) {
        this.title = title;
        this.description = description;
        this.filePath = filePath;
        this.user = user;
    }
} 