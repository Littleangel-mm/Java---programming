package com.example.sp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 映射视频文件 - 恢复原来的路径，但添加更具体的映射优先级
        registry.addResourceHandler("/videos/**")
                .addResourceLocations("file:uploads/videos/");
        
        // 映射缩略图和其他文件
        registry.addResourceHandler("/files/**")
                .addResourceLocations("file:uploads/files/");
        
        // 映射上传目录
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:uploads/");
    }
} 