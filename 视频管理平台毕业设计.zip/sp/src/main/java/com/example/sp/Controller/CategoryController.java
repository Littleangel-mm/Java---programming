package com.example.sp.Controller;

import com.example.sp.Entity.Category;
import com.example.sp.Service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/categories")
@CrossOrigin(origins = "*")
public class CategoryController {
    
    @Autowired
    private CategoryService categoryService;
    
    // 创建分类
    @PostMapping
    public ResponseEntity<?> createCategory(@Valid @RequestBody Category category) {
        try {
            Category createdCategory = categoryService.createCategory(category);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdCategory);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取所有分类（分页）
    @GetMapping
    public ResponseEntity<Page<Category>> getAllCategories(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Category> categories = categoryService.findAllCategories(pageable);
        return ResponseEntity.ok(categories);
    }
    
    // 根据ID获取分类
    @GetMapping("/{id}")
    public ResponseEntity<?> getCategoryById(@PathVariable Long id) {
        return categoryService.findCategoryById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    // 根据名称获取分类
    @GetMapping("/name/{name}")
    public ResponseEntity<?> getCategoryByName(@PathVariable String name) {
        return categoryService.findCategoryByName(name)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    // 更新分类
    @PutMapping("/{id}")
    public ResponseEntity<?> updateCategory(@PathVariable Long id, @RequestBody Category categoryDetails) {
        try {
            Category updatedCategory = categoryService.updateCategory(id, categoryDetails);
            return ResponseEntity.ok(updatedCategory);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 删除分类
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCategory(@PathVariable Long id) {
        try {
            categoryService.deleteCategoryById(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "分类删除成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 更新分类状态
    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateCategoryStatus(
            @PathVariable Long id, 
            @RequestBody Map<String, Boolean> request) {
        
        Boolean isActive = request.get("isActive");
        try {
            Category updatedCategory = categoryService.updateCategoryStatus(id, isActive);
            return ResponseEntity.ok(updatedCategory);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 更新分类排序
    @PutMapping("/{id}/sort-order")
    public ResponseEntity<?> updateCategorySortOrder(
            @PathVariable Long id, 
            @RequestBody Map<String, Integer> request) {
        
        Integer sortOrder = request.get("sortOrder");
        try {
            Category updatedCategory = categoryService.updateCategorySortOrder(id, sortOrder);
            return ResponseEntity.ok(updatedCategory);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 根据状态获取分类
    @GetMapping("/status/{isActive}")
    public ResponseEntity<List<Category>> getCategoriesByStatus(@PathVariable Boolean isActive) {
        List<Category> categories = categoryService.findCategoriesByStatus(isActive);
        return ResponseEntity.ok(categories);
    }
    
    // 获取活跃分类
    @GetMapping("/active")
    public ResponseEntity<List<Category>> getActiveCategories() {
        List<Category> categories = categoryService.findActiveCategories();
        return ResponseEntity.ok(categories);
    }
    
    // 获取根分类
    @GetMapping("/root")
    public ResponseEntity<List<Category>> getRootCategories() {
        List<Category> categories = categoryService.findRootCategories();
        return ResponseEntity.ok(categories);
    }
    
    // 获取叶子分类
    @GetMapping("/leaf")
    public ResponseEntity<List<Category>> getLeafCategories() {
        List<Category> categories = categoryService.findLeafCategories();
        return ResponseEntity.ok(categories);
    }
    
    // 获取分类树
    @GetMapping("/tree")
    public ResponseEntity<List<Category>> getCategoryTree() {
        List<Category> categories = categoryService.findCategoryTree();
        return ResponseEntity.ok(categories);
    }
    
    // 获取子分类
    @GetMapping("/{parentId}/subcategories")
    public ResponseEntity<List<Category>> getSubCategories(@PathVariable Long parentId) {
        List<Category> categories = categoryService.findSubCategories(parentId);
        return ResponseEntity.ok(categories);
    }
    
    // 获取分类路径
    @GetMapping("/{categoryId}/path")
    public ResponseEntity<List<Category>> getCategoryPath(@PathVariable Long categoryId) {
        List<Category> categories = categoryService.findCategoryPath(categoryId);
        return ResponseEntity.ok(categories);
    }
    
    // 获取分类深度
    @GetMapping("/{categoryId}/depth")
    public ResponseEntity<?> getCategoryDepth(@PathVariable Long categoryId) {
        try {
            Category category = categoryService.findCategoryById(categoryId)
                    .orElseThrow(() -> new RuntimeException("分类不存在"));
            int depth = categoryService.getCategoryDepth(category);
            Map<String, Integer> response = new HashMap<>();
            response.put("depth", depth);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取分类级别
    @GetMapping("/{categoryId}/level")
    public ResponseEntity<?> getCategoryLevel(@PathVariable Long categoryId) {
        try {
            int level = categoryService.getCategoryLevel(categoryId);
            Map<String, Integer> response = new HashMap<>();
            response.put("level", level);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 按排序顺序获取分类
    @GetMapping("/sorted")
    public ResponseEntity<List<Category>> getCategoriesOrderBySortOrder() {
        List<Category> categories = categoryService.findCategoriesOrderBySortOrder();
        return ResponseEntity.ok(categories);
    }
    
    // 按名称排序获取分类
    @GetMapping("/sorted/name")
    public ResponseEntity<List<Category>> getCategoriesOrderByName() {
        List<Category> categories = categoryService.findCategoriesOrderByName();
        return ResponseEntity.ok(categories);
    }
    
    // 按创建时间排序获取分类
    @GetMapping("/sorted/created-time")
    public ResponseEntity<List<Category>> getCategoriesOrderByCreatedTime() {
        List<Category> categories = categoryService.findCategoriesOrderByCreatedTime();
        return ResponseEntity.ok(categories);
    }
    
    // 按视频数量排序获取分类
    @GetMapping("/sorted/video-count")
    public ResponseEntity<List<Category>> getCategoriesOrderByVideoCount() {
        List<Category> categories = categoryService.findCategoriesOrderByVideoCount();
        return ResponseEntity.ok(categories);
    }
    
    // 搜索分类
    @GetMapping("/search")
    public ResponseEntity<Page<Category>> searchCategories(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        Page<Category> categories = categoryService.searchCategories(keyword, pageable);
        return ResponseEntity.ok(categories);
    }
    
    // 批量更新分类状态
    @PutMapping("/batch/status")
    public ResponseEntity<?> batchUpdateCategoryStatus(
            @RequestBody Map<String, Object> request) {
        
        @SuppressWarnings("unchecked")
        List<Long> categoryIds = (List<Long>) request.get("categoryIds");
        Boolean isActive = (Boolean) request.get("isActive");
        
        try {
            categoryService.batchUpdateCategoryStatus(categoryIds, isActive);
            Map<String, String> response = new HashMap<>();
            response.put("message", "批量更新成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 批量删除分类
    @DeleteMapping("/batch")
    public ResponseEntity<?> batchDeleteCategories(@RequestBody List<Long> categoryIds) {
        try {
            categoryService.batchDeleteCategories(categoryIds);
            Map<String, String> response = new HashMap<>();
            response.put("message", "批量删除成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 批量更新分类排序
    @PutMapping("/batch/sort-order")
    public ResponseEntity<?> batchUpdateCategorySortOrder(
            @RequestBody Map<String, Object> request) {
        
        @SuppressWarnings("unchecked")
        List<Long> categoryIds = (List<Long>) request.get("categoryIds");
        @SuppressWarnings("unchecked")
        List<Integer> sortOrders = (List<Integer>) request.get("sortOrders");
        
        try {
            categoryService.batchUpdateCategorySortOrder(categoryIds, sortOrders);
            Map<String, String> response = new HashMap<>();
            response.put("message", "批量更新排序成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 移动分类
    @PutMapping("/{categoryId}/move/{newParentId}")
    public ResponseEntity<?> moveCategory(@PathVariable Long categoryId, @PathVariable Long newParentId) {
        try {
            categoryService.moveCategory(categoryId, newParentId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "分类移动成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 移动分类到根级
    @PutMapping("/batch/move-to-root")
    public ResponseEntity<?> moveCategoriesToRoot(@RequestBody List<Long> categoryIds) {
        try {
            categoryService.moveCategoriesToRoot(categoryIds);
            Map<String, String> response = new HashMap<>();
            response.put("message", "分类移动到根级成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 合并分类
    @PostMapping("/merge")
    public ResponseEntity<?> mergeCategories(@RequestBody Map<String, Object> request) {
        Long targetCategoryId = Long.valueOf(request.get("targetCategoryId").toString());
        @SuppressWarnings("unchecked")
        List<Long> sourceCategoryIds = (List<Long>) request.get("sourceCategoryIds");
        
        try {
            Category mergedCategory = categoryService.mergeCategories(targetCategoryId, sourceCategoryIds);
            return ResponseEntity.ok(mergedCategory);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 复制分类
    @PostMapping("/copy")
    public ResponseEntity<?> copyCategory(@RequestBody Map<String, Object> request) {
        Long sourceCategoryId = Long.valueOf(request.get("sourceCategoryId").toString());
        String newName = (String) request.get("newName");
        Long newParentId = Long.valueOf(request.get("newParentId").toString());
        
        try {
            Category copiedCategory = categoryService.copyCategory(sourceCategoryId, newName, newParentId);
            return ResponseEntity.ok(copiedCategory);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 验证分类层次结构
    @GetMapping("/{categoryId}/validate-hierarchy")
    public ResponseEntity<?> validateCategoryHierarchy(@PathVariable Long categoryId) {
        try {
            Category category = categoryService.findCategoryById(categoryId)
                    .orElseThrow(() -> new RuntimeException("分类不存在"));
            boolean isValid = categoryService.isValidCategoryHierarchy(category);
            Map<String, Boolean> response = new HashMap<>();
            response.put("isValid", isValid);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 检查循环引用
    @GetMapping("/{categoryId}/check-circular")
    public ResponseEntity<?> checkCircularReference(@PathVariable Long categoryId) {
        try {
            Category category = categoryService.findCategoryById(categoryId)
                    .orElseThrow(() -> new RuntimeException("分类不存在"));
            boolean hasCircular = categoryService.hasCircularReference(category);
            Map<String, Boolean> response = new HashMap<>();
            response.put("hasCircularReference", hasCircular);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 获取热门分类
    @GetMapping("/popular")
    public ResponseEntity<List<Category>> getPopularCategories(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Category> categories = categoryService.findPopularCategories(pageable);
        return ResponseEntity.ok(categories);
    }
    
    // 获取趋势分类
    @GetMapping("/trending")
    public ResponseEntity<List<Category>> getTrendingCategories(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Pageable pageable = PageRequest.of(page, size);
        List<Category> categories = categoryService.findTrendingCategories(pageable);
        return ResponseEntity.ok(categories);
    }
    
    // 刷新分类缓存
    @PostMapping("/refresh-cache")
    public ResponseEntity<?> refreshCategoryCache() {
        try {
            categoryService.refreshCategoryCache();
            Map<String, String> response = new HashMap<>();
            response.put("message", "缓存刷新成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 清除分类缓存
    @DeleteMapping("/clear-cache")
    public ResponseEntity<?> clearCategoryCache() {
        try {
            categoryService.clearCategoryCache();
            Map<String, String> response = new HashMap<>();
            response.put("message", "缓存清除成功");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 导入分类
    @PostMapping("/import")
    public ResponseEntity<?> importCategories(@RequestBody List<Category> categories) {
        try {
            List<Category> importedCategories = categoryService.importCategories(categories);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "分类导入成功");
            response.put("importedCount", importedCategories.size());
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    // 导出分类
    @GetMapping("/export")
    public ResponseEntity<List<Category>> exportCategories() {
        List<Category> categories = categoryService.exportCategories();
        return ResponseEntity.ok(categories);
    }
    
    // 获取分类统计信息
    @GetMapping("/stats")
    public ResponseEntity<?> getCategoryStats() {
        Map<String, Object> stats = new HashMap<>();
        
        stats.put("totalCategories", categoryService.countCategoriesByStatus(true));
        stats.put("activeCategories", categoryService.countCategoriesByStatus(true));
        stats.put("inactiveCategories", categoryService.countCategoriesByStatus(false));
        stats.put("rootCategories", categoryService.countRootCategories());
        stats.put("leafCategories", categoryService.countLeafCategories());
        
        return ResponseEntity.ok(stats);
    }
    
    // 检查分类名称是否存在
    @GetMapping("/check-name/{name}")
    public ResponseEntity<?> checkCategoryNameExists(@PathVariable String name) {
        boolean exists = categoryService.existsByName(name);
        Map<String, Boolean> response = new HashMap<>();
        response.put("exists", exists);
        return ResponseEntity.ok(response);
    }
} 