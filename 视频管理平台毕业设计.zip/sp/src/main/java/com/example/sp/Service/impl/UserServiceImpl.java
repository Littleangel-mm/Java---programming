package com.example.sp.Service.impl;

import com.example.sp.Entity.User;
import com.example.sp.Repository.UserRepository;
import com.example.sp.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserServiceImpl implements UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    // 基本CRUD操作
    @Override
    public User saveUser(User user) {
        // 如果密码不是BCrypt格式，则加密密码
        if (user.getPassword() != null && !user.getPassword().startsWith("$2a$")) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        return userRepository.save(user);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Optional<User> findUserById(Long id) {
        return userRepository.findById(id);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Optional<User> findUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Optional<User> findUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<User> findAllUsers() {
        return userRepository.findAll();
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<User> findAllUsers(Pageable pageable) {
        return userRepository.findAll(pageable);
    }
    
    @Override
    public void deleteUserById(Long id) {
        userRepository.deleteById(id);
    }
    
    @Override
    @Transactional(readOnly = true)
    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }
    
    @Override
    @Transactional(readOnly = true)
    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }
    
    // 用户注册和认证
    @Override
    public User registerUser(User user) {
        // 检查用户名和邮箱是否已存在
        if (existsByUsername(user.getUsername())) {
            throw new RuntimeException("用户名已存在");
        }
        if (existsByEmail(user.getEmail())) {
            throw new RuntimeException("邮箱已存在");
        }
        
        // 加密密码
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        
        // 设置默认值
        user.setRole(User.UserRole.USER);
        user.setStatus(User.UserStatus.ACTIVE);
        user.setLoginCount(0);
        
        return userRepository.save(user);
    }
    
    @Override
    public User updateUserProfile(Long userId, User userDetails) {
        User user = findUserById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        
        // 更新基本信息
        if (userDetails.getNickname() != null) {
            user.setNickname(userDetails.getNickname());
        }
        if (userDetails.getAvatar() != null) {
            user.setAvatar(userDetails.getAvatar());
        }
        if (userDetails.getBio() != null) {
            user.setBio(userDetails.getBio());
        }
        if (userDetails.getAge() != null) {
            user.setAge(userDetails.getAge());
        }
        if (userDetails.getPhone() != null) {
            user.setPhone(userDetails.getPhone());
        }
        if (userDetails.getLocation() != null) {
            user.setLocation(userDetails.getLocation());
        }
        
        return userRepository.save(user);
    }
    
    @Override
    public void updateLastLoginTime(Long userId) {
        User user = findUserById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        user.setLastLoginTime(LocalDateTime.now());
        userRepository.save(user);
    }
    
    @Override
    public void incrementLoginCount(Long userId) {
        User user = findUserById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        user.setLoginCount(user.getLoginCount() + 1);
        userRepository.save(user);
    }
    
    // 角色和状态管理
    @Override
    @Transactional(readOnly = true)
    public List<User> findUsersByRole(User.UserRole role) {
        return userRepository.findByRole(role);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<User> findUsersByRole(User.UserRole role, Pageable pageable) {
        return userRepository.findByRole(role, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<User> findUsersByStatus(User.UserStatus status) {
        return userRepository.findByStatus(status);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<User> findUsersByStatus(User.UserStatus status, Pageable pageable) {
        return userRepository.findByStatus(status, pageable);
    }
    
    @Override
    public User updateUserRole(Long userId, User.UserRole role) {
        User user = findUserById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        user.setRole(role);
        return userRepository.save(user);
    }
    
    @Override
    public User updateUserStatus(Long userId, User.UserStatus status) {
        User user = findUserById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        user.setStatus(status);
        return userRepository.save(user);
    }
    
    // 搜索和查询
    @Override
    @Transactional(readOnly = true)
    public List<User> searchUsers(String keyword) {
        return userRepository.findByUsernameContainingOrNicknameContaining(keyword, keyword);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<User> searchUsers(String keyword, Pageable pageable) {
        return userRepository.searchUsers(keyword, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<User> findUsersByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return userRepository.findUsersByDateRange(startDate, endDate);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<User> findActiveUsers(Integer minLoginCount, Pageable pageable) {
        return userRepository.findActiveUsers(minLoginCount, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<User> findRecentUsers(Pageable pageable) {
        return userRepository.findRecentUsers(pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<User> findRecentlyLoggedInUsers(Pageable pageable) {
        return userRepository.findRecentlyLoggedInUsers(pageable);
    }
    
    // 用户统计
    @Override
    @Transactional(readOnly = true)
    public long countUsersByRole(User.UserRole role) {
        return userRepository.countByRole(role);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countUsersByStatus(User.UserStatus status) {
        return userRepository.countByStatus(status);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countUsersByCreatedTimeAfter(LocalDateTime startTime) {
        return userRepository.countByCreatedTimeAfter(startTime);
    }
    
    // 用户关系管理
    @Override
    public void followUser(Long followerId, Long followingId) {
        User follower = findUserById(followerId)
                .orElseThrow(() -> new RuntimeException("关注者不存在"));
        User following = findUserById(followingId)
                .orElseThrow(() -> new RuntimeException("被关注者不存在"));
        
        if (followerId.equals(followingId)) {
            throw new RuntimeException("不能关注自己");
        }
        
        follower.getFollowing().add(following);
        userRepository.save(follower);
    }
    
    @Override
    public void unfollowUser(Long followerId, Long followingId) {
        User follower = findUserById(followerId)
                .orElseThrow(() -> new RuntimeException("关注者不存在"));
        User following = findUserById(followingId)
                .orElseThrow(() -> new RuntimeException("被关注者不存在"));
        
        follower.getFollowing().remove(following);
        userRepository.save(follower);
    }
    
    @Override
    @Transactional(readOnly = true)
    public boolean isFollowing(Long followerId, Long followingId) {
        User follower = findUserById(followerId)
                .orElseThrow(() -> new RuntimeException("关注者不存在"));
        User following = findUserById(followingId)
                .orElseThrow(() -> new RuntimeException("被关注者不存在"));
        
        return follower.getFollowing().contains(following);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<User> findFollowers(Long userId, Pageable pageable) {
        User user = findUserById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        return userRepository.findAll(pageable).getContent(); // 简化实现
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<User> findFollowing(Long userId, Pageable pageable) {
        User user = findUserById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        return userRepository.findAll(pageable).getContent(); // 简化实现
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countFollowers(Long userId) {
        User user = findUserById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        return user.getFollowers().size();
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countFollowing(Long userId) {
        User user = findUserById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        return user.getFollowing().size();
    }
    
    // 密码管理
    @Override
    public void changePassword(Long userId, String oldPassword, String newPassword) {
        User user = findUserById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        
        if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
            throw new RuntimeException("原密码错误");
        }
        
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
    }
    
    @Override
    public void resetPassword(Long userId, String newPassword) {
        User user = findUserById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
    }
    
    // 用户验证
    @Override
    @Transactional(readOnly = true)
    public boolean validateUserCredentials(String username, String password) {
        System.out.println("验证用户凭据 - 用户名: " + username);
        
        Optional<User> userOpt = findUserByUsername(username);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            System.out.println("找到用户: " + user.getUsername() + ", 角色: " + user.getRole());
            System.out.println("数据库密码: " + user.getPassword());
            System.out.println("输入密码: " + password);
            
            boolean matches = passwordEncoder.matches(password, user.getPassword());
            System.out.println("密码匹配结果: " + matches);
            return matches;
        } else {
            System.out.println("用户不存在: " + username);
        }
        return false;
    }
    
    // 批量操作
    @Override
    public void batchUpdateUserStatus(List<Long> userIds, User.UserStatus status) {
        for (Long userId : userIds) {
            updateUserStatus(userId, status);
        }
    }
    
    @Override
    public void batchDeleteUsers(List<Long> userIds) {
        userRepository.deleteAllById(userIds);
    }
    
    // 管理员统计方法
    @Override
    @Transactional(readOnly = true)
    public long countAllUsers() {
        return userRepository.count();
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countTodayNewUsers() {
        LocalDateTime today = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0).withNano(0);
        return userRepository.countByCreatedTimeAfter(today);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countOnlineUsers() {
        // 这里可以根据实际需求实现在线用户统计
        // 暂时返回一个模拟值
        return userRepository.countByStatus(User.UserStatus.ACTIVE);
    }
} 