package com.example.sp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VideoViewPieDTO {
    private String videoTitle;
    private Long viewCount;
} 