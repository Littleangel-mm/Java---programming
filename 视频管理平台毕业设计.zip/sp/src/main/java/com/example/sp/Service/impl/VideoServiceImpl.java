package com.example.sp.Service.impl;

import com.example.sp.Entity.Video;
import com.example.sp.Entity.User;
import com.example.sp.Entity.Category;
import com.example.sp.Repository.VideoRepository;
import com.example.sp.Repository.UserRepository;
import com.example.sp.Repository.CategoryRepository;
import com.example.sp.Service.VideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.stream.Collectors;

@Service
@Transactional
public class VideoServiceImpl implements VideoService {
    
    @Autowired
    private VideoRepository videoRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private CategoryRepository categoryRepository;
    
    // 基本CRUD操作
    @Override
    public Video saveVideo(Video video) {
        return videoRepository.save(video);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Optional<Video> findVideoById(Long id) {
        return videoRepository.findById(id);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findAllVideos() {
        return videoRepository.findAll();
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Video> findAllVideos(Pageable pageable) {
        return videoRepository.findAll(pageable);
    }
    
    @Override
    public void deleteVideoById(Long id) {
        videoRepository.deleteById(id);
    }
    
    // 视频上传和管理
    @Override
    public Video uploadVideo(Video video, User user) {
        video.setUser(user);
        video.setStatus(Video.VideoStatus.PENDING);
        video.setIsApproved(false);
        video.setViewCount(0L);
        video.setLikeCount(0L);
        video.setCommentCount(0L);
        video.setShareCount(0L);
        video.setFavoriteCount(0L);
        
        // 处理视频上传
        processVideoUpload(video);
        
        return videoRepository.save(video);
    }
    
    @Override
    public Video updateVideo(Long videoId, Video videoDetails) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        
        // 更新基本信息
        if (videoDetails.getTitle() != null) {
            video.setTitle(videoDetails.getTitle());
        }
        if (videoDetails.getDescription() != null) {
            video.setDescription(videoDetails.getDescription());
        }
        if (videoDetails.getThumbnailUrl() != null) {
            video.setThumbnailUrl(videoDetails.getThumbnailUrl());
        }
        if (videoDetails.getVisibility() != null) {
            video.setVisibility(videoDetails.getVisibility());
        }
        if (videoDetails.getCategory() != null) {
            video.setCategory(videoDetails.getCategory());
        }
        if (videoDetails.getTags() != null) {
            video.setTags(videoDetails.getTags());
        }
        
        return videoRepository.save(video);
    }
    
    @Override
    public Video approveVideo(Long videoId, Long approvedBy) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        User approver = userRepository.findById(approvedBy)
                .orElseThrow(() -> new RuntimeException("审核员不存在"));
        
        video.setStatus(Video.VideoStatus.APPROVED);
        video.setIsApproved(true);
        video.setApprovedBy(approver.getId());
        video.setApprovedTime(LocalDateTime.now());
        
        return videoRepository.save(video);
    }
    
    @Override
    public Video rejectVideo(Long videoId, Long rejectedBy, String reason) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        User rejecter = userRepository.findById(rejectedBy)
                .orElseThrow(() -> new RuntimeException("审核员不存在"));
        
        video.setStatus(Video.VideoStatus.REJECTED);
        video.setIsApproved(false);
        video.setRejectReason(reason);
        
        return videoRepository.save(video);
    }
    
    // 视频查询
    @Override
    @Transactional(readOnly = true)
    public List<Video> findVideosByUser(User user) {
        return videoRepository.findByUser(user);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Video> findVideosByUser(User user, Pageable pageable) {
        return videoRepository.findByUser(user, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findVideosByCategory(Category category) {
        return videoRepository.findByCategory(category);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Video> findVideosByCategory(Category category, Pageable pageable) {
        return videoRepository.findByCategory(category, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findVideosByStatus(Video.VideoStatus status) {
        return videoRepository.findByStatus(status);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Video> findVideosByStatus(Video.VideoStatus status, Pageable pageable) {
        return videoRepository.findByStatus(status, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findVideosByVisibility(Video.VideoVisibility visibility) {
        return videoRepository.findByVisibility(visibility);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Video> findVideosByVisibility(Video.VideoVisibility visibility, Pageable pageable) {
        return videoRepository.findByVisibility(visibility, pageable);
    }
    
    // 热门和推荐视频
    @Override
    @Transactional(readOnly = true)
    public List<Video> findPopularVideos(Pageable pageable) {
        return videoRepository.findPopularVideos(pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findLatestVideos(Pageable pageable) {
        return videoRepository.findLatestVideos(pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findRecommendedVideos(Pageable pageable) {
        return videoRepository.findRecommendedVideos(pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findTrendingVideos(Pageable pageable) {
        // 使用推荐视频作为趋势视频的替代
        return videoRepository.findRecommendedVideos(pageable);
    }
    
    // 搜索功能
    @Override
    @Transactional(readOnly = true)
    public List<Video> searchVideos(String keyword) {
        return videoRepository.findByTitleContainingOrDescriptionContaining(keyword, keyword);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Video> searchVideos(String keyword, Pageable pageable) {
        return videoRepository.searchVideos(keyword, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findVideosByTag(String tagName, Pageable pageable) {
        return videoRepository.findVideosByTag(tagName, pageable).getContent();
    }
    
    // 用户互动
    @Override
    public void likeVideo(Long userId, Long videoId) {
        User user = userRepository.findById(userId).orElseThrow();
        Video video = videoRepository.findById(videoId).orElseThrow();
        user.getLikedVideos().add(video);
        userRepository.save(user);
        // 统计最新点赞数并同步
        long count = video.getLikedByUsers().size();
        video.setLikeCount(count);
        videoRepository.save(video);
    }

    @Override
    public void unlikeVideo(Long userId, Long videoId) {
        User user = userRepository.findById(userId).orElseThrow();
        Video video = videoRepository.findById(videoId).orElseThrow();
        user.getLikedVideos().remove(video);
        userRepository.save(user);
        // 统计最新点赞数并同步
        long count = video.getLikedByUsers().size();
        video.setLikeCount(count);
        videoRepository.save(video);
    }

    @Override
    public void favoriteVideo(Long userId, Long videoId) {
        User user = userRepository.findById(userId).orElseThrow();
        Video video = videoRepository.findById(videoId).orElseThrow();
        user.getFavoriteVideos().add(video);
        userRepository.save(user);
    }

    @Override
    public void unfavoriteVideo(Long userId, Long videoId) {
        User user = userRepository.findById(userId).orElseThrow();
        Video video = videoRepository.findById(videoId).orElseThrow();
        user.getFavoriteVideos().remove(video);
        userRepository.save(user);
    }
    
    @Override
    @Transactional(readOnly = true)
    public boolean isLikedByUser(Long userId, Long videoId) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        
        return video.getLikedByUsers().contains(user);
    }
    
    @Override
    @Transactional(readOnly = true)
    public boolean isFavoritedByUser(Long userId, Long videoId) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("用户不存在"));
        
        return video.getFavoritedByUsers().contains(user);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Video> findLikedVideosByUser(Long userId, Pageable pageable) {
        return videoRepository.findLikedVideosByUser(userId, pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Video> findFavoriteVideosByUser(Long userId, Pageable pageable) {
        return videoRepository.findFavoriteVideosByUser(userId, pageable);
    }
    
    // 视频统计
    @Override
    public void incrementViewCount(Long videoId) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        video.setViewCount(video.getViewCount() + 1);
        videoRepository.save(video);
    }
    
    @Override
    public void incrementLikeCount(Long videoId) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        video.setLikeCount(video.getLikeCount() + 1);
        videoRepository.save(video);
    }
    
    @Override
    public void decrementLikeCount(Long videoId) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        video.setLikeCount(Math.max(0, video.getLikeCount() - 1));
        videoRepository.save(video);
    }
    
    @Override
    public void incrementCommentCount(Long videoId) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        video.setCommentCount(video.getCommentCount() + 1);
        videoRepository.save(video);
    }
    
    @Override
    public void decrementCommentCount(Long videoId) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        video.setCommentCount(Math.max(0, video.getCommentCount() - 1));
        videoRepository.save(video);
    }
    
    @Override
    public void incrementShareCount(Long videoId) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        video.setShareCount(video.getShareCount() + 1);
        videoRepository.save(video);
    }
    
    @Override
    public void incrementFavoriteCount(Long videoId) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        video.setFavoriteCount(video.getFavoriteCount() + 1);
        videoRepository.save(video);
    }
    
    @Override
    public void decrementFavoriteCount(Long videoId) {
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        video.setFavoriteCount(Math.max(0, video.getFavoriteCount() - 1));
        videoRepository.save(video);
    }
    
    // 审核管理
    @Override
    @Transactional(readOnly = true)
    public Page<Video> findPendingVideos(Pageable pageable) {
        return videoRepository.findPendingVideos(pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Video> findRejectedVideos(Pageable pageable) {
        return videoRepository.findRejectedVideos(pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<Video> findApprovedVideos(Pageable pageable) {
        return videoRepository.findByIsApproved(true, pageable);
    }
    
    // 时间范围查询
    @Override
    @Transactional(readOnly = true)
    public List<Video> findVideosByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return videoRepository.findVideosByDateRange(startDate, endDate);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findVideosByCreatedTimeAfter(LocalDateTime startTime) {
        return videoRepository.findByCreatedTimeAfter(startTime);
    }
    
    // 排序查询
    @Override
    @Transactional(readOnly = true)
    public List<Video> findVideosByStatusOrderByViewCountDesc(Video.VideoStatus status) {
        return videoRepository.findByStatusOrderByViewCountDesc(status);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findVideosByStatusOrderByLikeCountDesc(Video.VideoStatus status) {
        return videoRepository.findByStatusOrderByLikeCountDesc(status);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findVideosByStatusOrderByCommentCountDesc(Video.VideoStatus status) {
        return videoRepository.findByStatusOrderByCommentCountDesc(status);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> findVideosByStatusOrderByCreatedTimeDesc(Video.VideoStatus status) {
        return videoRepository.findByStatusOrderByCreatedTimeDesc(status);
    }
    
    // 统计查询
    @Override
    @Transactional(readOnly = true)
    public long countVideosByStatus(Video.VideoStatus status) {
        return videoRepository.countByStatus(status);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countVideosByUser(User user) {
        return videoRepository.countByUser(user);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countVideosByCategory(Category category) {
        return videoRepository.countByCategory(category);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countVideosByIsApproved(Boolean isApproved) {
        return videoRepository.countByIsApproved(isApproved);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countVideosByCreatedTimeAfter(LocalDateTime startTime) {
        return videoRepository.countByCreatedTimeAfter(startTime);
    }
    
    // 批量操作
    @Override
    public void batchApproveVideos(List<Long> videoIds, Long approvedBy) {
        for (Long videoId : videoIds) {
            approveVideo(videoId, approvedBy);
        }
    }
    
    @Override
    public void batchRejectVideos(List<Long> videoIds, Long rejectedBy, String reason) {
        for (Long videoId : videoIds) {
            rejectVideo(videoId, rejectedBy, reason);
        }
    }
    
    @Override
    public void batchDeleteVideos(List<Long> videoIds) {
        videoRepository.deleteAllById(videoIds);
    }
    
    @Override
    public void batchUpdateVideoStatus(List<Long> videoIds, Video.VideoStatus status) {
        for (Long videoId : videoIds) {
            Video video = findVideoById(videoId)
                    .orElseThrow(() -> new RuntimeException("视频不存在"));
            video.setStatus(status);
            videoRepository.save(video);
        }
    }
    
    // 视频处理
    @Override
    public void processVideoUpload(Video video) {
        // 视频处理逻辑
        generateVideoThumbnail(video);
        extractVideoMetadata(video);
    }
    
    @Override
    public void generateVideoThumbnail(Video video) {
        // 生成视频缩略图逻辑
        // 这里可以调用FFmpeg或其他视频处理库
    }
    
    @Override
    public void extractVideoMetadata(Video video) {
        // 提取视频元数据逻辑
        // 获取视频时长、分辨率等信息
        if (video.getFilePath() != null && !video.getFilePath().isEmpty()) {
            java.nio.file.Path path;
            if (video.getFilePath().startsWith("uploads/")) {
                path = java.nio.file.Paths.get(video.getFilePath());
            } else {
                path = java.nio.file.Paths.get("uploads", video.getFilePath());
            }
            Long duration = com.example.sp.utils.VideoUtils.extractVideoDuration(path);
            if (duration != null && duration > 0) {
                video.setDuration(duration);
            }
        }
    }
    
    // 推荐算法
    @Override
    @Transactional(readOnly = true)
    public List<Video> getPersonalizedRecommendations(Long userId, Pageable pageable) {
        // 个性化推荐算法
        // 基于用户历史行为、偏好等
        return videoRepository.findRecommendedVideos(pageable);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<Video> getSimilarVideos(Long videoId, Pageable pageable) {
        // 相似视频推荐算法
        // 基于标签、分类、内容相似度等
        return videoRepository.findRecommendedVideos(pageable);
    }
    
    // 缓存管理
    @Override
    public void clearVideoCache(Long videoId) {
        // 清除视频缓存逻辑
    }
    
    @Override
    public void refreshVideoStatistics(Long videoId) {
        // 刷新视频统计数据
        Video video = findVideoById(videoId)
                .orElseThrow(() -> new RuntimeException("视频不存在"));
        
        // 重新计算统计数据
        video.setLikeCount((long) video.getLikedByUsers().size());
        video.setFavoriteCount((long) video.getFavoritedByUsers().size());
        
        videoRepository.save(video);
    }
    
    // 管理员统计方法
    @Override
    @Transactional(readOnly = true)
    public long countAllVideos() {
        return videoRepository.count();
    }
    
    @Override
    @Transactional(readOnly = true)
    public long getTotalViews() {
        return videoRepository.getTotalViews();
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countTodayNewVideos() {
        LocalDateTime today = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0).withNano(0);
        return videoRepository.countByCreatedTimeAfter(today);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long getTodayViews() {
        LocalDateTime today = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0).withNano(0);
        return videoRepository.getTodayViews(today);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countPendingVideos() {
        return videoRepository.countByStatus(Video.VideoStatus.PENDING);
    }
    
    @Override
    @Transactional(readOnly = true)
    public long countReportedContent() {
        // 简化实现，返回0
        return 0;
    }

    @Override
    public List<Map<String, Object>> getVideoCategoryStats() {
        List<Object[]> results = videoRepository.countVideosByCategory();
        return results.stream().map(obj -> {
            Map<String, Object> map = new HashMap<>();
            map.put("category", obj[0]);
            map.put("count", obj[1]);
            return map;
        }).collect(Collectors.toList());
    }

    @Override
    public List<Map<String, Object>> getVideoUploadTrend() {
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        List<Map<String, Object>> trend = new ArrayList<>();
        for (int i = 6; i >= 0; i--) {
            LocalDate date = today.minusDays(i);
            long count = videoRepository.countByCreatedTimeBetween(
                date.atStartOfDay(),
                date.plusDays(1).atStartOfDay()
            );
            Map<String, Object> map = new HashMap<>();
            map.put("date", date.format(formatter));
            map.put("count", count);
            trend.add(map);
        }
        return trend;
    }
} 