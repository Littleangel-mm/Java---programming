package com.example.sp.Controller;

import com.example.sp.Service.DashboardService;
import com.example.sp.dto.VideoTypeBarDTO;
import com.example.sp.dto.CommentPieDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/admin/dashboard")
public class DashboardController {
    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/comment-pie")
    public ResponseEntity<List<CommentPieDTO>> getCommentPie() {
        return ResponseEntity.ok(dashboardService.getCommentPieLast7Days());
    }

    @GetMapping("/video-type-bar")
    public ResponseEntity<List<VideoTypeBarDTO>> getVideoTypeBar() {
        return ResponseEntity.ok(dashboardService.getVideoTypeBarLast7Days());
    }
} 