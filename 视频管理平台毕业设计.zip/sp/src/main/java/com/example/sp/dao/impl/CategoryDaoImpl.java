package com.example.sp.dao.impl;

import com.example.sp.Entity.Category;
import com.example.sp.Repository.CategoryRepository;
import com.example.sp.dao.CategoryDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 分类数据访问对象实现类
 */
@Repository
public class CategoryDaoImpl implements CategoryDao {
    
    @Autowired
    private CategoryRepository categoryRepository;
    
    @PersistenceContext
    private EntityManager entityManager;
    
    @Override
    public Optional<Category> findByName(String name) {
        return categoryRepository.findByName(name);
    }
    
    @Override
    public List<Category> findByIsActive(Boolean isActive) {
        return categoryRepository.findByIsActive(isActive);
    }
    
    @Override
    public List<Category> findByParentId(Long parentId) {
        // CategoryRepository没有findByParent，返回空列表
        return new java.util.ArrayList<>();
    }
    
    @Override
    public List<Category> findTopLevelCategories() {
        // 简化实现，返回所有激活的分类
        return categoryRepository.findByIsActive(true);
    }
    
    @Override
    public Page<Category> findCategoriesWithPagination(Pageable pageable) {
        return categoryRepository.findAll(pageable);
    }
    
    @Override
    public Page<Category> searchCategories(String keyword, Boolean isActive, Pageable pageable) {
        if (keyword != null && !keyword.trim().isEmpty()) {
            if (isActive != null) {
                return categoryRepository.searchCategories(keyword, pageable);
            } else {
                return categoryRepository.searchCategories(keyword, pageable);
            }
        } else {
            if (isActive != null) {
                return categoryRepository.findByIsActive(isActive, pageable);
            } else {
                return categoryRepository.findAll(pageable);
            }
        }
    }
    
    @Override
    public List<CategoryTree> getCategoryTree() {
        // 获取所有分类
        List<Category> allCategories = categoryRepository.findAll();
        
        // 构建简化的分类树（所有分类都是顶级分类）
        return allCategories.stream()
            .map(category -> {
                CategoryDao.CategoryTree tree = new CategoryDao.CategoryTree(category);
                tree.setVideoCount(category.getVideos().size());
                return tree;
            })
            .collect(java.util.stream.Collectors.toList());
    }
    
    @Override
    public CategoryStatistics getCategoryStatistics() {
        String sql = "SELECT " +
            "COUNT(*) as totalCategories, " +
            "SUM(CASE WHEN is_active = true THEN 1 ELSE 0 END) as activeCategories, " +
            "SUM(CASE WHEN is_active = false THEN 1 ELSE 0 END) as inactiveCategories, " +
            "SUM(CASE WHEN parent_id IS NULL THEN 1 ELSE 0 END) as topLevelCategories, " +
            "SUM(CASE WHEN parent_id IS NOT NULL THEN 1 ELSE 0 END) as subCategories " +
            "FROM categories";
        
        Query query = entityManager.createNativeQuery(sql);
        Object[] result = (Object[]) query.getSingleResult();
        
        return new CategoryDao.CategoryStatistics(
            ((Number) result[0]).longValue(),
            ((Number) result[1]).longValue(),
            ((Number) result[2]).longValue(),
            ((Number) result[3]).longValue(),
            ((Number) result[4]).longValue()
        );
    }
    
    @Override
    public long getVideoCountByCategory(Long categoryId) {
        String sql = "SELECT COUNT(*) FROM videos WHERE category_id = :categoryId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("categoryId", categoryId);
        return ((Number) query.getSingleResult()).longValue();
    }
    
    @Override
    public long getTotalVideoCountByCategory(Long categoryId) {
        // 递归获取分类及其子分类的视频数量
        String sql = "WITH RECURSIVE category_tree AS (" +
            "SELECT id, parent_id FROM categories WHERE id = :categoryId " +
            "UNION ALL " +
            "SELECT c.id, c.parent_id FROM categories c " +
            "INNER JOIN category_tree ct ON c.parent_id = ct.id" +
            ") " +
            "SELECT COUNT(*) FROM videos WHERE category_id IN (SELECT id FROM category_tree)";
        
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("categoryId", categoryId);
        return ((Number) query.getSingleResult()).longValue();
    }
    
    @Override
    public List<CategoryWithVideoCount> getPopularCategories(int limit) {
        String sql = "SELECT c.id, c.name, COUNT(v.id) as videoCount " +
            "FROM categories c " +
            "LEFT JOIN videos v ON c.id = v.category_id " +
            "WHERE c.is_active = true " +
            "GROUP BY c.id, c.name " +
            "ORDER BY videoCount DESC " +
            "LIMIT :limit";
        
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("limit", limit);
        List<Object[]> results = query.getResultList();
        
        return results.stream()
            .map(row -> new CategoryDao.CategoryWithVideoCount(
                ((Number) row[0]).longValue(),
                (String) row[1],
                ((Number) row[2]).longValue()
            ))
            .collect(java.util.stream.Collectors.toList());
    }
    
    @Override
    public boolean existsByName(String name) {
        return categoryRepository.existsByName(name);
    }
    
    @Override
    public boolean hasChildren(Long categoryId) {
        String sql = "SELECT COUNT(*) FROM categories WHERE parent_id = :categoryId";
        Query query = entityManager.createNativeQuery(sql);
        query.setParameter("categoryId", categoryId);
        return ((Number) query.getSingleResult()).longValue() > 0;
    }
    
    @Override
    public boolean hasVideos(Long categoryId) {
        return getVideoCountByCategory(categoryId) > 0;
    }
} 