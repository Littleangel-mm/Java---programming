<template>
  <div class="video-player-container">
    <!-- 视频播放器 -->
    <video 
      v-if="videoUrl && videoStatus === 'APPROVED'"
      ref="videoRef"
      :src="videoUrl"
      class="video-element"
      controls
      preload="metadata"
      :autoplay="autoPlay"
      :muted="muted || autoPlay"
      @loadstart="onLoadStart"
      @loadedmetadata="onLoadedMetadata"
      @canplay="onCanPlay"
      @play="onPlay"
      @pause="onPause"
      @ended="onEnded"
      @timeupdate="onTimeUpdate"
      @error="onError"
      @seeking="onSeeking"
      @seeked="onSeeked"
    >
      您的浏览器不支持视频播放
    </video>
    
    <!-- 加载状态 -->
    <div v-else-if="loading" class="video-loading">
      <el-icon class="loading-icon" size="48"><Loading /></el-icon>
      <p>视频加载中...</p>
    </div>
    
    <!-- 错误状态 -->
    <div v-else-if="error" class="video-error">
      <el-icon class="error-icon" size="48"><Warning /></el-icon>
      <p>{{ error }}</p>
      <el-button @click="retryLoad" type="primary">重试</el-button>
    </div>
    
    <!-- 未审核状态 -->
    <div v-else-if="videoStatus !== 'APPROVED'" class="video-unapproved">
      <el-icon class="unapproved-icon" size="48"><Lock /></el-icon>
      <p>视频未通过审核，无法播放</p>
    </div>
    
    <!-- 默认状态 -->
    <div v-else class="video-placeholder">
      <el-icon class="placeholder-icon" size="48"><VideoPlay /></el-icon>
      <p>视频播放器</p>
    </div>
    
    <!-- 视频信息显示 -->
    <div v-if="showInfo && videoInfo" class="video-info-overlay">
      <div class="info-content">
        <h3>{{ videoInfo.title }}</h3>
        <p>{{ videoInfo.description }}</p>
        <div class="info-stats">
          <span>时长: {{ formatDuration(videoInfo.duration) }}</span>
          <span>大小: {{ formatFileSize(videoInfo.fileSize) }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import { ElMessage } from 'element-plus'
import { VideoPlay, Loading, Warning, Lock } from '@element-plus/icons-vue'
import { videoApi } from '@/api'

interface VideoInfo {
  videoId: number
  title: string
  description: string
  duration: number
  fileSize: number
  contentType: string
  playUrl: string
  thumbnailUrl: string
}

interface Props {
  videoId?: number
  videoStatus?: string
  showInfo?: boolean
  autoPlay?: boolean
  muted?: boolean
  loop?: boolean
  videoFilePath?: string // 新增
}

const props = withDefaults(defineProps<Props>(), {
  videoStatus: 'PENDING',
  showInfo: false,
  autoPlay: false,
  muted: false,
  loop: false,
  videoFilePath: ''
})

const emit = defineEmits<{
  'load-start': []
  'can-play': []
  'play': []
  'pause': []
  'ended': []
  'time-update': [currentTime: number, duration: number]
  'error': [error: string]
  'seeking': []
  'seeked': []
}>()

// 响应式数据
const videoRef = ref<HTMLVideoElement>()
const loading = ref(false)
const error = ref('')
const videoInfo = ref<VideoInfo | null>(null)
const currentTime = ref(0)
const duration = ref(0)
const isPlaying = ref(false)

// 计算属性
const videoUrl = computed(() => {
  if (props.videoFilePath) {
    // 静态资源直链
    return `/api/${props.videoFilePath}`
  }
  if (props.videoId) {
    // 兼容旧逻辑
    return videoApi.getVideoPlayUrl(props.videoId)
  }
  return ''
})

// 获取视频流信息
const fetchVideoInfo = async () => {
  if (!props.videoId) return
  
  loading.value = true
  error.value = ''
  
  try {
    const response = await videoApi.getVideoStreamInfo(props.videoId)
    videoInfo.value = response
  } catch (err) {
    console.error('获取视频信息失败:', err)
    error.value = '获取视频信息失败'
  } finally {
    loading.value = false
  }
}

// 重试加载
const retryLoad = () => {
  error.value = ''
  fetchVideoInfo()
}

// 视频事件处理
const onLoadStart = () => {
  console.log('视频开始加载')
  emit('load-start')
}

const onLoadedMetadata = () => {
  if (videoRef.value) {
    duration.value = videoRef.value.duration
    console.log('视频元数据加载完成，时长:', duration.value)
  }
}

const onCanPlay = () => {
  console.log('视频可以播放')
  emit('can-play')
}

const onPlay = () => {
  isPlaying.value = true
  emit('play')
}

const onPause = () => {
  isPlaying.value = false
  emit('pause')
}

const onEnded = () => {
  isPlaying.value = false
  emit('ended')
}

const onTimeUpdate = () => {
  if (videoRef.value) {
    currentTime.value = videoRef.value.currentTime
    emit('time-update', currentTime.value, duration.value)
  }
}

const onError = (event: Event) => {
  console.error('视频播放错误:', event)
  error.value = '视频播放失败，请检查视频文件'
  emit('error', error.value)
}

const onSeeking = () => {
  emit('seeking')
}

const onSeeked = () => {
  emit('seeked')
}

// 格式化时长
const formatDuration = (seconds: number) => {
  if (!seconds) return '00:00'
  const minutes = Math.floor(seconds / 60)
  const remainingSeconds = Math.floor(seconds % 60)
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`
}

// 格式化文件大小
const formatFileSize = (bytes: number) => {
  if (!bytes) return '0 B'
  const mb = bytes / (1024 * 1024)
  return `${mb.toFixed(2)} MB`
}

// 暴露方法给父组件
const play = () => {
  if (videoRef.value) {
    videoRef.value.play()
  }
}

const pause = () => {
  if (videoRef.value) {
    videoRef.value.pause()
  }
}

const seek = (time: number) => {
  if (videoRef.value) {
    videoRef.value.currentTime = time
  }
}

const setVolume = (volume: number) => {
  if (videoRef.value) {
    videoRef.value.volume = Math.max(0, Math.min(1, volume))
  }
}

// 暴露方法
defineExpose({
  play,
  pause,
  seek,
  setVolume,
  currentTime: computed(() => currentTime.value),
  duration: computed(() => duration.value),
  isPlaying: computed(() => isPlaying.value)
})

// 监听视频ID变化
watch(() => props.videoId, (newId) => {
  if (newId) {
    fetchVideoInfo()
  }
})

// 生命周期
onMounted(async () => {
  const { data: catData } = await adminApi.getVideoCategoryStats()
  categoryStats.value = catData
  pieOption.value = {
    tooltip: { trigger: 'item' },
    legend: { top: '5%', left: 'center' },
    series: [{
      name: '视频分类',
      type: 'pie',
      radius: '60%',
      data: catData.map(item => ({ name: item.category, value: item.count })),
      label: { formatter: '{b}: {d}%' }
    }]
  }

  const { data: trendData } = await adminApi.getVideoUploadTrend()
  uploadTrend.value = trendData
  barOption.value = {
    tooltip: { trigger: 'axis' },
    grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
    xAxis: { type: 'category', data: trendData.map(item => item.date) },
    yAxis: { type: 'value' },
    series: [{
      name: '上传数量',
      type: 'bar',
      data: trendData.map(item => item.count),
      barWidth: '50%',
      itemStyle: { color: '#409EFF' }
    }]
  }
})

onUnmounted(() => {
  // 清理资源
  if (videoRef.value) {
    videoRef.value.pause()
    videoRef.value.src = ''
  }
})
</script>

<style scoped>
.video-player-container {
  position: relative;
  width: 100%;
  height: 100%;
  background: #000;
  border-radius: 8px;
  overflow: hidden;
}

.video-element {
  width: 100%;
  height: 100%;
  object-fit: contain;
  background: #000;
}

.video-loading,
.video-error,
.video-unapproved,
.video-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: #fff;
  text-align: center;
}

.loading-icon {
  animation: spin 1s linear infinite;
  color: #409eff;
}

.error-icon {
  color: #f56c6c;
}

.unapproved-icon {
  color: #e6a23c;
}

.placeholder-icon {
  color: #909399;
}

.video-loading p,
.video-error p,
.video-unapproved p,
.video-placeholder p {
  margin: 16px 0 0 0;
  font-size: 14px;
}

.video-info-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.3s;
}

.video-player-container:hover .video-info-overlay {
  opacity: 1;
}

.info-content {
  color: white;
  text-align: center;
  padding: 20px;
}

.info-content h3 {
  margin: 0 0 12px 0;
  font-size: 18px;
}

.info-content p {
  margin: 0 0 16px 0;
  font-size: 14px;
  line-height: 1.5;
}

.info-stats {
  display: flex;
  justify-content: center;
  gap: 20px;
  font-size: 12px;
  color: #ccc;
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style> 