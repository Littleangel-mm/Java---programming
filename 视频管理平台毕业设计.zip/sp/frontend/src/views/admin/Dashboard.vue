<template>
  <div class="dashboard">
    <div class="dashboard-header">
      <h2>仪表板</h2>
      <p>欢迎回来，{{ userStore.user?.nickname || userStore.user?.username }}</p>
    </div>
    
    <!-- 统计卡片 -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon users">
          <el-icon><User /></el-icon>
        </div>
        <div class="stat-content">
          <div class="stat-number">{{ stats.totalUsers }}</div>
          <div class="stat-label">总用户数</div>
          <div class="stat-change">
            <span class="change-text">今日新增: {{ stats.todayNewUsers }}</span>
          </div>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon videos">
          <el-icon><VideoPlay /></el-icon>
        </div>
        <div class="stat-content">
          <div class="stat-number">{{ stats.totalVideos }}</div>
          <div class="stat-label">总视频数</div>
          <div class="stat-change">
            <span class="change-text">今日新增: {{ stats.todayNewVideos }}</span>
          </div>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon views">
          <el-icon><View /></el-icon>
        </div>
        <div class="stat-content">
          <div class="stat-number">{{ formatNumber(stats.totalViews) }}</div>
          <div class="stat-label">总观看次数</div>
          <div class="stat-change">
            <span class="change-text">今日观看: {{ formatNumber(stats.todayViews) }}</span>
          </div>
        </div>
      </div>
      
      <div class="stat-card">
        <div class="stat-icon comments">
          <el-icon><ChatDotRound /></el-icon>
        </div>
        <div class="stat-content">
          <div class="stat-number">{{ stats.totalComments }}</div>
          <div class="stat-label">总评论数</div>
          <div class="stat-change">
            <span class="change-text">今日新增: {{ stats.todayComments }}</span>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 待处理事项 -->
    <div class="pending-section">
      <h3>待处理事项</h3>
      <div class="pending-grid">
        <div class="pending-card">
          <div class="pending-header">
            <el-icon><VideoPlay /></el-icon>
            <span>待审核视频</span>
          </div>
          <div class="pending-number">{{ stats.pendingVideos }}</div>
          <el-button type="primary" size="small" @click="$router.push('/admin/videos')">
            去处理
          </el-button>
        </div>
        
        <div class="pending-card">
          <div class="pending-header">
            <el-icon><ChatDotRound /></el-icon>
            <span>待审核评论</span>
          </div>
          <div class="pending-number">{{ stats.pendingComments }}</div>
          <el-button type="primary" size="small" @click="$router.push('/admin/comments')">
            去处理
          </el-button>
        </div>
        
        <div class="pending-card">
          <div class="pending-header">
            <el-icon><Warning /></el-icon>
            <span>举报内容</span>
          </div>
          <div class="pending-number">{{ stats.reportedContent }}</div>
          <el-button type="danger" size="small">
            查看详情
          </el-button>
        </div>
      </div>
    </div>
    
    <!-- 系统信息 -->
    <div class="system-section">
      <h3>系统信息</h3>
      <div class="system-grid">
        <div class="system-card">
          <div class="system-item">
            <span class="label">运行时间:</span>
            <span class="value">{{ systemInfo.uptime }}</span>
          </div>
          <div class="system-item">
            <span class="label">在线用户:</span>
            <span class="value">{{ systemInfo.onlineUsers }}</span>
          </div>
        </div>
        <div class="system-card">
          <div class="system-item">
            <span class="label">CPU使用率:</span>
            <span class="value">{{ systemInfo.cpuUsage }}%</span>
          </div>
          <div class="system-item">
            <span class="label">内存使用率:</span>
            <span class="value">{{ systemInfo.memoryUsage }}%</span>
          </div>
        </div>
        <div class="system-card">
          <div class="system-item">
            <span class="label">磁盘使用率:</span>
            <span class="value">{{ systemInfo.diskUsage }}%</span>
          </div>
        </div>
      </div>
    </div>
    <!-- 可视化统计 -->
    <div class="visual-section-flex" style="display: flex; gap: 24px; margin-bottom: 30px;">
      <div id="comment-pie" style="flex:1; height: 360px; background: #fff; border-radius: 12px;"></div>
      <div id="video-type-bar" style="flex:1; height: 360px; background: #fff; border-radius: 12px;"></div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick } from 'vue'
import * as echarts from 'echarts'
import { useUserStore } from '@/stores/user'
import { adminApi } from '@/api'
import type { DashboardStats, SystemInfo } from '@/types'
import { ElMessage } from 'element-plus'

const userStore = useUserStore()

// 仪表盘统计数据
const stats = ref<DashboardStats>({
  totalUsers: 0,
  totalVideos: 0,
  totalViews: 0,
  totalComments: 0,
  todayNewUsers: 0,
  todayNewVideos: 0,
  todayViews: 0,
  todayComments: 0,
  pendingVideos: 0,
  pendingComments: 0,
  reportedContent: 0
})

const systemInfo = ref<SystemInfo>({
  uptime: '',
  cpuUsage: 0,
  memoryUsage: 0,
  diskUsage: 0,
  onlineUsers: 0
})

const commentPieData = ref<any[]>([])
const videoTypeBarData = ref<any[]>([])

const fetchCommentPie = async () => {
  try {
    commentPieData.value = await adminApi.getCommentPie()
    nextTick(() => renderCommentPie())
  } catch (e) {
    console.error('获取评论分布失败', e)
  }
}
const fetchVideoTypeBar = async () => {
  try {
    videoTypeBarData.value = await adminApi.getVideoTypeBar()
    nextTick(() => renderVideoTypeBar())
  } catch (e) {
    console.error('获取视频类型分布失败', e)
  }
}

const renderCommentPie = () => {
  const chartDom = document.getElementById('comment-pie')
  if (!chartDom) return
  const chart = echarts.init(chartDom)
  chart.setOption({
    title: { text: '七天内评论分布', left: 'center' },
    tooltip: { trigger: 'item' },
    series: [{
      name: '评论数',
      type: 'pie',
      radius: '60%',
      data: commentPieData.value.map(item => ({
        name: item.videoTitle,
        value: item.commentCount
      })),
      emphasis: { itemStyle: { shadowBlur: 10, shadowOffsetX: 0, shadowColor: 'rgba(0,0,0,0.5)' } }
    }]
  })
}

const renderVideoTypeBar = () => {
  const chartDom = document.getElementById('video-type-bar')
  if (!chartDom) return
  const chart = echarts.init(chartDom)
  chart.setOption({
    title: { text: '七天内视频类型上传分布', left: 'center' },
    tooltip: { trigger: 'axis' },
    xAxis: { type: 'category', data: videoTypeBarData.value.map(item => item.type) },
    yAxis: { type: 'value' },
    series: [{
      name: '上传数量',
      type: 'bar',
      data: videoTypeBarData.value.map(item => item.uploadCount)
    }]
  })
}

// 获取仪表盘统计数据
const fetchDashboardStats = async () => {
  try {
    const response = await adminApi.getDashboardStats()
    stats.value = response
  } catch (error) {
    console.error('获取仪表板统计失败:', error)
    ElMessage.error('获取统计数据失败')
  }
}

// 获取系统信息
const fetchSystemInfo = async () => {
  try {
    const response = await adminApi.getSystemInfo()
    systemInfo.value = response
  } catch (error) {
    console.error('获取系统信息失败:', error)
    ElMessage.error('获取系统信息失败')
  }
}

onMounted(() => {
  fetchDashboardStats()
  fetchSystemInfo()
  fetchCommentPie()
  fetchVideoTypeBar()
  // 移除 ECharts 相关变量和方法
  setInterval(() => {
    fetchDashboardStats()
    fetchSystemInfo()
    // 移除 ECharts 相关变量和方法
  }, 30000)
})

// 格式化数字
const formatNumber = (num: number) => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M'
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K'
  }
  return num.toString()
}
</script>

<style scoped>
.dashboard {
  max-width: 1200px;
  margin: 0 auto;
}

.dashboard-header {
  margin-bottom: 30px;
}

.dashboard-header h2 {
  margin: 0 0 8px 0;
  font-size: 28px;
  color: #333;
}

.dashboard-header p {
  margin: 0;
  color: #666;
  font-size: 16px;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  margin-bottom: 30px;
}

.stat-card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: center;
  transition: transform 0.3s, box-shadow 0.3s;
}

.stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
}

.stat-icon {
  width: 60px;
  height: 60px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
  font-size: 24px;
  color: white;
}

.stat-icon.users {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.stat-icon.videos {
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
}

.stat-icon.views {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}

.stat-icon.comments {
  background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
}

.stat-content {
  flex: 1;
}

.stat-number {
  font-size: 32px;
  font-weight: 700;
  color: #333;
  margin-bottom: 4px;
}

.stat-label {
  font-size: 14px;
  color: #666;
  margin-bottom: 8px;
}

.stat-change {
  font-size: 12px;
}

.change-text {
  color: #409eff;
}

.pending-section,
.system-section {
  margin-bottom: 30px;
}

.pending-section h3,
.system-section h3 {
  margin: 0 0 20px 0;
  font-size: 20px;
  color: #333;
}

.pending-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
}

.pending-card {
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.pending-header {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 12px;
  color: #666;
  font-size: 14px;
}

.pending-header .el-icon {
  margin-right: 8px;
  font-size: 16px;
}

.pending-number {
  font-size: 32px;
  font-weight: 700;
  color: #333;
  margin-bottom: 16px;
}

.system-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
}

.system-card {
  background: white;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.system-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
  border-bottom: 1px solid #f0f0f0;
}

.system-item:last-child {
  border-bottom: none;
}

.system-item .label {
  color: #666;
  font-size: 14px;
}

.system-item .value {
  color: #333;
  font-weight: 500;
  font-size: 14px;
}

/* 移除 .visual-section-flex 和 .chart-card 样式 */
</style> 