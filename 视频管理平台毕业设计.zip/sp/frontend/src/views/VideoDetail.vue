<template>
  <div class="yt-video-detail-root">
    <div class="yt-main-content">
      <div class="yt-video-player-block">
        <video
          class="yt-video-element"
          :src="getVideoUrl(video)"
          controls
          autoplay
          muted
          preload="metadata"
        >
          您的浏览器不支持视频播放
        </video>
      </div>
      <h1 class="yt-video-title">{{ video?.title }}</h1>
      <div class="yt-video-meta-row">
        <div class="yt-video-stats">
          <span>{{ video?.viewCount }} 次观看</span>
          <span>{{ formatTime(video?.createdTime) }}</span>
        </div>
        <div class="yt-video-actions">
          <el-button @click="handleLike" :type="isLiked ? 'danger' : 'default'" :disabled="!userStore.user" circle>
            <el-icon><Promotion /></el-icon>
          </el-button>
          <span class="yt-action-label">{{ video?.likeCount }}</span>
          <el-button @click="handleFavorite" :type="isFavorited ? 'warning' : 'default'" :disabled="!userStore.user" circle>
            <el-icon><Star /></el-icon>
          </el-button>
          <span class="yt-action-label">{{ isFavorited ? '已收藏' : '收藏' }}</span>
          <el-button @click="handleShare" circle>
            <el-icon><Share /></el-icon>
          </el-button>
          <span class="yt-action-label">分享</span>
        </div>
      </div>
      <el-divider />
      <div class="yt-author-row">
        <el-avatar :src="video?.user.avatar" :size="48">
          {{ video?.user.nickname?.[0] || video?.user.username?.[0] || '' }}
        </el-avatar>
        <div class="yt-author-info">
          <div class="yt-author-name">{{ video?.user.nickname || video?.user.username }}</div>
          <div class="yt-author-bio">{{ video?.user.bio || '这个用户很懒，没有留下任何介绍' }}</div>
        </div>
        <el-button class="yt-subscribe-btn" type="primary" plain disabled>订阅</el-button>
      </div>
      <div class="yt-video-description">
        <el-collapse>
          <el-collapse-item title="视频简介" name="desc">
            <div>{{ video?.description || '暂无描述' }}</div>
          </el-collapse-item>
        </el-collapse>
      </div>
      <el-divider />
      <div class="yt-comments-section">
        <h3 class="yt-comments-title">评论 ({{ commentTotal }})</h3>
        <div class="yt-comment-form">
          <el-input
            v-model="commentContent"
            type="textarea"
            :rows="3"
            placeholder="发表评论..."
            maxlength="500"
            show-word-limit
          />
          <el-button type="primary" @click="handleComment" :loading="commenting" :disabled="!userStore.user">
            发表评论
          </el-button>
        </div>
        <div class="yt-comments-list" v-loading="commentsLoading">
          <div v-if="comments.length === 0" class="yt-no-comments">
            <el-empty description="暂无评论" />
          </div>
          <div v-else class="yt-comment-item" v-for="comment in comments" :key="comment.id">
            <el-avatar :src="comment.user?.avatar" :size="40">
              {{ comment.user?.nickname?.[0] || comment.user?.username?.[0] || '' }}
            </el-avatar>
            <div class="yt-comment-content">
              <div class="yt-comment-header">
                <span class="yt-comment-author">{{ comment.user?.nickname || comment.user?.username }}</span>
                <span class="yt-comment-time">{{ formatTime(comment.createdTime) }}</span>
              </div>
              <div class="yt-comment-text">{{ comment.content }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="yt-side-content">
      <div class="yt-related-videos">
        <h3 class="yt-related-title">相关视频</h3>
        <div class="yt-related-list">
          <div
            v-for="relatedVideo in relatedVideos"
            :key="relatedVideo.id"
            class="yt-related-card"
            @click="goToVideo(relatedVideo.id)"
          >
            <div class="yt-related-thumb-wrap">
              <img :src="getVideoThumbnail(relatedVideo)" :alt="relatedVideo.title" class="yt-related-thumb">
              <div class="yt-related-duration">{{ formatDuration(relatedVideo.duration) }}</div>
            </div>
            <div class="yt-related-info">
              <div class="yt-related-title-main">{{ relatedVideo.title }}</div>
              <div class="yt-related-author">{{ relatedVideo.user?.nickname || relatedVideo.user?.username || '' }}</div>
              <div class="yt-related-stats">{{ relatedVideo.viewCount }} 次观看</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { videoApi, commentApi } from '@/api'
import { useUserStore } from '@/stores/user'
import type { Video, Comment } from '@/types'
import { ElMessage } from 'element-plus'
import { Promotion, Star, Share } from '@element-plus/icons-vue'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const video = ref<Video | null>(null)
const comments = ref<Comment[]>([])
const commentTotal = ref(0)
const relatedVideos = ref<Video[]>([])
const commentContent = ref('')
const commenting = ref(false)
const commentsLoading = ref(false)
const isLiked = ref(false)
const isFavorited = ref(false)

const fetchVideoDetail = async () => {
  const videoId = parseInt(route.params.id as string)
  try {
    const response = await videoApi.getVideoById(videoId)
    video.value = response
    await fetchComments() // 确保video加载后再加载评论
    fetchRelatedVideos(videoId)
    if (userStore.user) {
      refreshLikeFavoriteStatus()
    }
  } catch (error) {
    video.value = null
    comments.value = []
    commentTotal.value = 0
  }
}

const fetchComments = async () => {
  if (!video.value) return
  commentsLoading.value = true
  try {
    let page = 0
    let allComments: any[] = []
    let hasMore = true
    let totalElements = 0
    while (hasMore) {
      const response = await commentApi.getCommentList(page, 50)
      const pageComments = response.content || response
      allComments = allComments.concat(pageComments)
      totalElements = response.totalElements || 0
      hasMore = pageComments.length > 0 && allComments.length < totalElements
      page++
    }
    // 只按视频id过滤，不再按状态过滤
    comments.value = allComments.filter((c: any) => c.video?.id === video.value.id)
    commentTotal.value = comments.value.length
  } catch (error) {
    comments.value = []
    commentTotal.value = 0
  } finally {
    commentsLoading.value = false
  }
}

const fetchRelatedVideos = async (videoId: number) => {
  try {
    const response = await videoApi.getSimilarVideos(videoId, 0, 12)
    relatedVideos.value = response
  } catch (error) {
    relatedVideos.value = []
  }
}

const refreshLikeFavoriteStatus = async () => {
  if (!video.value || !userStore.user) return
  try {
    const [likedResponse, favoritedResponse] = await Promise.all([
      videoApi.isLikedByUser(video.value.id, userStore.user.id),
      videoApi.isFavoritedByUser(video.value.id, userStore.user.id)
    ])
    isLiked.value = likedResponse.isLiked // 正确解析后端返回
    isFavorited.value = favoritedResponse.isFavorited // 正确解析后端返回
  } catch (error) {
    isLiked.value = false
    isFavorited.value = false
  }
}

const checkUserActions = refreshLikeFavoriteStatus // 复用

const refreshVideoDetail = async () => {
  if (!video.value) return
  try {
    const response = await videoApi.getVideoById(video.value.id)
    video.value = response
  } catch (error) {
    // 可选：处理异常
  }
}

const handleLike = async () => {
  if (!userStore.user || !video.value) return
  try {
    if (isLiked.value) {
      await videoApi.unlikeVideo(video.value.id, userStore.user.id)
      ElMessage.success('取消点赞')
    } else {
      await videoApi.likeVideo(video.value.id, userStore.user.id)
      ElMessage.success('点赞成功')
    }
    await refreshLikeFavoriteStatus()
    await refreshVideoDetail() // 新增：刷新视频详情
  } catch (error) {
    ElMessage.error('操作失败')
  }
}

const handleFavorite = async () => {
  if (!userStore.user || !video.value) return
  try {
    if (isFavorited.value) {
      await videoApi.unfavoriteVideo(video.value.id, userStore.user.id)
      ElMessage.success('取消收藏')
    } else {
      await videoApi.favoriteVideo(video.value.id, userStore.user.id)
      ElMessage.success('收藏成功')
    }
    await refreshLikeFavoriteStatus()
    await refreshVideoDetail() // 新增：刷新视频详情
  } catch (error) {
    ElMessage.error('操作失败')
  }
}

const handleShare = () => {
  if (!video.value) return
  const shareUrl = `${window.location.origin}/video/${video.value.id}`
  navigator.clipboard.writeText(shareUrl).then(() => {
    ElMessage.success('链接已复制到剪贴板')
  }).catch(() => {
    ElMessage.error('复制失败')
  })
}

const handleComment = async () => {
  if (!userStore.user || !video.value || !commentContent.value.trim()) return
  commenting.value = true
  try {
    await commentApi.addComment({
      content: commentContent.value,
      userId: userStore.user.id,
      videoId: video.value.id
    })
    ElMessage.success('评论发表成功')
    commentContent.value = ''
    fetchComments()
  } catch (error) {
    ElMessage.error('发表评论失败')
  } finally {
    commenting.value = false
  }
}

const goToVideo = (videoId: number) => {
  router.push(`/video/${videoId}`)
}

const getVideoUrl = (video: Video | null) => {
  return video && video.filePath ? `/api/${video.filePath}` : ''
}

const getVideoThumbnail = (video: Video) => {
  if (video.thumbnailUrl) {
    if (video.thumbnailUrl.startsWith('http')) {
      return video.thumbnailUrl
    }
    // 如果是相对路径，拼接API地址
    return `/api/files/${video.thumbnailUrl.replace('/api/files/', '')}`
  }
  return '/default-thumbnail.jpg'
}

const formatTime = (timeStr: string) => {
  const date = new Date(timeStr)
  return date.toLocaleString()
}

const formatDuration = (duration?: number) => {
  if (!duration) return '00:00'
  const minutes = Math.floor(duration / 60)
  const seconds = duration % 60
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
}

// 评论状态tag辅助方法
const getStatusType = (status: string) => {
  const types: Record<string, string> = {
    PENDING: 'warning',
    ACTIVE: 'success',
    REJECTED: 'danger',
    HIDDEN: 'info',
    DELETED: 'info'
  }
  return types[status] || 'info'
}
const getStatusText = (status: string) => {
  const texts: Record<string, string> = {
    PENDING: '待审核',
    ACTIVE: '已通过',
    REJECTED: '已拒绝',
    HIDDEN: '隐藏',
    DELETED: '已删除'
  }
  return texts[status] || status
}

onMounted(() => {
  fetchVideoDetail()
})

watch(() => route.params.id, async (newId, oldId) => {
  if (newId !== oldId) {
    await fetchVideoDetail()
  }
})
</script>

<style scoped>
.yt-video-detail-root {
  display: flex;
  flex-direction: row;
  gap: 32px;
  max-width: 1400px;
  margin: 32px auto;
  padding: 0 16px;
}
.yt-main-content {
  flex: 1 1 0;
  min-width: 0;
}
.yt-side-content {
  width: 370px;
  min-width: 320px;
}
.yt-video-player-block {
  background: #000;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  margin-bottom: 18px;
  display: flex;
  justify-content: center;
  align-items: center;
}
.yt-video-element {
  width: 100%;
  max-width: 900px;
  height: 500px;
  border-radius: 12px;
  background: #000;
}
.yt-video-title {
  font-size: 26px;
  font-weight: 600;
  margin: 8px 0 12px 0;
  color: #222;
  line-height: 1.3;
}
.yt-video-meta-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  gap: 16px;
}
.yt-video-stats {
  color: #888;
  font-size: 15px;
  display: flex;
  gap: 18px;
}
.yt-video-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}
.yt-video-actions .el-button {
  font-size: 18px;
  padding: 0 10px;
}
.yt-action-label {
  margin-right: 12px;
  color: #666;
  font-size: 15px;
  min-width: 40px;
  display: inline-block;
  text-align: center;
}
.yt-author-row {
  display: flex;
  align-items: center;
  gap: 18px;
  margin: 18px 0 8px 0;
}
.yt-author-info {
  flex: 1;
  min-width: 0;
}
.yt-author-name {
  font-size: 17px;
  font-weight: 500;
  color: #222;
}
.yt-author-bio {
  font-size: 14px;
  color: #888;
  margin-top: 2px;
}
.yt-subscribe-btn {
  font-weight: 600;
  letter-spacing: 1px;
}
.yt-video-description {
  margin: 18px 0 0 0;
}
.yt-comments-section {
  background: #fafbfc;
  border-radius: 8px;
  padding: 20px;
  margin: 32px 0;
}
.yt-comments-title {
  margin: 0 0 20px 0;
  font-size: 18px;
  color: #333;
}
.yt-comment-form {
  margin-bottom: 30px;
}
.yt-comment-form .el-button {
  margin-top: 12px;
}
.yt-comments-list {
  margin-top: 10px;
}
.yt-comment-item {
  display: flex;
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid #eee;
}
.yt-comment-item:last-child {
  border-bottom: none;
}
.yt-comment-content {
  flex: 1;
  margin-left: 12px;
}
.yt-comment-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}
.yt-comment-author {
  font-weight: 500;
  color: #333;
}
.yt-comment-time {
  font-size: 12px;
  color: #999;
}
.yt-comment-text {
  color: #333;
  line-height: 1.5;
  margin-bottom: 8px;
}
.yt-no-comments {
  text-align: center;
  padding: 40px 0;
}
.yt-related-videos {
  background: #fff;
  border-radius: 8px;
  padding: 18px 12px 12px 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}
.yt-related-title {
  font-size: 17px;
  font-weight: 500;
  margin-bottom: 12px;
  color: #222;
}
.yt-related-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.yt-related-card {
  display: flex;
  gap: 12px;
  cursor: pointer;
  border-radius: 8px;
  transition: box-shadow 0.2s, transform 0.2s;
  background: #f7f7f7;
  padding: 6px 6px 6px 0;
  align-items: flex-start;
}
.yt-related-card:hover {
  box-shadow: 0 4px 16px rgba(0,0,0,0.10);
  transform: translateY(-2px) scale(1.02);
}
.yt-related-thumb-wrap {
  position: relative;
  width: 120px;
  height: 70px;
  border-radius: 6px;
  overflow: hidden;
  flex-shrink: 0;
}
.yt-related-thumb {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 6px;
}
.yt-related-duration {
  position: absolute;
  bottom: 4px;
  right: 6px;
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 1px 6px;
  border-radius: 4px;
  font-size: 12px;
}
.yt-related-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.yt-related-title-main {
  font-size: 15px;
  font-weight: 500;
  color: #222;
  line-height: 1.3;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
.yt-related-author {
  font-size: 13px;
  color: #666;
}
.yt-related-stats {
  font-size: 12px;
  color: #999;
}
</style> 