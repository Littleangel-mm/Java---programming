import { userApi, videoApi, commentApi, categoryApi, adminApi } from '@/api'
import type { PageResponse, Video } from '@/types'

// API接口测试工具
export class ApiTester {
  private static instance: ApiTester
  private testResults: Array<{ name: string; success: boolean; error?: string }> = []

  static getInstance(): ApiTester {
    if (!ApiTester.instance) {
      ApiTester.instance = new ApiTester()
    }
    return ApiTester.instance
  }

  // 测试用户相关接口
  async testUserApis() {
    console.log('🧪 测试用户相关接口...')
    
    try {
      // 测试获取用户统计
      const stats = await userApi.getUserStats()
      console.log('✅ 用户统计接口正常:', stats)
      this.testResults.push({ name: '用户统计接口', success: true })
    } catch (error) {
      console.error('❌ 用户统计接口失败:', error)
      this.testResults.push({ name: '用户统计接口', success: false, error: String(error) })
    }

    try {
      // 测试获取活跃分类
      const categories = await categoryApi.getActiveCategories()
      console.log('✅ 活跃分类接口正常:', categories)
      this.testResults.push({ name: '活跃分类接口', success: true })
    } catch (error) {
      console.error('❌ 活跃分类接口失败:', error)
      this.testResults.push({ name: '活跃分类接口', success: false, error: String(error) })
    }

    try {
      // 测试获取视频统计
      const videoStats = await videoApi.getVideoStats()
      console.log('✅ 视频统计接口正常:', videoStats)
      this.testResults.push({ name: '视频统计接口', success: true })
    } catch (error) {
      console.error('❌ 视频统计接口失败:', error)
      this.testResults.push({ name: '视频统计接口', success: false, error: String(error) })
    }

    try {
      // 测试管理员仪表板统计
      const dashboardStats = await adminApi.getDashboardStats()
      console.log('✅ 管理员仪表板接口正常:', dashboardStats)
      this.testResults.push({ name: '管理员仪表板接口', success: true })
    } catch (error) {
      console.error('❌ 管理员仪表板接口失败:', error)
      this.testResults.push({ name: '管理员仪表板接口', success: false, error: String(error) })
    }

    try {
      // 测试系统信息接口
      const systemInfo = await adminApi.getSystemInfo()
      console.log('✅ 系统信息接口正常:', systemInfo)
      this.testResults.push({ name: '系统信息接口', success: true })
    } catch (error) {
      console.error('❌ 系统信息接口失败:', error)
      this.testResults.push({ name: '系统信息接口', success: false, error: String(error) })
    }
  }

  // 测试视频相关接口
  async testVideoApis() {
    console.log('🧪 测试视频相关接口...')
    
    try {
      // 测试获取视频列表
      const videosPage: PageResponse<Video> = await videoApi.getAllVideos(0, 10)
      const videos = videosPage.content
      console.log('✅ 视频列表接口正常:', videos)
      this.testResults.push({ name: '视频列表接口', success: true })

      // 批量测试视频播放接口（前10个视频）
      for (const video of videos) {
        try {
          const playUrl = videoApi.getVideoPlayUrl(video.id)
          const response = await fetch(playUrl, { method: 'HEAD' })
          if (response.ok || response.status === 206) {
            console.log(`✅ 视频播放接口正常: [${video.id}]`, playUrl, response.status)
            this.testResults.push({ name: `视频播放接口 [ID:${video.id}]`, success: true })
          } else {
            console.error(`❌ 视频播放接口失败: [${video.id}]`, playUrl, response.status)
            this.testResults.push({ name: `视频播放接口 [ID:${video.id}]`, success: false, error: `状态码: ${response.status}` })
          }
        } catch (error) {
          console.error(`❌ 视频播放接口异常: [${video.id}]`, error)
          this.testResults.push({ name: `视频播放接口 [ID:${video.id}]`, success: false, error: String(error) })
        }
      }
    } catch (error) {
      console.error('❌ 视频列表接口失败:', error)
      this.testResults.push({ name: '视频列表接口', success: false, error: String(error) })
    }

    try {
      // 测试获取热门视频
      const popularVideos = await videoApi.getPopularVideos(0, 5)
      console.log('✅ 热门视频接口正常:', popularVideos)
      this.testResults.push({ name: '热门视频接口', success: true })
    } catch (error) {
      console.error('❌ 热门视频接口失败:', error)
      this.testResults.push({ name: '热门视频接口', success: false, error: String(error) })
    }

    try {
      // 测试获取最新视频
      const latestVideos = await videoApi.getLatestVideos(0, 5)
      console.log('✅ 最新视频接口正常:', latestVideos)
      this.testResults.push({ name: '最新视频接口', success: true })
    } catch (error) {
      console.error('❌ 最新视频接口失败:', error)
      this.testResults.push({ name: '最新视频接口', success: false, error: String(error) })
    }

    try {
      // 测试获取待审核视频
      const pendingVideos = await videoApi.getPendingVideos(0, 5)
      console.log('✅ 待审核视频接口正常:', pendingVideos)
      this.testResults.push({ name: '待审核视频接口', success: true })
    } catch (error) {
      console.error('❌ 待审核视频接口失败:', error)
      this.testResults.push({ name: '待审核视频接口', success: false, error: String(error) })
    }
  }

  // 测试评论相关接口
  async testCommentApis() {
    console.log('🧪 测试评论相关接口...')
    
    try {
      // 测试获取评论列表
      const comments = await commentApi.getAllComments(0, 5)
      console.log('✅ 评论列表接口正常:', comments)
      this.testResults.push({ name: '评论列表接口', success: true })
    } catch (error) {
      console.error('❌ 评论列表接口失败:', error)
      this.testResults.push({ name: '评论列表接口', success: false, error: String(error) })
    }

    try {
      // 测试获取待审核评论
      const pendingComments = await commentApi.getPendingComments(0, 5)
      console.log('✅ 待审核评论接口正常:', pendingComments)
      this.testResults.push({ name: '待审核评论接口', success: true })
    } catch (error) {
      console.error('❌ 待审核评论接口失败:', error)
      this.testResults.push({ name: '待审核评论接口', success: false, error: String(error) })
    }

    try {
      // 测试获取评论统计
      const commentStats = await commentApi.getCommentStats()
      console.log('✅ 评论统计接口正常:', commentStats)
      this.testResults.push({ name: '评论统计接口', success: true })
    } catch (error) {
      console.error('❌ 评论统计接口失败:', error)
      this.testResults.push({ name: '评论统计接口', success: false, error: String(error) })
    }
  }

  // 测试分类相关接口
  async testCategoryApis() {
    console.log('🧪 测试分类相关接口...')
    
    try {
      // 测试获取分类列表
      const categories = await categoryApi.getAllCategories(0, 5)
      console.log('✅ 分类列表接口正常:', categories)
      this.testResults.push({ name: '分类列表接口', success: true })
    } catch (error) {
      console.error('❌ 分类列表接口失败:', error)
      this.testResults.push({ name: '分类列表接口', success: false, error: String(error) })
    }

    try {
      // 测试获取分类树
      const categoryTree = await categoryApi.getCategoryTree()
      console.log('✅ 分类树接口正常:', categoryTree)
      this.testResults.push({ name: '分类树接口', success: true })
    } catch (error) {
      console.error('❌ 分类树接口失败:', error)
      this.testResults.push({ name: '分类树接口', success: false, error: String(error) })
    }

    try {
      // 测试获取分类统计
      const categoryStats = await categoryApi.getCategoryStats()
      console.log('✅ 分类统计接口正常:', categoryStats)
      this.testResults.push({ name: '分类统计接口', success: true })
    } catch (error) {
      console.error('❌ 分类统计接口失败:', error)
      this.testResults.push({ name: '分类统计接口', success: false, error: String(error) })
    }
  }

  // 运行所有测试
  async runAllTests() {
    console.log('🚀 开始API接口测试...')
    this.testResults = []
    
    await this.testUserApis()
    await this.testVideoApis()
    await this.testCommentApis()
    await this.testCategoryApis()
    
    this.printResults()
  }

  // 打印测试结果
  printResults() {
    console.log('\n📊 API接口测试结果:')
    console.log('='.repeat(50))
    
    const successCount = this.testResults.filter(r => r.success).length
    const totalCount = this.testResults.length
    
    this.testResults.forEach(result => {
      const status = result.success ? '✅' : '❌'
      console.log(`${status} ${result.name}`)
      if (!result.success && result.error) {
        console.log(`   错误: ${result.error}`)
      }
    })
    
    console.log('='.repeat(50))
    console.log(`总计: ${successCount}/${totalCount} 个接口正常`)
    
    if (successCount === totalCount) {
      console.log('🎉 所有API接口测试通过！')
    } else {
      console.log('⚠️  部分API接口存在问题，请检查后端服务')
    }
  }

  // 获取测试结果
  getResults() {
    return this.testResults
  }
}

// 导出测试实例
export const apiTester = ApiTester.getInstance() 