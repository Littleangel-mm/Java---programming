import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { User, LoginResponse } from '@/types'
import { userApi } from '@/api'
import { ElMessage } from 'element-plus'

export const useUserStore = defineStore('user', () => {
  // 状态
  const user = ref<User | null>(null)
  const token = ref<string | null>(null)
  const isLoggedIn = computed(() => !!token.value && !!user.value)

  // 初始化 - 从localStorage恢复状态
  const init = () => {
    const savedToken = localStorage.getItem('token')
    const savedUser = localStorage.getItem('user')
    
    if (savedToken && savedUser) {
      token.value = savedToken
      user.value = JSON.parse(savedUser)
    }
  }

  // 登录
  const login = async (username: string, password: string) => {
    try {
      const response = await userApi.login(username, password)
      if (response.success && response.data) {
        const { token: newToken, user: userData } = response.data
        
        // 保存到store
        token.value = newToken
        user.value = userData
        
        // 保存到localStorage
        localStorage.setItem('token', newToken)
        localStorage.setItem('user', JSON.stringify(userData))
        
        ElMessage.success('登录成功')
        return true
      } else {
        ElMessage.error(response.message || '登录失败')
        return false
      }
    } catch (error: any) {
      ElMessage.error(error.response?.data?.message || '登录失败')
      return false
    }
  }

  // 注册
  const register = async (userData: Partial<User> & { password: string }) => {
    try {
      const response = await userApi.register(userData)
      if (response.success && response.data) {
        const { token: newToken, user: newUser } = response.data
        
        // 保存到store
        token.value = newToken
        user.value = newUser
        
        // 保存到localStorage
        localStorage.setItem('token', newToken)
        localStorage.setItem('user', JSON.stringify(newUser))
        
        ElMessage.success('注册成功')
        return true
      } else {
        ElMessage.error(response.message || '注册失败')
        return false
      }
    } catch (error: any) {
      ElMessage.error(error.response?.data?.message || '注册失败')
      return false
    }
  }

  // 退出登录
  const logout = async () => {
    try {
      await userApi.logout()
    } catch (error) {
      console.error('退出登录失败:', error)
    } finally {
      // 清除状态
      token.value = null
      user.value = null
      
      // 清除localStorage
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      
      ElMessage.success('已退出登录')
    }
  }

  // 更新用户信息
  const updateUserInfo = (newUserData: User) => {
    user.value = newUserData
    localStorage.setItem('user', JSON.stringify(newUserData))
  }

  // 检查是否为管理员
  const isAdmin = computed(() => user.value?.role === 'ADMIN')

  // 初始化
  init()

  return {
    user,
    token,
    isLoggedIn,
    isAdmin,
    login,
    register,
    logout,
    updateUserInfo
  }
}) 