import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '@/stores/user'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      redirect: '/home'
    },
    {
      path: '/login',
      name: 'Login',
      component: () => import('@/views/Login.vue'),
      meta: { requiresAuth: false }
    },
    {
      path: '/register',
      name: 'Register',
      component: () => import('@/views/Register.vue'),
      meta: { requiresAuth: false }
    },
    {
      path: '/home',
      name: 'Home',
      component: () => import('@/views/Home.vue'),
      meta: { requiresAuth: true }
    },
    {
      path: '/admin',
      name: 'AdminLayout',
      component: () => import('@/views/admin/AdminLayout.vue'),
      meta: { requiresAuth: true, requiresAdmin: true },
      children: [
        {
          path: '',
          redirect: '/admin/dashboard'
        },
        {
          path: 'dashboard',
          name: 'AdminDashboard',
          component: () => import('@/views/admin/Dashboard.vue')
        },
        {
          path: 'users',
          name: 'AdminUsers',
          component: () => import('@/views/admin/Users.vue')
        },
        {
          path: 'videos',
          name: 'AdminVideos',
          component: () => import('@/views/admin/Videos.vue')
        },
        {
          path: 'comments',
          name: 'AdminComments',
          component: () => import('@/views/admin/Comments.vue')
        },
        {
          path: 'categories',
          name: 'AdminCategories',
          component: () => import('@/views/admin/Categories.vue')
        },
        {
          path: 'system',
          name: 'AdminSystem',
          component: () => import('@/views/admin/System.vue')
        }
      ]
    },
    {
      path: '/video/:id',
      name: 'VideoDetail',
      component: () => import('@/views/VideoDetail.vue'),
      meta: { requiresAuth: true }
    },
    {
      path: '/upload',
      name: 'UploadVideo',
      component: () => import('@/views/UploadVideo.vue'),
      meta: { requiresAuth: true }
    },
    {
      path: '/profile',
      name: 'Profile',
      component: () => import('@/views/Profile.vue'),
      meta: { requiresAuth: true }
    },
    {
      path: '/search',
      name: 'Search',
      component: () => import('@/views/Search.vue'),
      meta: { requiresAuth: true }
    },
    {
      path: '/api-test',
      name: 'ApiTest',
      component: () => import('@/views/ApiTest.vue'),
      meta: { requiresAuth: true, requiresAdmin: true }
    },
    {
      path: '/video-play-test',
      name: 'VideoPlayTest',
      component: () => import('@/views/VideoPlayTest.vue'),
      meta: { requiresAuth: true, requiresAdmin: true }
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'NotFound',
      component: () => import('@/views/NotFound.vue')
    }
  ]
})

// 路由守卫
router.beforeEach((to, from, next) => {
  const userStore = useUserStore()
  
  // 检查是否需要登录
  if (to.meta.requiresAuth && !userStore.isLoggedIn) {
    next('/login')
    return
  }
  
  // 检查是否需要管理员权限
  if (to.meta.requiresAdmin && !userStore.isAdmin) {
    next('/home')
    return
  }
  
  // 如果已登录且访问登录页，重定向到首页
  if (userStore.isLoggedIn && (to.path === '/login' || to.path === '/register')) {
    if (userStore.isAdmin) {
      next('/admin/dashboard')
    } else {
      next('/home')
    }
    return
  }
  
  next()
})

export default router 