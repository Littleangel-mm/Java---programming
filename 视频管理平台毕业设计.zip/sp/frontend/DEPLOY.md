# SP视频平台前端部署指南

## 开发环境部署

### 1. 环境要求
- Node.js 18.20.8+
- npm 或 yarn
- 现代浏览器（Chrome、Firefox、Safari、Edge）

### 2. 安装依赖
```bash
cd frontend
npm install
```

### 3. 启动开发服务器
```bash
npm run dev
```

开发服务器将在 http://localhost:3000 启动

### 4. 构建生产版本
```bash
npm run build
```

构建文件将生成在 `dist` 目录中

## 生产环境部署

### 1. 使用Nginx部署

#### 安装Nginx
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install nginx

# CentOS/RHEL
sudo yum install nginx
```

#### 配置Nginx
创建配置文件 `/etc/nginx/sites-available/sp-video-platform`：

```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/sp-video-platform;
    index index.html;

    # 处理前端路由
    location / {
        try_files $uri $uri/ /index.html;
    }

    # API代理
    location /api/ {
        proxy_pass http://localhost:8080/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # 静态资源缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

#### 启用配置
```bash
sudo ln -s /etc/nginx/sites-available/sp-video-platform /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

#### 部署文件
```bash
# 构建项目
npm run build

# 复制到服务器
sudo cp -r dist/* /var/www/sp-video-platform/
```

### 2. 使用Docker部署

#### 创建Dockerfile
```dockerfile
# 构建阶段
FROM node:18-alpine as build-stage
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

# 生产阶段
FROM nginx:alpine as production-stage
COPY --from=build-stage /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

#### 创建nginx.conf
```nginx
server {
    listen 80;
    server_name localhost;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://backend:8080/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

#### 构建和运行
```bash
# 构建镜像
docker build -t sp-video-platform-frontend .

# 运行容器
docker run -d -p 80:80 --name sp-frontend sp-video-platform-frontend
```

### 3. 使用Docker Compose部署

#### 创建docker-compose.yml
```yaml
version: '3.8'

services:
  frontend:
    build: ./frontend
    ports:
      - "80:80"
    depends_on:
      - backend
    networks:
      - sp-network

  backend:
    image: sp-video-platform-backend:latest
    ports:
      - "8080:8080"
    environment:
      - SPRING_PROFILES_ACTIVE=prod
    networks:
      - sp-network

networks:
  sp-network:
    driver: bridge
```

#### 启动服务
```bash
docker-compose up -d
```

## 环境变量配置

### 开发环境
创建 `.env` 文件：
```
VITE_APP_TITLE=SP视频平台
VITE_APP_API_BASE_URL=http://localhost:8080
VITE_APP_VERSION=1.0.0
```

### 生产环境
根据实际部署环境修改API地址：
```
VITE_APP_API_BASE_URL=https://your-api-domain.com
```

## 注意事项

1. **CORS配置**：确保后端API已正确配置CORS，允许前端域名访问
2. **HTTPS**：生产环境建议使用HTTPS
3. **缓存策略**：静态资源应设置适当的缓存策略
4. **监控**：建议配置日志监控和性能监控
5. **备份**：定期备份前端代码和配置文件

## 故障排除

### 常见问题

1. **API请求失败**
   - 检查后端服务是否正常运行
   - 检查API地址配置是否正确
   - 检查CORS配置

2. **路由404错误**
   - 确保Nginx配置了正确的try_files规则
   - 检查前端路由配置

3. **静态资源加载失败**
   - 检查文件路径是否正确
   - 检查Nginx静态文件配置

4. **构建失败**
   - 检查Node.js版本是否符合要求
   - 检查依赖是否安装完整
   - 查看构建日志获取详细错误信息 